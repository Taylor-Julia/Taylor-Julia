#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""gamma.py placeholder file for backwards compatibility; Dec 2015
"""
from __future__ import absolute_import, division, print_function

from psychopy import logging

logging.warning('Deprecated v1.84.00: instead of `from psychopy import gamma`'
                ', now do `from psychopy.visual import gamma`')

