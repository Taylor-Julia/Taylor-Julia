.. _P4N:

P4N: Python for Neuroscience (and Psychology)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The original P4N workshops have been rebranded and extended to provide a greater range of audiences and levels. See :ref:`officialWorkshops` for details.
