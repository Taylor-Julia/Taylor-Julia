.. _officialWorkshops:

PsychoPy official workshops
===============================

You can now find information about
`PsychoPy workshops here <https://workshops.psychopy.org>`_
