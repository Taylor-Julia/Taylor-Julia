.. _gotchas:

Common Mistakes (aka Gotcha's)
-------------------------------

.. toctree::
   :maxdepth: 1   
   :glob:

   commonMistakes/*
   
If you are having problems getting the application to run please see :ref:`troubleshooting`