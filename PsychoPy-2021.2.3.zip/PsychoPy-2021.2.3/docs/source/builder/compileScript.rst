.. _compileScript:

Compiling a Script
----------------------

If you click the `compile script` icon this will display the script for your experiment in the :ref:`coder` window. 

This can be used for debugging experiments, entering small amounts of code and learning a bit about writing scripts amongst other things.

The code is fully commented and so this can be an excellent introduction to writing your own code.