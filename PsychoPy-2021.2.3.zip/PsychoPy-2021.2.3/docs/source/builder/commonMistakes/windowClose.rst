.. _windowClose:

The window opens and immediately closes
---------------------------------------

-	Have you checked all of your variable entries are accepted commands e.g. gauss but not Gauss
-	If you compile your experiment and run it from the coder window what does the error message say? Does it point you towards a particular variable which may be incorrectly formatted?