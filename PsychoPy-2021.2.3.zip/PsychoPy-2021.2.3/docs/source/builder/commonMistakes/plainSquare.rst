.. _plainSquare:

I just want a plain square, but it's turning into a grating
-----------------------------------------------------------

-	If you don't want your stimulus to have a texture, you need Image to be None