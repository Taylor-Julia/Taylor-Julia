.. _loopFail:

The loop isn't using my Excel spreadsheet
-----------------------------------------

-	Have you remembered to specify the file you want to use when setting up the loop?
-	Have you remembered to add the variables proceeded by the $ symbol to your stimuli?
