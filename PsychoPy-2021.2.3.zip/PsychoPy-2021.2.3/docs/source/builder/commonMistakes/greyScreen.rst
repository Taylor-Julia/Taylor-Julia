.. _greyScreen:

My stimulus isn't appearing, there's only the grey background
-------------------------------------------------------------

-	Have you checked the size of your stimulus? If it is 0.5x0.5 pixels you won't be able to see it!
-	Have you checked the position of your stimulus? Is it positioned off the screen?