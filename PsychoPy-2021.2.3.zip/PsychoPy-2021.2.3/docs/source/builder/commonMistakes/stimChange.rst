.. _stimChange:

My stimulus isn't changing as I progress through the loop
---------------------------------------------------------

-	Have you changed the setting for the variable that you want to change to 'change every repeat' (or 'change every frame')?