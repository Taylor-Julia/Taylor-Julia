Can PsychoPy run my experiment with sub-millisecond timing?
------------------------------------------------------------

This question is common enough and complex enough to have a section of the manual all of its own. See :ref:`timing`
