
:mod:`psychopy.tools.plottools`
------------------------------------
.. automodule:: psychopy.tools.plottools
.. currentmodule:: psychopy.tools.plottools
    
.. autofunction:: plotFrameIntervals
