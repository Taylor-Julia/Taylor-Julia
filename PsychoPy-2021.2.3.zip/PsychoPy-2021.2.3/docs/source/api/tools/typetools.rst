

:mod:`psychopy.tools.typetools`
------------------------------------
.. automodule:: psychopy.tools.typetools
.. currentmodule:: psychopy.tools.typetools
    
.. autofunction:: float_uint8
.. autofunction:: uint8_float
.. autofunction:: float_uint16
