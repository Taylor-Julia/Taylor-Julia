

:mod:`psychopy.tools.unittools`
------------------------------------
.. automodule:: psychopy.tools.unittools
.. currentmodule:: psychopy.tools.unittools
    
.. autofunction:: radians
.. autofunction:: degrees
