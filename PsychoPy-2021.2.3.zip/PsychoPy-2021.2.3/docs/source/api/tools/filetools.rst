:mod:`psychopy.tools.filetools`
------------------------------------
.. automodule:: psychopy.tools.filetools
.. currentmodule:: psychopy.tools.filetools
    
.. autofunction:: toFile
.. autofunction:: fromFile
.. autofunction:: mergeFolder
.. autofunction:: openOutputFile
.. autofunction:: genDelimiter
