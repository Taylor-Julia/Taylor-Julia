
:mod:`psychopy.tools.coordinatetools`
-------------------------------------
.. automodule:: psychopy.tools.coordinatetools
.. currentmodule:: psychopy.tools.coordinatetools
        
.. autosummary:: 

    cart2pol
    cart2sph
    pol2cart
    sph2cart
    
Function details
~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: cart2pol
.. autofunction:: cart2sph
.. autofunction:: pol2cart
.. autofunction:: sph2cart

