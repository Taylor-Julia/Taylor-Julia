
:mod:`psychopy.tools.imagetools`
------------------------------------
.. automodule:: psychopy.tools.imagetools
.. currentmodule:: psychopy.tools.imagetools
    
.. autosummary:: 

    array2image
    image2array
    makeImageAuto
    
Function details
~~~~~~~~~~~~~~~~~~~~~~~
    
.. autofunction:: array2image
.. autofunction:: image2array
.. autofunction:: makeImageAuto