:mod:`psychopy.tools.monitorunittools`
------------------------------------------------------------
.. automodule:: psychopy.tools.monitorunittools
.. currentmodule:: psychopy.tools.monitorunittools
    
.. autosummary:: 

    convertToPix
    cm2deg
    cm2pix
    deg2cm
    deg2pix
    pix2cm
    pix2deg
    
Function details
~~~~~~~~~~~~~~~~~~~~~~~
    
.. autofunction:: convertToPix
.. autofunction:: cm2deg
.. autofunction:: cm2pix
.. autofunction:: deg2cm
.. autofunction:: deg2pix
.. autofunction:: pix2cm
.. autofunction:: pix2deg
