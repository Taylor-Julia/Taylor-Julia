:mod:`psychopy.info` - functions for getting information about the system
==============================================================================

.. automodule:: psychopy.info
    :members:
