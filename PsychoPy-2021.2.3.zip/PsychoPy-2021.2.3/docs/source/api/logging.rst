:mod:`psychopy.logging` - control what gets logged
======================================================================

.. automodule:: psychopy.logging
    :members:
    
:func:`flush`
----------------------------------
.. autofunction:: psychopy.logging.flush

:func:`setDefaultClock`
----------------------------------
.. autofunction:: psychopy.logging.setDefaultClock