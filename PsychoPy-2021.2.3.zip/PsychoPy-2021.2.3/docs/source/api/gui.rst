:mod:`psychopy.gui` - create dialogue boxes
===================================================

:class:`~psychopy.gui.DlgFromDict`
------------------------------------
.. autoclass:: psychopy.gui.DlgFromDict
    :members:
    :undoc-members:


:class:`~psychopy.gui.Dlg`
------------------------------------
.. autoclass:: psychopy.gui.Dlg
    :members:
    :exclude-members: display, exec_


:func:`~psychopy.gui.fileOpenDlg`
------------------------------------
.. autofunction:: psychopy.gui.fileOpenDlg


:func:`~psychopy.gui.fileSaveDlg`
------------------------------------
.. autofunction:: psychopy.gui.fileSaveDlg
 
