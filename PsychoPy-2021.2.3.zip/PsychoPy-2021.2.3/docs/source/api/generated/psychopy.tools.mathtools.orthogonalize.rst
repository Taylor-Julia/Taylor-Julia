﻿psychopy.tools.mathtools.orthogonalize
======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: orthogonalize