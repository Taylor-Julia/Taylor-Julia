﻿psychopy.tools.gltools.endQuery
===============================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: endQuery