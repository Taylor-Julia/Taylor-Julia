﻿psychopy.tools.gltools.useLights
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: useLights