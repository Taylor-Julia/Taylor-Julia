﻿psychopy.tools.gltools.deleteVBO
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: deleteVBO