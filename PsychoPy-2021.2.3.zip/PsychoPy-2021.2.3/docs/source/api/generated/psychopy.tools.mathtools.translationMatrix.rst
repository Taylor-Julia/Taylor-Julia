﻿psychopy.tools.mathtools.translationMatrix
==========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: translationMatrix