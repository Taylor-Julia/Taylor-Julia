﻿psychopy.tools.gltools.deleteObjectARB
======================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: deleteObjectARB