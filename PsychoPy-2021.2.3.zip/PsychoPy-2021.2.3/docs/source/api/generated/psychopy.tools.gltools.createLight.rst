﻿psychopy.tools.gltools.createLight
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createLight