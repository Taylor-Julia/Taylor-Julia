﻿psychopy.tools.mathtools.ortho3Dto2D
====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: ortho3Dto2D