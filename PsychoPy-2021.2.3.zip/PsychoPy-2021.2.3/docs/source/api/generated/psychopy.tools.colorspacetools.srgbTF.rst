﻿psychopy.tools.colorspacetools.srgbTF
=====================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: srgbTF