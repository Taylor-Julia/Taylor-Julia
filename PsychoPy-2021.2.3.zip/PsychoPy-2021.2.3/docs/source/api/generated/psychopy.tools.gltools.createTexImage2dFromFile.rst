﻿psychopy.tools.gltools.createTexImage2dFromFile
===============================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createTexImage2dFromFile