﻿psychopy.tools.mathtools.intersectRayOBB
========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: intersectRayOBB