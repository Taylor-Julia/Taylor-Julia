﻿psychopy.tools.gltools.beginQuery
=================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: beginQuery