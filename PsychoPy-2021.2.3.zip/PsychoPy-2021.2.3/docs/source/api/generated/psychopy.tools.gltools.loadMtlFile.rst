﻿psychopy.tools.gltools.loadMtlFile
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: loadMtlFile