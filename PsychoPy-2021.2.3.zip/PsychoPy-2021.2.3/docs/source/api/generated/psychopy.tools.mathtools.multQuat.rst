﻿psychopy.tools.mathtools.multQuat
=================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: multQuat