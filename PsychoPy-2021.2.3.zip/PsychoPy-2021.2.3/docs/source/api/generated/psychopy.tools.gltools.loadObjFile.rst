﻿psychopy.tools.gltools.loadObjFile
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: loadObjFile