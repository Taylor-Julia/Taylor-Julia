﻿psychopy.tools.gltools.deleteObject
===================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: deleteObject