﻿psychopy.tools.gltools.createVBO
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createVBO