﻿psychopy.tools.gltools.validateProgram
======================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: validateProgram