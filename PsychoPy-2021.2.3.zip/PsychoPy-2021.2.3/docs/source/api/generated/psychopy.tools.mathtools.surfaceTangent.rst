﻿psychopy.tools.mathtools.surfaceTangent
=======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: surfaceTangent