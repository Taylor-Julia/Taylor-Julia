﻿psychopy.tools.mathtools.zeroFix
================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: zeroFix