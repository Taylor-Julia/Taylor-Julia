﻿psychopy.tools.mathtools.slerp
==============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: slerp