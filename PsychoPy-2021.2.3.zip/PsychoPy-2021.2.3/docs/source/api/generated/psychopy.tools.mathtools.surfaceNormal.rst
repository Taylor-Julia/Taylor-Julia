﻿psychopy.tools.mathtools.surfaceNormal
======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: surfaceNormal