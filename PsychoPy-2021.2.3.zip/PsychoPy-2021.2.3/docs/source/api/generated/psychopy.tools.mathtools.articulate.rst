﻿psychopy.tools.mathtools.articulate
===================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: articulate