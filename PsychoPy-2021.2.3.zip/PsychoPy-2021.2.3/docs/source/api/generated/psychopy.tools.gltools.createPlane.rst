﻿psychopy.tools.gltools.createPlane
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createPlane