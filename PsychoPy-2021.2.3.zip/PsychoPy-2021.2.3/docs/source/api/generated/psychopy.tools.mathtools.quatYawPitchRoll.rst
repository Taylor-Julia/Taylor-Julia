﻿psychopy.tools.mathtools.quatYawPitchRoll
=========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: quatYawPitchRoll