﻿psychopy.tools.gltools.detachObjectARB
======================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: detachObjectARB