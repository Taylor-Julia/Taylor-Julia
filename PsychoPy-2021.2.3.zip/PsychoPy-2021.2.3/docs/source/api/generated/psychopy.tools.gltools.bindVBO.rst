﻿psychopy.tools.gltools.bindVBO
==============================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: bindVBO