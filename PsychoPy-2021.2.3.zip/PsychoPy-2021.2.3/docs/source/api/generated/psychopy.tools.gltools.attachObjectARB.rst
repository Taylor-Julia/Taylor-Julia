﻿psychopy.tools.gltools.attachObjectARB
======================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: attachObjectARB