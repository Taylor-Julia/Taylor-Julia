﻿psychopy.tools.mathtools.vertexNormal
=====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: vertexNormal