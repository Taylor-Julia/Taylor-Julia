﻿psychopy.tools.mathtools.multMatrix
===================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: multMatrix