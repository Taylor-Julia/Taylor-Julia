﻿psychopy.tools.mathtools.accumQuat
==================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: accumQuat