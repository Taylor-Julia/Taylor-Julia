﻿psychopy.tools.gltools.useMaterial
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: useMaterial