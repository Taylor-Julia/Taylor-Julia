﻿psychopy.tools.mathtools.applyQuat
==================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: applyQuat