﻿psychopy.tools.mathtools.applyMatrix
====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: applyMatrix