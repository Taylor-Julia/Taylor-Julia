﻿psychopy.tools.mathtools.quatMagnitude
======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: quatMagnitude