﻿psychopy.tools.gltools.ObjMeshInfo
==================================

.. currentmodule:: psychopy.tools.gltools

.. autoclass:: ObjMeshInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ObjMeshInfo.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ObjMeshInfo.extents
      ~ObjMeshInfo.faces
      ~ObjMeshInfo.mtlFile
      ~ObjMeshInfo.normals
      ~ObjMeshInfo.texCoords
      ~ObjMeshInfo.vertexPos
   
   