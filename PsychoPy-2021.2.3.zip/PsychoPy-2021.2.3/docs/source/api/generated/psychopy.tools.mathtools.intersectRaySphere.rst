﻿psychopy.tools.mathtools.intersectRaySphere
===========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: intersectRaySphere