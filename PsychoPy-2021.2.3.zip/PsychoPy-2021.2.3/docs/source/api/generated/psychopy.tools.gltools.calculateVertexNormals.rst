﻿psychopy.tools.gltools.calculateVertexNormals
=============================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: calculateVertexNormals