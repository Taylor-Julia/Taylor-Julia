﻿psychopy.tools.mathtools.scaleMatrix
====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: scaleMatrix