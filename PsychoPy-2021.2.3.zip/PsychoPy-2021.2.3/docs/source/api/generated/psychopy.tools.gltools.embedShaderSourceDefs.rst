﻿psychopy.tools.gltools.embedShaderSourceDefs
============================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: embedShaderSourceDefs