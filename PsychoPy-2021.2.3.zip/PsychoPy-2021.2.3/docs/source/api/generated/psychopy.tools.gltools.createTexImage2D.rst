﻿psychopy.tools.gltools.createTexImage2D
=======================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createTexImage2D