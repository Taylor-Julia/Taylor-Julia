﻿psychopy.tools.mathtools.computeBBoxCorners
===========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: computeBBoxCorners