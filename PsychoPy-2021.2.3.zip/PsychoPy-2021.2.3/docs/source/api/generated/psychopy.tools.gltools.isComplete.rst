﻿psychopy.tools.gltools.isComplete
=================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: isComplete