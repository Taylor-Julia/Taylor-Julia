﻿psychopy.tools.gltools.transformMeshPosOri
==========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: transformMeshPosOri