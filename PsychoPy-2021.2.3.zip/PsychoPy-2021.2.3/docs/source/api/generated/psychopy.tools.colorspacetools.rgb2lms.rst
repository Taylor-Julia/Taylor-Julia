﻿psychopy.tools.colorspacetools.rgb2lms
======================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: rgb2lms