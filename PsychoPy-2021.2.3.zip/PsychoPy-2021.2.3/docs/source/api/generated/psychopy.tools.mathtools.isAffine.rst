﻿psychopy.tools.mathtools.isAffine
=================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: isAffine