﻿psychopy.tools.mathtools.scale
==============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: scale