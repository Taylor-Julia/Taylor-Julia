﻿psychopy.tools.mathtools.dot
============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: dot