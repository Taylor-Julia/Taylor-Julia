﻿psychopy.tools.mathtools.normalMatrix
=====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: normalMatrix