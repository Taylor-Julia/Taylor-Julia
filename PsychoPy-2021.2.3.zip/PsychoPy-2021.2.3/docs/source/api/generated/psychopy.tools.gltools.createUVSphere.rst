﻿psychopy.tools.gltools.createUVSphere
=====================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createUVSphere