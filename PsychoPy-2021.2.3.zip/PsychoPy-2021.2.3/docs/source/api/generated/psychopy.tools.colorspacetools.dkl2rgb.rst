﻿psychopy.tools.colorspacetools.dkl2rgb
======================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: dkl2rgb