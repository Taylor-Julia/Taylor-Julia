﻿psychopy.tools.gltools.VertexBufferInfo
=======================================

.. currentmodule:: psychopy.tools.gltools

.. autoclass:: VertexBufferInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VertexBufferInfo.__init__
      ~VertexBufferInfo.validate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VertexBufferInfo.dataType
      ~VertexBufferInfo.hasBuffer
      ~VertexBufferInfo.isIndex
      ~VertexBufferInfo.name
      ~VertexBufferInfo.shape
      ~VertexBufferInfo.size
      ~VertexBufferInfo.stride
      ~VertexBufferInfo.target
      ~VertexBufferInfo.usage
      ~VertexBufferInfo.userData
   
   