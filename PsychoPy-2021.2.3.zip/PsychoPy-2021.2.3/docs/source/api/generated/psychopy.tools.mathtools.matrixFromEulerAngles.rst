﻿psychopy.tools.mathtools.matrixFromEulerAngles
==============================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: matrixFromEulerAngles