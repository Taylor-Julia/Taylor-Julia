﻿psychopy.tools.gltools.getQuery
===============================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getQuery