﻿psychopy.tools.mathtools.isOrthogonal
=====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: isOrthogonal