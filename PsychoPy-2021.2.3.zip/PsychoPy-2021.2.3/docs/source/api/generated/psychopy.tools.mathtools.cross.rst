﻿psychopy.tools.mathtools.cross
==============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: cross