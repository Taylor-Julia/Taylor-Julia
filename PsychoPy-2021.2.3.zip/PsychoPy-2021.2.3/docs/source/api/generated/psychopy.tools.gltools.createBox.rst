﻿psychopy.tools.gltools.createBox
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createBox