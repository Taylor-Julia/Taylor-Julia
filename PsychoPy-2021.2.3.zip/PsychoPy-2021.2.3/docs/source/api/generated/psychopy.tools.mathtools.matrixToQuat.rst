﻿psychopy.tools.mathtools.matrixToQuat
=====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: matrixToQuat