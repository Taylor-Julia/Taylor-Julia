﻿psychopy.tools.mathtools.intersectRayTriangle
=============================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: intersectRayTriangle