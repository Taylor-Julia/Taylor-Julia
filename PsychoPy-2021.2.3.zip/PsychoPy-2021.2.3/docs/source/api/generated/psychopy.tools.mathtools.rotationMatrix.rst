﻿psychopy.tools.mathtools.rotationMatrix
=======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: rotationMatrix