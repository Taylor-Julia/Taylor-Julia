﻿psychopy.tools.mathtools.lerp
=============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: lerp