﻿psychopy.tools.gltools.disableVertexAttribArray
===============================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: disableVertexAttribArray