﻿psychopy.tools.gltools.getModelViewMatrix
=========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getModelViewMatrix