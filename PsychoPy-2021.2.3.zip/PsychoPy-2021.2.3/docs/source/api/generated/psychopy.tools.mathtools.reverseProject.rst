﻿psychopy.tools.mathtools.reverseProject
=======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: reverseProject