﻿psychopy.tools.mathtools.length
===============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: length