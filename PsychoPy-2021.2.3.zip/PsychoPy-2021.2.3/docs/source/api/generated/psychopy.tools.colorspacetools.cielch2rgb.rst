﻿psychopy.tools.colorspacetools.cielch2rgb
=========================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: cielch2rgb