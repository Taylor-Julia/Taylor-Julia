﻿psychopy.tools.gltools.getString
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getString