﻿psychopy.tools.gltools.useProgramObjectARB
==========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: useProgramObjectARB