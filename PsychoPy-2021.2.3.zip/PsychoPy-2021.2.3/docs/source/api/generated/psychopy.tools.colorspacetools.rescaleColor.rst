﻿psychopy.tools.colorspacetools.rescaleColor
===========================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: rescaleColor