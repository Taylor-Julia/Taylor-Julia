﻿psychopy.tools.mathtools.intersectRayPlane
==========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: intersectRayPlane