﻿psychopy.tools.gltools.unbindTexture
====================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: unbindTexture