﻿psychopy.tools.mathtools.quatToMatrix
=====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: quatToMatrix