﻿psychopy.tools.mathtools.posOriToMatrix
=======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: posOriToMatrix