﻿psychopy.tools.mathtools.lensCorrection
=======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: lensCorrection