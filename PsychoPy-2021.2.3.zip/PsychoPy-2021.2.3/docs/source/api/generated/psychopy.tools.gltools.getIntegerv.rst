﻿psychopy.tools.gltools.getIntegerv
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getIntegerv