﻿psychopy.tools.gltools.createTexImage2DMultisample
==================================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createTexImage2DMultisample