﻿psychopy.tools.gltools.getOpenGLInfo
====================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getOpenGLInfo