﻿psychopy.tools.gltools.getAbsTimeGPU
====================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getAbsTimeGPU