﻿psychopy.tools.gltools.getAttribLocations
=========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getAttribLocations