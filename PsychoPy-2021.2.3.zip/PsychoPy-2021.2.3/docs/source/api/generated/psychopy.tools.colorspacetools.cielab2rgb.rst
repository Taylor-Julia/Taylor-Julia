﻿psychopy.tools.colorspacetools.cielab2rgb
=========================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: cielab2rgb