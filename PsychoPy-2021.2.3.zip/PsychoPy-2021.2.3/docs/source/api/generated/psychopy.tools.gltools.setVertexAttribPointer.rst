﻿psychopy.tools.gltools.setVertexAttribPointer
=============================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: setVertexAttribPointer