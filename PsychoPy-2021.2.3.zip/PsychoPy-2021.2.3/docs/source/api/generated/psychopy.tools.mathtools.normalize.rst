﻿psychopy.tools.mathtools.normalize
==================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: normalize