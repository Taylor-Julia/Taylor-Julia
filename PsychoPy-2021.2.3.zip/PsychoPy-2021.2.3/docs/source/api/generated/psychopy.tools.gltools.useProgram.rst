﻿psychopy.tools.gltools.useProgram
=================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: useProgram