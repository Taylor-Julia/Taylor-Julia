﻿psychopy.tools.mathtools.invertMatrix
=====================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: invertMatrix