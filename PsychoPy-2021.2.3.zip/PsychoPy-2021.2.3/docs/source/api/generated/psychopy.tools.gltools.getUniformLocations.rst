﻿psychopy.tools.gltools.getUniformLocations
==========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getUniformLocations