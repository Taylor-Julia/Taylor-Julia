﻿psychopy.tools.mathtools.forwardProject
=======================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: forwardProject