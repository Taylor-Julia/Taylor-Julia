﻿psychopy.tools.mathtools.intersectRayAABB
=========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: intersectRayAABB