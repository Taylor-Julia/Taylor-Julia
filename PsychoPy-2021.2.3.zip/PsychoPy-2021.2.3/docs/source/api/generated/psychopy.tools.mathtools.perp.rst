﻿psychopy.tools.mathtools.perp
=============================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: perp