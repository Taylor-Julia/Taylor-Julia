﻿psychopy.tools.mathtools.bisector
=================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: bisector