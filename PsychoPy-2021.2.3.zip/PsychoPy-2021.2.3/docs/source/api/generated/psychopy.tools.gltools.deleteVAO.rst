﻿psychopy.tools.gltools.deleteVAO
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: deleteVAO