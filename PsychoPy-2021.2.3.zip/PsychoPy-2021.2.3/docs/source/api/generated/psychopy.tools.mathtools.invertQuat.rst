﻿psychopy.tools.mathtools.invertQuat
===================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: invertQuat