﻿psychopy.tools.mathtools.quatToAxisAngle
========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: quatToAxisAngle