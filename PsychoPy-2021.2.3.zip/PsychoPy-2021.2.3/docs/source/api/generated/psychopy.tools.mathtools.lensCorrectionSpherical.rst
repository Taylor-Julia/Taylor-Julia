﻿psychopy.tools.mathtools.lensCorrectionSpherical
================================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: lensCorrectionSpherical