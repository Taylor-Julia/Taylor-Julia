﻿psychopy.tools.colorspacetools.lms2rgb
======================================

.. currentmodule:: psychopy.tools.colorspacetools

.. autofunction:: lms2rgb