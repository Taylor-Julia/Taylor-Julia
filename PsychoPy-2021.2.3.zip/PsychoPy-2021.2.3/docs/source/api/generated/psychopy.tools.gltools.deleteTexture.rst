﻿psychopy.tools.gltools.deleteTexture
====================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: deleteTexture