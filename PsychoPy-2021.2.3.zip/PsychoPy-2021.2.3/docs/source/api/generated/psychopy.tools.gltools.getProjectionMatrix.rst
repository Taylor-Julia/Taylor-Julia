﻿psychopy.tools.gltools.getProjectionMatrix
==========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getProjectionMatrix