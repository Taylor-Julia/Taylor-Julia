﻿psychopy.tools.gltools.attachShader
===================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: attachShader