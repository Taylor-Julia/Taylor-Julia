﻿psychopy.tools.gltools.validateProgramARB
=========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: validateProgramARB