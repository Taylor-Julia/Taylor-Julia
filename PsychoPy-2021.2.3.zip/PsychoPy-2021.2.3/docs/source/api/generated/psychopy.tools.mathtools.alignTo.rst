﻿psychopy.tools.mathtools.alignTo
================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: alignTo