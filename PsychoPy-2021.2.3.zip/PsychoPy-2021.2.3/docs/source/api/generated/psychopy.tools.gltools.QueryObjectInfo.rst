﻿psychopy.tools.gltools.QueryObjectInfo
======================================

.. currentmodule:: psychopy.tools.gltools

.. autoclass:: QueryObjectInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~QueryObjectInfo.__init__
      ~QueryObjectInfo.isValid
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~QueryObjectInfo.name
      ~QueryObjectInfo.target
   
   