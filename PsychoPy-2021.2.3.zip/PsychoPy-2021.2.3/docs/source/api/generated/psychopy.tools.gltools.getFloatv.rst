﻿psychopy.tools.gltools.getFloatv
================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getFloatv