﻿psychopy.tools.gltools.getInfoLog
=================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: getInfoLog