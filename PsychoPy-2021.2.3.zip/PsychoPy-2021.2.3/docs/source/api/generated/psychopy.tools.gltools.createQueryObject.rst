﻿psychopy.tools.gltools.createQueryObject
========================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createQueryObject