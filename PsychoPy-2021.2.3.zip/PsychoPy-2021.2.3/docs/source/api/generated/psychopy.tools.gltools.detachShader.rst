﻿psychopy.tools.gltools.detachShader
===================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: detachShader