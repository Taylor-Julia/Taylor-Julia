﻿psychopy.tools.mathtools.fitBBox
================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: fitBBox