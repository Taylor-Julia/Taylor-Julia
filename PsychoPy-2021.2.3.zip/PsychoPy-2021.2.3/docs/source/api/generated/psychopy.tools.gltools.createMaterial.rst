﻿psychopy.tools.gltools.createMaterial
=====================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: createMaterial