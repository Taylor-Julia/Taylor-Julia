﻿psychopy.tools.gltools.enableVertexAttribArray
==============================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: enableVertexAttribArray