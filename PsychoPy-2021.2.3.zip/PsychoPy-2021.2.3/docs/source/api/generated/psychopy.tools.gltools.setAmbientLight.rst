﻿psychopy.tools.gltools.setAmbientLight
======================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: setAmbientLight