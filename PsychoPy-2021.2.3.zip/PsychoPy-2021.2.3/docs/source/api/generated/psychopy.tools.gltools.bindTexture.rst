﻿psychopy.tools.gltools.bindTexture
==================================

.. currentmodule:: psychopy.tools.gltools

.. autofunction:: bindTexture