﻿psychopy.tools.gltools.VertexArrayInfo
======================================

.. currentmodule:: psychopy.tools.gltools

.. autoclass:: VertexArrayInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VertexArrayInfo.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VertexArrayInfo.activeAttribs
      ~VertexArrayInfo.attribDivisors
      ~VertexArrayInfo.count
      ~VertexArrayInfo.indexBuffer
      ~VertexArrayInfo.isLegacy
      ~VertexArrayInfo.name
      ~VertexArrayInfo.userData
   
   