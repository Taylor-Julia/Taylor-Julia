﻿psychopy.tools.mathtools.surfaceBitangent
=========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: surfaceBitangent