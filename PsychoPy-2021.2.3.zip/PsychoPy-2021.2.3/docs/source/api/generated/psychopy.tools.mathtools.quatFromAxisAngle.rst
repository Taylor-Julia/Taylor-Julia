﻿psychopy.tools.mathtools.quatFromAxisAngle
==========================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: quatFromAxisAngle