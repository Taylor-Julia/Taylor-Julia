﻿psychopy.tools.mathtools.fixTangentHandedness
=============================================

.. currentmodule:: psychopy.tools.mathtools

.. autofunction:: fixTangentHandedness