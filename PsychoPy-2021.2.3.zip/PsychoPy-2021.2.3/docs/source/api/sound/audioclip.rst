:class:`~psychopy.sound.AudioClip` - for working with audio data
----------------------------------------------------------------

.. currentmodule:: psychopy.sound

Overview
========

.. autosummary::
    AudioClip

Details
=======

.. autoclass:: AudioClip
    :members:
    :undoc-members:
    :inherited-members:
