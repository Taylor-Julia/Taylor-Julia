:class:`~psychopy.sound.TranscriptionResult` - results of an audio transcription
--------------------------------------------------------------------------------

.. currentmodule:: psychopy.sound

Overview
========

.. autosummary::
    TranscriptionResult

Details
=======

.. autoclass:: TranscriptionResult
    :members:
    :undoc-members:
    :inherited-members:
