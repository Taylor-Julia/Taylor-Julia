:mod:`psychopy.filters` - helper functions for creating filters
==============================================================================

This module has moved to `psychopy.visual.filters` but you can still (currently) import it as `psychopy.filters`

.. automodule:: psychopy.visual. filters
    :members:
