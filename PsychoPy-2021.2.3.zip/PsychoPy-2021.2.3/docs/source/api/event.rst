:mod:`psychopy.event` - for keypresses and mouse clicks
==============================================================================


.. autoclass:: psychopy.event.Mouse
    :members:
    :undoc-members:
    :inherited-members:

.. autofunction:: psychopy.event.clearEvents
.. autofunction:: psychopy.event.waitKeys
.. autofunction:: psychopy.event.getKeys
.. autofunction:: psychopy.event.xydist
