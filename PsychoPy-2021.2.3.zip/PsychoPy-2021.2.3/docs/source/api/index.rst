.. _api:

Reference Manual (API)
======================

Contents:

.. toctree::
    :maxdepth: 1
    :glob:

    core
    clock
    visual/index
    sound/index
    hardware/index
    iohub/index
    tools/index
    *

.. only:: html

    Indices and tables
    ~~~~~~~~~~~~~~~~~~

    * :ref:`genindex`
    * :ref:`modindex`
    * :ref:`search`
