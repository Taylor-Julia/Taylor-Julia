:mod:`psychopy.core` - basic functions (clocks etc.)
======================================================

.. automodule:: psychopy.core
    :members: getTime, getAbsTime, wait, Clock, CountdownTimer, MonotonicClock, StaticPeriod
