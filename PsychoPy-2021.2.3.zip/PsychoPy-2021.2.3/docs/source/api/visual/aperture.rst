
:class:`Aperture`
------------------------------------

Attributes
=============

.. currentmodule:: psychopy.visual


.. autosummary::

    Aperture
    Aperture.win
    Aperture.size
    Aperture.pos
    Aperture.ori
    Aperture.nVert
    Aperture.shape
    Aperture.inverted
    Aperture.units
    Aperture.name
    Aperture.autoLog

.. autoclass:: psychopy.visual.Aperture
    :members:
    :undoc-members:
    :inherited-members:    
    