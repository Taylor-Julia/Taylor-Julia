

:class:`ElementArrayStim`
------------------------------------
.. autoclass:: psychopy.visual.ElementArrayStim
    :members:
    :undoc-members:
    :inherited-members:
 