

:class:`CustomMouse`
------------------------------------
.. autoclass:: psychopy.visual.CustomMouse
    :members:
    :undoc-members:
    :inherited-members:    
    