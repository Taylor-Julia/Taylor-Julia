:mod:`psychopy.visual.windowwarp` - warping to spherical, cylindrical, or other projections
===========================================================================================

.. automodule:: psychopy.visual.windowwarp

:class:`Warper`
------------------------------------
.. autoclass:: psychopy.visual.windowwarp.Warper
    :members: changeProjection
    :undoc-members: 


