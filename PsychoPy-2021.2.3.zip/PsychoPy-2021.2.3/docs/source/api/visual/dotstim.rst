

:class:`DotStim`
------------------------------------
.. autoclass:: psychopy.visual.DotStim
    :members:
    :undoc-members:
    :inherited-members:
    :exclude-members: setContr, setDKL, setLMS, setRGB, set, setPos