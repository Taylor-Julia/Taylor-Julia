
:class:`BufferImageStim`
------------------------------------------------------------------------

Attributes
=============

.. currentmodule:: psychopy.visual

.. autosummary:: 

    BufferImageStim
    BufferImageStim.win
    BufferImageStim.buffer
    BufferImageStim.rect
    BufferImageStim.stim
    BufferImageStim.mask
    BufferImageStim.units
    BufferImageStim.pos
    BufferImageStim.ori
    BufferImageStim.size
    BufferImageStim.contrast
    BufferImageStim.color
    BufferImageStim.colorSpace
    BufferImageStim.opacity
    BufferImageStim.interpolate
    BufferImageStim.name
    BufferImageStim.autoLog
    BufferImageStim.draw
    BufferImageStim.autoDraw 
    
        
Details
=============

.. autoclass:: BufferImageStim
    :members:
    :undoc-members:
    :inherited-members: