:class:`SphereStim`
----------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    SphereStim
    
        
Details
=======

.. autoclass:: SphereStim
    :members:
    :undoc-members:
    :inherited-members:
