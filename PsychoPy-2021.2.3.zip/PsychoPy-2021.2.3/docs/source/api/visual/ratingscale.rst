
:class:`RatingScale`
------------------------------------
.. autoclass:: psychopy.visual.RatingScale
    :members:
    :undoc-members:
