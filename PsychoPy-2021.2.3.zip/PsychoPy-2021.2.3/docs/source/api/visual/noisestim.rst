
:class:`NoiseStim`
------------------------------------------------------------------------

Attributes
=============

.. currentmodule:: psychopy.visual

Details
=============

.. autoclass:: NoiseStim
    :members:
    :undoc-members:
    :inherited-members:
