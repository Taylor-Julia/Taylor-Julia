:class:`RigidBodyPose`
----------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    RigidBodyPose
    
        
Details
=======

.. autoclass:: RigidBodyPose
    :members:
    :undoc-members:
    :inherited-members:
