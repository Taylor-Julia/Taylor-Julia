:class:`BoxStim`
----------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    BoxStim
    
        
Details
=======

.. autoclass:: BoxStim
    :members:
    :undoc-members:
    :inherited-members:
