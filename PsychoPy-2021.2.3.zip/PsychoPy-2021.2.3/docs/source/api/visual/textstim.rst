

:class:`TextStim`
------------------------------------
.. autoclass:: psychopy.visual.TextStim
    :members:
    :inherited-members:
