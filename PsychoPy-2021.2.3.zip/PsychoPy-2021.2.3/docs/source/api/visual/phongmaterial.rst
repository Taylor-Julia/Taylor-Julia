:class:`BlinnPhongMaterial`
----------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    BlinnPhongMaterial
    
        
Details
=======

.. autoclass:: BlinnPhongMaterial
    :members:
    :undoc-members:
    :inherited-members:
