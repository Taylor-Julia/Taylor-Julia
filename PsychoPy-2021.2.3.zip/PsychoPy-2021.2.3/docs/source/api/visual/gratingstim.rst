
:class:`GratingStim`
------------------------------------------------------------------------

Attributes
=============

.. currentmodule:: psychopy.visual

.. autosummary:: 

    GratingStim
    GratingStim.win
    GratingStim.tex
    GratingStim.mask
    GratingStim.units
    GratingStim.sf
    GratingStim.pos
    GratingStim.ori
    GratingStim.size
    GratingStim.contrast
    GratingStim.color
    GratingStim.colorSpace
    GratingStim.opacity
    GratingStim.interpolate
    GratingStim.texRes
    GratingStim.name
    GratingStim.autoLog
    GratingStim.draw
    GratingStim.autoDraw 
    
        
Details
=============

.. autoclass:: GratingStim
    :members:
    :undoc-members:
    :inherited-members: