:class:`ObjMeshStim`
--------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    ObjMeshStim
    
        
Details
=======

.. autoclass:: ObjMeshStim
    :members:
    :undoc-members:
    :inherited-members:
