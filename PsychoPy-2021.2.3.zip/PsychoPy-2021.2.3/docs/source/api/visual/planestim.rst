:class:`PlaneStim`
------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    PlaneStim
    
        
Details
=======

.. autoclass:: PlaneStim
    :members:
    :undoc-members:
    :inherited-members:
