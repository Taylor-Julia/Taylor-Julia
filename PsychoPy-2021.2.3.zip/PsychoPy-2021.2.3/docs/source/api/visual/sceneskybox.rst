:class:`SceneSkybox`
---------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    SceneSkybox
    
        
Details
=======

.. autoclass:: SceneSkybox
    :members:
    :undoc-members:
    :inherited-members:
