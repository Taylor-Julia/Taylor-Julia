:mod:`psychopy.visual.windowframepack` - Pack multiple monochrome images into RGB frame
===========================================================================================

.. automodule:: psychopy.visual.windowframepack

:class:`ProjectorFramePacker`
------------------------------------
.. autoclass:: psychopy.visual.windowframepack.ProjectorFramePacker
    :members: 
    :undoc-members:  endOfFlip, startOfFlip

