:class:`BoundingBox`
----------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    BoundingBox
    
        
Details
=======

.. autoclass:: BoundingBox
    :members:
    :undoc-members:
    :inherited-members:
