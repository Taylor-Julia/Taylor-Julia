
:class:`RadialStim`
------------------------------------------------------------------------

Attributes
=============

.. currentmodule:: psychopy.visual

.. autosummary:: 

    RadialStim
    RadialStim.win
    RadialStim.tex
    RadialStim.mask
    RadialStim.units
    RadialStim.pos
    RadialStim.ori
    RadialStim.size
    RadialStim.contrast
    RadialStim.color
    RadialStim.colorSpace
    RadialStim.opacity
    RadialStim.interpolate
    RadialStim.setAngularCycles
    RadialStim.setAngularPhase
    RadialStim.setRadialCycles
    RadialStim.setRadialPhase
    RadialStim.name
    RadialStim.autoLog
    RadialStim.draw
    RadialStim.autoDraw
    RadialStim.clearTextures 
    
        
Details
=============

.. autoclass:: RadialStim
    :members:
    :undoc-members:
    :inherited-members: