
.. _visualhelperfunctions:

Helper functions
------------------------------------
.. autofunction:: psychopy.visual.helpers.pointInPolygon
.. autofunction:: psychopy.visual.helpers.polygonsOverlap
.. autofunction:: psychopy.visual.helpers.groupFlipVert
