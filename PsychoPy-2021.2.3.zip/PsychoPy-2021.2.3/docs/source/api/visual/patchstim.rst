

:class:`PatchStim` (deprecated)
------------------------------------------------------------------------
.. autoclass:: psychopy.visual.PatchStim
    :members:
    :undoc-members:
    :inherited-members:
   