

:class:`SimpleImageStim`
------------------------------------------------------------------------
.. autoclass:: psychopy.visual.SimpleImageStim
    :members:
    :undoc-members:
    :inherited-members:
    