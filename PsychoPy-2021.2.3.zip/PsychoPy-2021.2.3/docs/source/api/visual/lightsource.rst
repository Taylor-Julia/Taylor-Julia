:class:`LightSource`
---------------------

Attributes
==========

.. currentmodule:: psychopy.visual

.. autosummary:: 

    LightSource
    
        
Details
=======

.. autoclass:: LightSource
    :members:
    :undoc-members:
    :inherited-members:
