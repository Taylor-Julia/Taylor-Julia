
Encryption
============

Some labs may wish to better protect their data from casual inspection
or accidental disclosure. This is possible within PsychoPy using a separate
python package, pyFileSec, which grew out of PsychoPy. pyFileSec is distributed
with the StandAlone versions of PsychoPy, or can be installed using pip or easy_install
via https://pypi.python.org/pypi/PyFileSec/

Some elaboration of pyFileSec usage and security strategy can be found here: http://pythonhosted.org/PyFileSec

Basic usage is illustrated in the Coder demo > misc > encrypt_data.py
