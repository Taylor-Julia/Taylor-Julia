:mod:`psychopy.clock` -  Clocks and timers
======================================================

.. automodule:: psychopy.clock
    :members: getTime, getAbsTime, wait, Clock, CountdownTimer, MonotonicClock, StaticPeriod
