.. _iohub_devices:

Supported Devices
=================

psychopy.iohub supports several different device types.

Details for each device can be found in the following sections.

.. toctree::
    :maxdepth: 3

    Keyboard <device/keyboard>
    Mouse <device/mouse>
    Eye Tracker <device/eyetracker>
