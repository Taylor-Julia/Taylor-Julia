.. _iohub_serial:

Serial Port Device and Events
=================================

TBC