:mod:`psychopy.web` - Web methods
=========================================

Test for access
---------------
.. autofunction:: psychopy.web.haveInternetAccess
.. autofunction:: psychopy.web.requireInternetAccess

Proxy set-up and testing
------------------------
.. autofunction:: psychopy.web.setupProxy
