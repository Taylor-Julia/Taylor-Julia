.. _brainproducts:

BrainProducts
=============================================

.. automodule:: psychopy.hardware.brainproducts

.. _brainproductsRCS:

.. autoclass:: psychopy.hardware.brainproducts.RemoteControlServer
    :members:

