.. _egi:

egi (pynetstation) 
=============================================

.. automodule:: psychopy.hardware.egi
    :members: