.. _joystick:

joystick (pyglet and pygame)
=============================================

AT THE MOMENT JOYSTICK DOES NOT APPEAR TO WORK UNDER PYGLET. We need someone motivated and capable to go and get this right (problem is with event polling under pyglet)

.. automodule:: psychopy.hardware.joystick
    :members:

.. autoclass:: psychopy.hardware.joystick.Joystick
    :members:
    :undoc-members:
    :inherited-members:
