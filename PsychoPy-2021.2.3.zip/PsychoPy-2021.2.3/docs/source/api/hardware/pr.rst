PhotoResearch
=============================================

.. currentmodule:: psychopy.hardware.pr

Supported devices:
    
    - :class:`PR650`
    - :class:`PR655/PR670 <PR655>`

.. automodule:: psychopy.hardware.pr
    :members: