Launch an fMRI experiment: Test or Scan
==========================================

.. automodule:: psychopy.hardware.emulator
    :inherited-members:
    
.. autoclass:: psychopy.hardware.emulator.ResponseEmulator
    :members:

.. autoclass:: psychopy.hardware.emulator.SyncGenerator
    :members: