.. _keyboard:

Keyboard
=============================================

.. automodule:: psychopy.hardware.keyboard

.. currentmodule:: psychopy.hardware.keyboard



Classes and functions
-----------------------


.. autoclass:: Keyboard
    :members:
    :inherited-members:

.. autoclass:: KeyPress
    :members:
    :inherited-members:

.. autofunction:: getKeyboards


