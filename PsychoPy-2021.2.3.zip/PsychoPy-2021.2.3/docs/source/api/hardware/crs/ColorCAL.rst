.. _ColorCAL:

.. currentmodule:: psychopy.hardware.crs.colorcal

:class:`ColorCAL`
------------------------------------------------------------------------

Attributes
=============

.. autosummary::

    ColorCAL

Details
=============

.. autoclass:: ColorCAL
    :members:
    :undoc-members:
    :inherited-members: