

.. _PsychoPy: https://psychopy.org
.. _PsychoJS: https://github.com/psychopy/psychojs
.. _Pavlovia: https://pavlovia.org

.. _query string: https://en.wikipedia.org/wiki/Query_string

.. |prolific| replace:: Prolific
.. _prolific: https://prolific.ac



.. |pavloviaRun| image:: /images/pavloviaRun.png
    :alt: Run online button
    :scale: 50%

.. |experimentSettingsBtn| image:: /images/experimentSettingsBtn.png
    :alt: Experiemnt settings button
    :scale: 50%