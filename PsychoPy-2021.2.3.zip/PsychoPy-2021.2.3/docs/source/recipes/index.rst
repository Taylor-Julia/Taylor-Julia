Recipes ("How-to"s)
=====================================

Below are various tips/tricks/recipes/how-tos for PsychoPy. They involve something that is a little more involved than you would find in FAQs, but too specific for the manual as such (should they be there?).

.. toctree::
   :maxdepth: 1
   :glob:
   
   *
