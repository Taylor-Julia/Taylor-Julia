3xxx: Issues with timing
=====================================

There are many ways for timing to go wrong, and these alerts will warn you about some of them (but we do always recommend that you test your timing carefully with hardware devices if precise timing is important to your study).

.. toctree::
   :maxdepth: 1
   :glob: 
   
   3*