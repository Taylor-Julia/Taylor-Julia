Code: Test Alert
=================

Synopsis
-----------

Provide a few sentences (at most) about the alert.


Details
-----------

Longer description with optional links to further information


PsychoPy versions affected
---------------------------

Info about what versions are affected if this has been fixed

Solutions
-----------

Describe fixes/workarounds for the user


