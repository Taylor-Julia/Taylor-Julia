2xxx: Issues with units
=====================================

These issue usually result in problems with stimuli not appearing (too fast, too small, off-screen) or being an unexpected size or color.

.. toctree::
   :maxdepth: 1
   :glob: 
   
   2*