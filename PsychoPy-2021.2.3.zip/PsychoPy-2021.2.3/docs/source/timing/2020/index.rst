.. _timing2020:

Mega-timing study data
=============================

Here are the data summaries for our paper, `The timing mega-study: comparing a range of experiment generators, both lab-based and online <https://peerj.com/articles/9414/>`_

You can read the full preprint of the paper at https://peerj.com/articles/9414/

.. toctree::
    :maxdepth: 1

    table2
    table3
