Changelog
=========

.. raw:: html

    <style> .noncompat {color:red} </style>

.. role:: noncompat

PsychoPy uses **major.minor.patch** version numbers:

- All changes to **major.minor** numbers indicate that changes are expected to change the behavior of PsychoPy experiments
- Changes to the **patch** version number are relativel minor bug fixes and we hope they do not change behavior

Updating without breaking existing studies
------------------------------------------

We **strongly recommend** that, once your experiment is finished and is being run "for real",
that you apply the :ref:`useVersion <useVersion>` setting so that your study will always try
to run on the same PsychoPy version even where a different version is installed on the computer.
That setting often even allows PsychoPy to run experiments from versions that have not yet
been installed! If the dependencies haven't changed it will run.

PsychoPy 2021.2
---------------

*Highlights:*

- Unified Eyetracker support via ioHub is now integrated into Builder for easy-to-use eyetracking studies, with many fixes, improvements and a "MouseGaze" option to simulate eye movements while testing
- Mic recordings for voice responses (Python and JS)
- Transcription (speech-to-text) via Google Speech or using CMU Pocket Sphinx (free but currently on the Python lib only)
- Improved JavaScript outputs from the Builder, providing more seamless migration to web-based studies

*Compatibility Changes:*

- :noncompat:`CHANGED: In Python the random number generators for TrialHandlers etc use an improved algorithm (PCG64) and are now indendent of each other but seeded random sequences will differ from previous versions`

PsychoPy 2021.2.0
~~~~~~~~~~~~~~~~~

*New and improved:*

- JS+Py: Record and transcribe (speech-to-text) audio responses in both Python and JavaScript engines using various local (CMU Pocket Sphinx) and web (Google and Bing) services.
- Py: Eyetracking Components added to Builder for code-free eye-gaze monitoring
    - Eyetracker Record: Starts an ioHub server to receive input from an eye tracker
    - Eyetracker Calibration: Runs calibration procedure on connected eyetracker
    - Eyetracker Validation: Runs validation procedure on connected eyetracker
    - Region Of Interest: A PsychoPy polygon with methods to check whether it's being looked at, how long for, how many times, etc.
    - also improved calibration and validation procedures
- Py: Improved Movie playback performance for both the OpenCV (MovieStim3) and VLC backends. The VLC backend has added playback controls (fast-forward, rewind, etc)
- Py: hardware.Keyboard class now supports ioHub as a backend and will use that in preference to Psychtoolbox keyboard (PsychHID) if ioHub has been started before the Keyboard is created. ioHub keyboard is similarly in performance but with fewer constraints (can handle a wider range of keyboards)
- App: demos within the app got so busy they've been moved into categories
- App: includes some basic fonts, so as not to rely on what is installed (except on macOS where these aren't permitted)
- App: output is available again in the bottom of the Coder view
- App: many improvements to the autotranslate of Py->JS in Code Components (fixing issues from the "Crib sheet")
- JS: audio playback can fade in/out to avoid clicks
- JS: Builder loops (TrialHandlers) support and update properties such as thisN as in Python Experiments
- JS: Form supports `formComplete()` call to check if all required items have a response
- JS: Form supports itesm types: SLIDER, RADIO (synonyms for RATING and CHOICE)
- JS: Button Component now supported for text-based buttons (as in the Python Component already present)
- JS: supports more options for color styles

*Fixes:*

- Py: TextBox better handling word boundaries for newlines
- Py: Button was incorrectly treating a held-down button as a click (now supports new-clicks only option)
- Py: ioHub better integration with PsychoPy units and color spaces
- JS: bug in Form scrolling
- JS: various fixes to TextBox and Form styling
- JS: Data files output now include information about their character encoding (BOM) supporting more locales of Excel

PsychoPy 2021.2.1
~~~~~~~~~~~~~~~~~

Fixes:

- macOS was crashing on launch (caused by missing files from psychtoolbox stripped by macOS GateKeeper)
- added cryptography lib explicitly to requirements for pip install `commit:267483d00 <https://github.com/psychopy/psychopy/commit/267483d00>`_
- Runner local debug of PsychoJS experiments was failing with MIME-type errors (Runner didn't know about new psychojs packaging) `#4153 <https://github.com/psychopy/psychopy/issues/4153>`_
- extended timeout when querying Pavlovia from the app (e.g. searching for projects) `#4148 <https://github.com/psychopy/psychopy/issues/4148>`_
- corrected reset of clock for new Button Component
- DlgFromDict was crashing if `labels` were used (in code) `#4137 <https://github.com/psychopy/psychopy/issues/4137>`_
- short (<0.5s) sounds were not labelled as finished in PsychoJS boilerplate `#4117 <https://github.com/psychopy/psychopy/issues/4117>`_
- contrast parameter was not being applied to ShapeStim `#4111 <https://github.com/psychopy/psychopy/issues/4111>`_

PsychoPy 2021.2.2
~~~~~~~~~~~~~~~~~

Fixes:

- Builder outputs weren't fully honouring the `userVersion()` request, resulting in broken PsychoJS code `commit:5f10b0a12 <https://github.com/psychopy/psychopy/commit/5f10b0a12>`_ `commit:017c18f2f <https://github.com/psychopy/psychopy/commit/017c18f2f31e>`_
- Better documentation of (high-performance) VLC movie backend
- iohub.Mouse.setPosition was not handling units correctly when given a float
- Builder boilerplate for Microphone was looking for a transcription even if none was requested `#4163 <https://github.com/psychopy/psychopy/issues/4163>`_

PsychoPy 2021.1
---------------

The first major release of 2021 brings a lot of fixes (the dev team is focussing heavily on making the user experience more smooth at the moment).

On top of those fixes are a number of useful additions though, like the new :ref:`buttonComponent`.

NEW:

- Builder has a :ref:`buttonComponent` to make it easier to have clickable image/text objects
- Builder: Improved layout of Component dialogs:
  
    - Consistent tabs for common parameters (like pos, size, color...)
    - Component parameters that use filenames (sounds, images, etc.) now have a Browse... button
    - Component parameters that use Excel files now have an “open in Excel” button, if you click this when the field is blank it will open a pre-made template for you
    - Component parameters that are colors now have a button to open the color picker

- Builder now features separate compile buttons for JS and Py and will open the JS file in the Coder view when compiled
- Builder readme files now support markdown formatting (and .md extensions) psychopy/psychopy#3377
- PsychoPy lib: refactored color handling via the :class:`~psychopy.colors.Color` class

:noncompat:`CHANGES (compatibility issues):`

- :noncompat:`CHANGED: the new more-flexible parameters of PsychoPy Experiment Components makes experiments from 2021.1 **will not run** on older versions of PsychoPy. If you share your study with people using older versions make sure you set the :ref:'useVersion' setting to be 2021.1.0 or upwards so that it will run elsewhere`
- :noncompat:`CHANGED: PsychoJS: orientation for PsychoJS now follows clock convention rather than engineering convention (polar coordinates, positive rotation is anti-clockwise) whereas PsychoPy used the clock convention. From this release onwards both use the clock convention or orientation/rotation.`
- :noncompat:`CHANGED: Slider has additional params for colors and fonts of lines/labels/marker that will not exist on older installations`
- :noncompat:`CHANGED: BufferImageStim was using an incorrect rect specification for selecting the region of the screen - it was using a bottom-left instead of PsychoPy standard center '#3597 <https://github.com/psychopy/psychopy/issues/3597>'_`

PsychoPy 2021.1.0
~~~~~~~~~~~~~~~~~~

FIXES:

- All: Curly quotation marks (“”), which are sometimes automatically put into text boxes by MacOS and certain keyboard settings, will now be automatically replaced with regular quotation marks (“) when in code. To use curly quotation marks still, you can “escape” them by putting a \ before them.
- Lib: Fixed syntax warnings on Python 3.8 `#3344 <https://github.com/psychopy/psychopy/issues/3344>`_
- Lib: The Pygame audio backend can be used again. `#3382 <https://github.com/psychopy/psychopy/issues/3382>`_
- Lib: Several fixes to iohub ( `#3348 <https://github.com/psychopy/psychopy/issues/3348>`_, `#3399 <https://github.com/psychopy/psychopy/issues/3399>`_, `#3412 <https://github.com/psychopy/psychopy/issues/3412>`_, commit psychopy/psychopy/3912167)
- Builder/Coder: Fixed the error raised when the “Plot gamma” button in the monitor center is clicked but no calibration data is loaded. `#3384 <https://github.com/psychopy/psychopy/issues/3384>`_ 
- Coder/Builder: Correct detection of retina/high-dpi displays within wxPython on MacOS, Linux, and Windows.
- Python Lib: TextBox stim text layout not working on linux and macOS.
- Python Lib: various minor fixes to TextBox2
- Coder: Miscellaneous bug fixes to demos/coder/stimuli example scripts.
- Coder: Fixed a possible error when parsing code to build the source tree.
- Coder: Handle error caused when closing editor tabs.
- Builder: The “Routine” pane can no longer be-  moved which broke the builder interface.
- Coder: Make Coder's default size reasonable on fresh install. `#3472 <https://github.com/psychopy/psychopy/issues/3472>`_
- Coder: Bug where opening an unsupported file type raises an error. `#3519 <https://github.com/psychopy/psychopy/issues/3519>`_
- Coder: Fixed bug where the source tree raises and error if it comes across things it cannot correctly parse.
- Online: Prevent Safari from beeping in full screen. psychopy/psychojs#266
- Online: Slider sizing, tick placement, and event handling improvements. `#249 <https://github.com/psychopy/psychopy/issues/249>`_ `#263 <https://github.com/psychopy/psychopy/issues/263>`_ `#264 <https://github.com/psychopy/psychopy/issues/264>`_
- Online: Fixed ShapeStim instances ignoring the closeShape property. psychopy/psychojs#245
- Online: Support `TrialHandler.Method.FULLRANDOM`. psychopy/psychojs#247
- Online: Improved mouse event accuracy overall. psychopy/psychojs#248
- Online: Fixed ShapeStim variants ignoring the contrast property. psychopy/psychojs#250
- Online: Fixed an issue translating ‘\n’ encoded line breaks when importing conditions files. psychopy/psychojs#251
- Online: Fixed TextBox click handling. psychopy/psychojs#258
- Online: Improved MovieStim autoplay. psychopy/psychojs#260
- Online: Allow for parsing of array-like strings when setting VisualStim position or size. psychopy/psychojs#262
- Online: Prevent Safari from beeping in full screen. psychopy/psychojs#266

PsychoPy 2021.1.1
~~~~~~~~~~~~~~~~~~

FIXES:

- Error when trying to sync a new project with Pavlovia `commit:33b3d80ea <https://github.com/psychopy/psychopy/commit/33b3d80ea>`_
- TextBox in Builder was resetting to "default text" on each repeat rather than blank `commit:8510d9f1a <https://github.com/psychopy/psychopy/commit/8510d9f1a>`_
- Editable elements of Form were being erroneously drawn when they fell beyond the Form boundary `commit:7d02c8251 <https://github.com/psychopy/psychopy/commit/7d02c8251>`_
- Several improvements to styling of Form (on Python)
- Added a preference for Builder to show only the online-compatible Components (or other similar options). This is a BETA testing feature

PsychoPy 2021.1.2
~~~~~~~~~~~~~~~~~~

FIXES:

- Code Components were raising an error when trying to generate JS code `#3643 <https://github.com/psychopy/psychopy/issues/3643>`_
- Slider styles weren't generating correct JS code
- New Button component (Python only) was not cleaning previous clicks so they tended to act as if clicking all trials! `#3641 <https://github.com/psychopy/psychopy/issues/3641>`_

PsychoPy 2021.1.3
~~~~~~~~~~~~~~~~~~

FIXES:

- Builder: Fix `'list' object has no attribute 'contains'` with clickable mouse objects `#3651 <https://github.com/psychopy/psychopy/issues/3651>`_
- Builder: context (right-click) menu was not aligned with mouse in Flow for large Flows `#3657 <https://github.com/psychopy/psychopy/issues/3657>`_
- Builder: Slider styles were not being used correctly from previous versions (<2021.0) `#3665 <https://github.com/psychopy/psychopy/issues/3665>`_
- Builder: crash if the filter preference was used to filter out pure Python or pure JS Components from Builder `#3649 <https://github.com/psychopy/psychopy/issues/3649>`_
- Builder: Color Picker defaults to RGB to reduce chance of users pasting in RGBA to visual Components  `#3667 <https://github.com/psychopy/psychopy/issues/3667>`_
- Runner: local debug of online studies working again (was trying to fetch the wrong PsychoJS version) `commit:af6622c71 <https://github.com/psychopy/psychopy/commit/af6622c712>`_
- PsychoPy lib: better handling of unknown fonts (fall back to Open Sans and Alert) `commit:fba09ef8d <https://github.com/psychopy/psychopy/commit/fba09ef8d0a>`_
- PsychoPy lib: better timing on iohub for macOS key/mouse polling `commit:fba09ef8d <https://github.com/psychopy/psychopy/commit/fba09ef8d0a>`_

PsychoPy 2021.1.4
~~~~~~~~~~~~~~~~~~

FIXES:

- Py Lib: Sounds from files were being truncated `#3689 <https://github.com/psychopy/psychopy/issues/3689>`_
- Py Lib: TrialHandlerExt now compatible with current numpy (had an index error before) `#3705 <https://github.com/psychopy/psychopy/issues/3705>`_
- Py Lib: MoviStim raising an error if opacity was None `commit:50334df2f <https://github.com/psychopy/psychopy/commit/50334df2f>`_
- Py Lib: RIFT backend not working `commit:428f62f80 <https://github.com/psychopy/psychopy/commit/428f62f80>`_
- Builder: When letter height was set to a variable it raised an error at run time `TypeError: len() of unsized object` `commit:b1a77ca3a <https://github.com/psychopy/psychopy/commit/b1a77ca3a>`_
- Builder: Raising an error when floats looking like file names `#3719 <https://github.com/psychopy/psychopy/issues/3719>`_
- Builder: better handling of failure to updateVersion `commit:afec41226 <https://github.com/psychopy/psychopy/commit/afec41226>`_
- JS: TextBox when editable was not being reset on each trial `#3706 <https://github.com/psychopy/psychopy/issues/3706>`_
- JS: Keyboard should stop consuming keypresses at end of trial, even if not storing data `#3706 <https://github.com/psychopy/psychopy/issues/3706>`_
- JS: Add Sound.setSound() method to allow for dynamically deciding audio source psychopy/psychojs#154
- JS: Allow for PIXI updates when dynamically adjusting opacity, including on polygons psychopy/psychojs#203
- JS: Give Form radio type support psychopy/psychojs#281
- JS: Improve ImageStim.setImage() attribute checking psychopy/psychojs#292
- JS: Give TrackPlayer fades on play / stop psychopy/psychojs#296
- JS: Fix TextBox eating up key presses psychopy/psychojs#302

PsychoPy 2020.2
-----------------

NEW FEATURES:

- New look, including dark mode, customizable themes and new flat buttons (you can choose a Classic theme to get the old buttons back for comfort)
- Now have an class for /editable/ text called **TextBox2**:

  - very fast rendering (faster than the original TextStim)once the font characters are uploaded
  - supports an editable flag which allows it to pick up text input to the window including full unicode support for your keyboard
  - you can apply (fake) bold and italics within the text using <i></i> and <b></b>
  - if multiple editable TextBoxes are onscreen together you can tab between them

- **Form** components now work online and support (in both lab-based and online versions):

  - free text
  - ratings and sliders
  - choice boxes (radio buttons)
  - descriptions (no response)
  - headings

- Improved Coder:

  - call-tips for code and better auto-completion
  - view the folders and the structure of the current file

- Improved Runner:

  - Builder/Coder provide options to run directly (Ctrl-R) and Runner only then used to show stdout
  - more visible how to save/open Runner filelists
  - Runner filelists saved as `.psyrun` files and can be loaded into PsychoPy with a double-click

- Online studies don't need to use html folder. Keep everything where it is! If resources aren't found automatically (and you would have put them in to the Resources folder) you can now add them to the ExperimentSettings>Online>AdditionalResources
- Added support for Emotive and BrainProducts EEG hardware
- CSV data outputs now have an option to set the delimitter (e.g. `;` or `\t` rather than `,`)
- Brush component now has an option to allow drawing without having to hold down the mouse button `#2980 <https://github.com/psychopy/psychopy/issues/2980>`_

:noncompat:`CHANGES:`

- _PsychoJS_ code now uses the same syntax for loop termination as _PsychoPy_ allowing either `nameOfLoop.finished=true` or `currentLoop.finished=true`
- Python 2.7 is no longer supported. We recommend Python versions 3.6 or 3.7 (3.8 is not tested likely to work)

FIXES:

- Various compatibility fixes for JS code from PsychoPy

  - loop termination now working the same as Python and correctly auto-translated
  - movies *should* now restart correctly, at least on browsers that support the seek behavior
  - randint is now included and imported in all scripts
  - sin, cos, pi etc are also imported in all scripts

- support for wxPython 4.1
- so many more small fixes!

PsychoPy 2020.2.10
~~~~~~~~~~~~~~~~~~

Further fixes on top of the `new features in 2020.2 <https://www.psychopy.org/changelog.html#psychopy-2020-2>`_:

- Fixed rendering of TextBox2 following Big Sur update of 2020.2.7 `commit:0fcb89c54 <https://github.com/psychopy/psychopy/commit/0fcb89c54>`_ `commit:39777a3e0 <https://github.com/psychopy/psychopy/commit/39777a3e0>`_ `commit:1aec9abb9 <https://github.com/psychopy/psychopy/commit/1aec9abb9>`_
- Fixed handling of `continueRoutine=False` in BeginExperiment of online studies `commit:ae20cb12f <https://github.com/psychopy/psychopy/commit/ae20cb12f41>`_
- Erroneous warnings about code being used as parameters `commit:40bbfe1a3 <https://github.com/psychopy/psychopy/commit/40bbfe1a3>`_

PsychoPy 2020.2.9
~~~~~~~~~~~~~~~~~

Further fixes on top of the `new features in 2020.2 <https://www.psychopy.org/changelog.html#psychopy-2020-2>`_:

- TextBox2 broke in 2020.2.8 due to switch from PyOpenGL to pyglet.gl in text rendering `commit:39777a3e0 <https://github.com/psychopy/psychopy/commit/39777a3e0>`_ `commit:1aec9abb9 <https://github.com/psychopy/psychopy/commit/1aec9abb9>`_
- Fixed error Unknown colorSpace: 'Named' `commit:da234cc46 <https://github.com/psychopy/psychopy/commit/da234cc46>`_
- Superfluous debug messages from ioHub when no key pressed `commit:9589e4865 <https://github.com/psychopy/psychopy/commit/9589e4865>`_

PsychoPy 2020.2.8
~~~~~~~~~~~~~~~~~

Further fixes on top of the `new features in 2020.2 <https://www.psychopy.org/changelog.html#psychopy-2020-2>`_:

- support for macOS 11.1 Big Sur (updated mac pyglet to 1.5.11 and mac Python to 3.6.8)
- fixed default blank text in textBox for online studies actually showing a pair of quotes `commit:786e1d3f7 <https://github.com/psychopy/psychopy/commit/786e1d3f7>`_
- flag to alphabetically sort Exp Info fields was being set always true `#3279 <https://github.com/psychopy/psychopy/issues/3279>`_
- Position and Size params for Form Component were being requested twice `commit:d45ca99c9 <https://github.com/psychopy/psychopy/commit/d45ca99c9>`_
- fixed annoying (but harmless) error 'ModuleNotFoundError: import of pyglet halted; None in sys.modules' 
- further fixes to Runner not showing print() statements `commit:e0ec67e6f <https://github.com/psychopy/psychopy/commit/e0ec67e6f>`_
- Routine panels now support mouse scroll wheel to navigate `commit:6da3707d3 <https://github.com/psychopy/psychopy/commit/6da3707d3>`_

PsychoPy 2020.2.7
-----------------

(Binaries never released)

PsychoPy 2020.2.6
~~~~~~~~~~~~~~~~~

FIXES:

- missing resource error in some online experiments, caused by incorrect relative relative paths in Settings>Online>Resources `#3285 <https://github.com/psychopy/psychopy/issues/3285>`_
- JavaScript Code Components for Before Experiment is now moved earlier in the script - it needed to be positioned before first function opens `#3289 <https://github.com/psychopy/psychopy/issues/3289>`_
- TextBox was missing setBorderColor and setFillColor so these needed code to change dynamically `commit:eb915732d <https://github.com/psychopy/psychopy/commit/eb915732d>`_
- TextBox was carrying the text from one trial into the next `commit:330f5fa1d <https://github.com/psychopy/psychopy/commit/330f5fa1d>`_
- Coder FoldAll menu item was having no effect `commit:6d4f66b0d <https://github.com/psychopy/psychopy/commit/6d4f66b0d>`_
- TextStim opacity can now be set dynamically `#1045 <https://github.com/psychopy/psychopy/issues/1045>`_
- Loop OK button was sometimes left disabled if invalid inputs `commit:3a1104f71 <https://github.com/psychopy/psychopy/commit/3a1104f71>`_
- fixed non-uniform probabilities of conditions file row selection suggested in docs `#3256 <https://github.com/psychopy/psychopy/issues/3256>`_
- workaround for scipy.optimize import error on windows machines that are using BitLocker `#3287 <https://github.com/psychopy/psychopy/issues/3287>`_
- if a TextBox is the only editable thing on the screen then give it focus `#3269 <https://github.com/psychopy/psychopy/issues/3269>`_

PsychoPy 2020.2.5
~~~~~~~~~~~~~~~~~

FIXES:

- Now code-signing the installer on Windows as well as macOS
- Failing to send print statements to output, depending on how PsychoPy was launched `commit:4773ec32d <https://github.com/psychopy/psychopy/commit/4773ec32dcf>`_ Only occurred if you launch by double-clicking file or if you close Runner
- Coder crashing on macOS when using editor with autocomplete=True `commit:687e81dfb <https://github.com/psychopy/psychopy/commit/687e81dfb>`_
- ioHub fix for unicode strings `commit:5451ea49a <https://github.com/psychopy/psychopy/commit/5451ea49a>`_
- Marker color on RatingScale was not resetting (but use Slider anyway!) `#3140 <https://github.com/psychopy/psychopy/issues/3140>`_
- Runner sometimes ran wrong script (and never knew which to stop). Now better tracking of running process `#3142 <https://github.com/psychopy/psychopy/issues/3142>`_
- Slider not honoring the order from the Routine (should render in order from top down) `commit:9e0299544 <https://github.com/psychopy/psychopy/commit/9e0299544>`_
- JavaScript Code Components for Before Experiment were having no effect `#3151 <https://github.com/psychopy/psychopy/issues/3151>`_
- error with trying to poll() on a script process that was NoneType `commit:cc56713cc <https://github.com/psychopy/psychopy/commit/cc56713cc>`_
- Editable textboxes were still able to be drawn if you clicked on them (even when they were not told to draw()) `commit:8253f0696 <https://github.com/psychopy/psychopy/commit/8253f0696>`_
- warn against using global JS names in experiment `#3177 <https://github.com/psychopy/psychopy/issues/3177>`_
- Brush not being reset in JavaScript `commit:88812c3bd <https://github.com/psychopy/psychopy/commit/88812c3bd>`_
- Movie reset issue `#3183 <https://github.com/psychopy/psychopy/issues/3183>`_
- countinueRoutine=False had no effect for online studies if in Begin Routine block
- errors that should have appeared in the console were sometimes appearing in the (app) error dialog `commit:d44f24d63 <https://github.com/psychopy/psychopy/commit/d44f24d63>`_
- more tolerant of whitespace in Emotiv Client ID file
- Runner AddTask dialog had wrong format for file filter `#3213 <https://github.com/psychopy/psychopy/issues/3213>`_
- Sound volume attribute was having no effect on the PTB backend `#3215 <https://github.com/psychopy/psychopy/issues/3215>`_
- Fixed fill/line colors of TextBox `#3222 <https://github.com/psychopy/psychopy/issues/3222>`_
- Error in JavaScript code when Movie Component had blank stop time `commit:0b4ddcffc <https://github.com/psychopy/psychopy/commit/0b4ddcffc>`_
- Better handling of stdout encodings when console not set to utf-8 encoding `commit:d77535906 <https://github.com/psychopy/psychopy/commit/d77535906>`_
- Improved Resources box for the online (using relative references `commit:c9558bfd8 <https://github.com/psychopy/psychopy/commit/c9558bfd8>`_ and resize with dialog `commit:d607271db <https://github.com/psychopy/psychopy/commit/d607271db>`_)
- JavaScript code-conversion now uses our own built-in `round()` function mimicking the same function in Python `commit:da426d9e3 <https://github.com/psychopy/psychopy/commit/da426d9e37e>`_

PsychoPy 2020.2.4
~~~~~~~~~~~~~~~~~~~~~~

FIXES:

- improved search for resources files whne compiling JS (was crashing if using root folder and using code to specify the conditions file) `commit:09816985d <https://github.com/psychopy/psychopy/commit/09816985d5>`_
- the `Before Experiment` section of Code Components wasn't being written for JavaScript components `commit:bbfd310 <https://github.com/psychopy/psychopy/commit/bbfd310>`_
- error with wx complaining about Alignment (in wx 4.1) `commit:a32e2ca <https://github.com/psychopy/psychopy/commit/a32e2ca>`_ `commit:ae508d6 <https://github.com/psychopy/psychopy/commit/ae508d6>`_
- TextBox Component default size is None (=autoexpand)
- TextBox `editable=True` had no effect on the Builder outputs to JavaScript
- themes menu correctly updates what thte current them is in all open windows `commit:c5cdc49 <https://github.com/psychopy/psychopy/commit/c5cdc49>`_
- custom fonts that didn't provide a "family name" were causing the font search to crash `commit:ef078ab <https://github.com/psychopy/psychopy/commit/ef078ab>`_
- bug trying to us an invalid "useRunner" preference 3532e4c
- JavaScript studies failed if there were 2 Mouse Components in a single Routine `commit:0e0b26d4d <https://github.com/psychopy/psychopy/commit/0e0b26d4dcc>`_ `commit:32a6be2 <https://github.com/psychopy/psychopy/commit/32a6be2>`_
- improved Big Five Inventory demo
- blank TextBox Component should use blank string rather than None `commit:39bf1bb <https://github.com/psychopy/psychopy/commit/39bf1bb>`_
- further fix to macOS stapling (might not have worked for users with no internet connection?)
- Form Component now honors being set to show only at certain times (in keeping with other visual Components) `commit:35ad5bc <https://github.com/psychopy/psychopy/commit/35ad5bc>`_
- Coder now correctly providing syntax styling for JS and C

PsychoPy 2020.2.3
~~~~~~~~~~~~~~~~~~~~~~

FIXES:

- **Mac version now fully signed and notarized for GateKeeper!** For some time it's been an annoyance that Apple would block PsychoPy because of it not being from a "known developer" but in recent updates GateKeeper has become so aggressive the app has been crashing on startup for some macOS versions. Hopefully Apple will now let us launch in peace!
- **better handling of non-loading fonts in the application** On mac some fonts weren't being found (although this *might* be due to the now-solved gatekeeper issue)
- **auto-translate py->js for parameters with $** We were translating code components but not parameter boxes where the user was switching to code using $  `#3064 <https://github.com/psychopy/psychopy/issues/3064>`_
- better handling when a piece of code fails to convert (warning not error) `#3063 <https://github.com/psychopy/psychopy/issues/3063>`_
- show progress (in Runner) while syncing project with Pavlovia `#3061 <https://github.com/psychopy/psychopy/issues/3061>`_
- various fixes and additions to Japanese translations


PsychoPy 2020.1
----------------

For the new decade we have a new version system. The application is still called PsychoPy3 for now,
but we're using `year.version.bugfix` from now on to mark versions.

NEW FEATURES:

- Many exciting tools for 3D rendering. See Coder demos menu for some examples
- Online studies have better cross-browser compatibility including fixed support for edge
- Auto-translate Code Components Py-?JS (syntax only)
- Online studies have substantially improve timing. In fact, PsychoPy now has the
  `best timing of any online system, consistently under 4ms precision for RTs! <https://psyarxiv.com/d6nu5/>`_
- New Runner dialog:
    - provides some 'Alerts' about things that might go wrong in their study `#2646 <https://github.com/psychopy/psychopy/issues/2646>`_
    - allows you to run/save/open a set of studies without opening a window for each one
    - allows online studies to run locally in "debug" mode to test the study before uploading

- Online studies now support shapes Cross, Star and regular polygons (nVertices) `#2673 <https://github.com/psychopy/psychopy/issues/2673>`_
- Support for pyglet 1.4, including support for **text alignment in multi-line text** `#2693 <https://github.com/psychopy/psychopy/issues/2693>`_
- :noncompat:`CHANGED: rendering of text stimuli may not look quite the same. We now have new parameters`
  `anchorHoriz` and `TextAlign` rather than `alignHoriz` but this may not act the same in all
  cases `#2693 <https://github.com/psychopy/psychopy/issues/2693>`_
- Online studies no longer require a separate `html` folder.  `#2687 <https://github.com/psychopy/psychopy/issues/2687>`_ In some cases (e.g. when adding extra resource files)
  it may be preferable to keep the html folder and that's currently still the default
  for new studies but ExperimentSettings>online>folder can now be set to blank and the html/js
  files will be saved alongside the psyexp/py files. This reduces file duplication.
- Support for QUESTplus staircases
- Pyglet backend now supports 10-bit framebuffer `#2672 <https://github.com/psychopy/psychopy/issues/2672>`_
- Updated support for Oculus Rift `#2655 <https://github.com/psychopy/psychopy/issues/2655>`_
- Added a :class:`~psychopy.visual.Pie` (pacman) stimulus `#2652 <https://github.com/psychopy/psychopy/issues/2652>`_
- Substantially faster rendering of DotStim `#2647 <https://github.com/psychopy/psychopy/issues/2647>`_

PsychoPy 2020.1.3
~~~~~~~~~~~~~~~~~~~~~~

- Runner was not launching Coder scripts from their own directory `#2819 <https://github.com/psychopy/psychopy/issues/2819>`_
- csv files should allow separator to be `;` and decimal place to be `,` `#2825 <https://github.com/psychopy/psychopy/issues/2825>`_ `#2828 <https://github.com/psychopy/psychopy/issues/2828>`_
- PsychoPy application was now launching in Windows versions <8.1 (which don't know about high-dpi displays) `#2820 <https://github.com/psychopy/psychopy/issues/2820>`_

PsychoPy 2020.1.2
~~~~~~~~~~~~~~~~~~~~~~

- Keypad key responses were not showing up as numbered responses under the new Keyboard class `#2812 <https://github.com/psychopy/psychopy/issues/2812>`_
- Cedrus button box had an error int he Builder-output code added in 2020.1.1 `commit:186ec5876 <https://github.com/psychopy/psychopy/commit/186ec587634>`_
- Code Component was accidentally *forcing* people to use code auto-conversion `commit:5c57d0c9d <https://github.com/psychopy/psychopy/commit/5c57d0c9d>`_

PsychoPy 2020.1.1
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- Several tweaks to the new Runner dialog:
    - Double-click takes you back to the file in the appropriate Builder/Coder view
    - Ctrl-R within the Runner run the file (so you can do Ctrl-R twice from builder and you're running)
    - Alerts separated from stdout so they're more visible
    - Alerts for Builder are checked on experiemnt selection rather than on script compile time
    - Alert was testing stim size/pos incorrectly if using units "from experiment settings"

- Mac keyboard access should now bring up a dialog taking you to the correct System Preferences panel
- Fixes to Eyelink 1000 communications from iohub `commit:1a8c6923b <https://github.com/psychopy/psychopy/commit/1a8c6923b0>`_
- Better support for high-res displays on Windows `#2795 <https://github.com/psychopy/psychopy/issues/2795>`_
- Further tweak to readline issues on linux `commit:6975040fa <https://github.com/psychopy/psychopy/commit/6975040fae>`_ `commit:4a80060b9 <https://github.com/psychopy/psychopy/commit/4a80060b94>`_

PsychoPy 2020.1.0
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- Rect stimulus now aliases size with width and height so that users can refer to either `#2650 <https://github.com/psychopy/psychopy/issues/2650>`_
- Faster updating of DotStim dot locations (so fewer dropped frames) `#2647 <https://github.com/psychopy/psychopy/issues/2647>`_
- `continueRoutine` can be set in the BeginRoutine block rather than the EachFrame block `#2680 <https://github.com/psychopy/psychopy/issues/2680>`_
- Tab key was incorrectly reporting itself as 'escape' in new Keyboard object `#2620 <https://github.com/psychopy/psychopy/issues/2620>`_
- many more!
- Cedrus response box can be inserted into multiple routines without having to use a Code Component (no "Could not find a Cedrus device" error)


PsychoPy 3.2
----------------

PsychoPy 3.2.4
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- Mitigated the gamma get/set fails caused by Microsoft Windows release 1903. PsychoPy
    - now avoids using these calls unless gamma-setting is really needed
    - gives more info about the cause. See more info in [troubleshooting gamma ramp](https://www.psychopy.org/troubleshooting.html#errors-with-getting-setting-the-gamma-ramp)
    - provides an option to skip gamma-setting entirely
- Slider wasn't allowing the units to be "from experiment settings" `commit:23d80b49f <https://github.com/psychopy/psychopy/commit/23d80b49f>`_
- Setting the conditions rows from another conditions file was causing "Error path is on mount... start on mount..." `commit:2e8cd2183 <https://github.com/psychopy/psychopy/commit/2e8cd2183>`_
- Mac 'tab' key was reporting itself as 'escape' with new Keyboard `commit:95326cadd <https://github.com/psychopy/psychopy/commit/95326cadd>`_
- PSTBox Python3 incompatibility (although there may be more) `commit:da83429d6 <https://github.com/psychopy/psychopy/commit/da83429d6>`_
- better scaling of rating scale (Slider) in Form `commit:d115e63cb <https://github.com/psychopy/psychopy/commit/d115e63cb>`_
- Stencil for Form was being activated immediately rather than when needed `commit:9daeba94d <https://github.com/psychopy/psychopy/commit/9daeba94d>`_

PsychoPy 3.2.3
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- on the `pip install` version (incorrectly packaged) there was an error "NameError: name ‘pythonExec’ is not defined"
- JS version system now drops the final (bugfix) release number (3.2.3 -> 3.2 in JS lib)
- Cedrus response box now supports keys as a variable value in Builder `#2608 <https://github.com/psychopy/psychopy/issues/2608>`_
- QuestPlusHandler now supports "unkown" kwargs `#2610 <https://github.com/psychopy/psychopy/issues/2610>`_

PsychoPy 3.2.2
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- timing of first frame was being given an extra (unecessary) delay if images were loaded `commit:8ddab41 <https://github.com/psychopy/psychopy/commit/8ddab41>`_
- potential app crashes if no internet avilable `commit:63aa7e0 <https://github.com/psychopy/psychopy/commit/63aa7e0>`_ `commit:b3e15f9 <https://github.com/psychopy/psychopy/commit/b3e15f9>`_
- Builder under OS X was not launching experiments if filename contained a space `commit:1b205df <https://github.com/psychopy/psychopy/commit/1b205df>`_

PsychoPy 3.2.1
~~~~~~~~~~~~~~~~~~~~~~

- Python2 installations crashed when trying to launch studies from Builder due to the use of a modern argument to subprocess not supported by Python2 `#2596 <https://github.com/psychopy/psychopy/issues/2596>`_
- If Builder script had an error, then printing of that error was sometimes being split across the output frame (of Builder) and the output panel of Coder `#2594 <https://github.com/psychopy/psychopy/issues/2594>`_

PsychoPy 3.2.0
~~~~~~~~~~~~~~~~~~~~~~

It's all about the new timing improvements!

PsychoPy 3.2.0
~~~~~~~~~~~~~~~~~~~~~~

TIMING improvements:

- **new Sound backend 'PTB' which is much faster** than any of the alternatives on all operating systems (using the C code from Psychtoolbox thanks to Mario Kleiner) :
   - when combined with pre-scheduling (e.g. start playback on upcoming win.flip()) this can generate sub-ms precision and sub-ms lag!
   - works with standard audio hardware
- **better timing of visual stimuli** when timing by 'secs' (rather than frames):
   - new feature to request info from the Window about next expected flip
   - t in a Builder scripts is now time from first frame (so synched to visual stims)
- **better timing on the keyboard responses** of the JavaScript experiments due to timestamping asynchronously with your script

Also ADDED:

- Standalone installations now provide an updated Cedrus library, pyxid2
- Support for new LabHackers TTL2USB8 device (parallel port alternative)
- Envelope grating now has exponent (power) option

FIXED:

- Long-standing issue with lots of print-statements (e.g. on every frame) crashing Builder scripts
- Support for Pyglet 1.4 (although text scaling appears to have changed a little)
- Some serial devices (photometers) were not compatible with Python3 string/bytes
  conversion
- Too many more to mention...!

PsychoPy 3.1
----------------

We've improved keyboard timing a great deal.

As of PsychoPy 3.1 we are now using the underlying code of the `kbQueue` calls in
`Psychophysics Toolbox`. The C code from those calls was ported to a new Python
package in late 2018 and this is now the basis of the new :class:`Keyboard` class.
This only works on 64-bit Python3 installations, but the Keyboard class will
fall back to the old `event.GetKeys` calls where the `psychtoolbox` package is
not available.

PsychoPy 3.1.5
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- new rendering glitch in ImageStim when mask=None and interpolate=True, caused by previous fix to the wrapping issue `#2526 <https://github.com/psychopy/psychopy/issues/2526>`_

PsychoPy 3.1.4
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- further fix to Mic for experiments created under the previous version (our last fix only solved the problem for new
  Mic Components being inserted) `#2512 <https://github.com/psychopy/psychopy/issues/2512>`_
- fixed demo timeByFrames which was set to use Qt4 for plotting instead of Qt5 (which has been the default version
  provided since the switch to Python3)
- fixed crash in the new Keyboard class caused by `psychtoolbox` lib incorrectly converting unicode characters in the
  device name (this was actually a fix in #kleinerm/Psychtoolbox-3@a5c37855a4a097) that needed repackaging
- error with Variable Component trying to save start/stop times (that might not exist for that variable) `commit:e1bca1bdc <https://github.com/psychopy/psychopy/commit/e1bca1bdc>`_
- some data could get orphaned (and not saved) by being collected in the outer section of a nested loop `commit:8b7fda826 <https://github.com/psychopy/psychopy/commit/8b7fda826>`_
- when using Mouse.getPos() with retina display and win.units=='pix' the mouse pos was double the expected value `commit:a78d74420 <https://github.com/psychopy/psychopy/commit/a78d74420>`_

PsychoPy 3.1.3
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- StairHandler code from Builder was failing in 3.1 due to new tStartRefresh
  data being sent to wrong method (addData not addOtherData) `#2497 <https://github.com/psychopy/psychopy/issues/2497>`_
- Routines in online studies that weren't included in (or before) a loop were
  not having their data saved `#2496 <https://github.com/psychopy/psychopy/issues/2496>`_
- Fix to audio capture error "bad argument at position 0" from Builder experiments `commit:dadb9be25 <https://github.com/psychopy/psychopy/commit/dadb9be25>`_
- PsychoPy app didn't recognise projects that were pointing to gitlab ssh targets (e.g. created in terminal) `commit:08d7937 <https://github.com/psychopy/psychopy/commit/08d7937>`_

PsychoPy 3.1.2
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- teething problems with new :class:`~psychopy.hardware.Keyboard`:
   - in Builder there was stuttering of sounds and lags in frame timing caused
   by accidentally creating lots of Kyeboards while checking for 'escape'
   - durations were being reported with correct magnitude but as negative values `commit:e43e47460 <https://github.com/psychopy/psychopy/commit/e43e474602b7f>`_
   - problem on Windows if keyboard device name contained unicode (that problem
   was actually in psychtoolbox package, now updated in Standalone)
   - on Windows, the 'return' key was being called 'num_enter'
- videos were not running online `commit:9779579b6 <https://github.com/psychopy/psychopy/commit/9779579b60>`_ `commit:51b0824f7 <https://github.com/psychopy/psychopy/commit/51b0824f755>`_
- fixed rounding error in filtering of NoiseStim `commit:5d0e360d8 <https://github.com/psychopy/psychopy/commit/5d0e360d87b>`_
- iohub `waitKeys` should act like `getKeys` if maxWait<=0 `commit:e33f733f3 <https://github.com/psychopy/psychopy/commit/e33f733f317de>`_
- error if unicode items in the new Form class `commit:8287674f4 <https://github.com/psychopy/psychopy/commit/8287674f49a4c8>`_

ADDED:

- videos in Builder now have a `Loop playback` parameter
- Standalone distributions now include tobii-research package

PsychoPy 3.1.1
~~~~~~~~~~~~~~~~~~~~~~

ADDED:

- Added the loop playback parameter to Movie Components

FIXED:

- Microphone on windows failed if user didn't manually set pyo to be preferred lib. That isn't now needed `commit:700b72cd6 <https://github.com/psychopy/psychopy/commit/700b72cd6>`_
- pyo lib is now provided in the 64 bit Python3 Standalone (win)
- The new Keyboard class wasn't clearing all events when requested (e.g. at the beginning of stimulus onset) `#2442 <https://github.com/psychopy/psychopy/issues/2442>`_
- Parallel port lib in the Windows 32-bit version wasn't working (installed a new dll)
- OpenCV in Mac Standalone wasn't working (updated to be a package not a single file)
- Sounds with variable duration didn't stop properly `#2446 <https://github.com/psychopy/psychopy/issues/2446>`_
- Fix to JS output when useVersion was set to something
- Cedrus XID lib is now working on Python3 (although their official one is yet to come)

PsychoPy 3.1.0
~~~~~~~~~~~~~~~~~~~~~~

NEW:

- hardware.keyboard.Keyboard class, based on C code from the Psychtoolbox project (ported to Python by Mario Kleiner)
 - faster than `event.getKeys()` (polling is asynchronous with drawing loop and the calls go direct
   to the USB rather than going via the operating system key calls)
 - supports keyDuration fields as well as `rt` for key down time
- Form class for combining text items and responses (currently ratings and radio items) in a scrollable list
- each Builder Component is now outputting its start/stop times in the data file by default (can be turned
  off for )


PsychoPy 3.0
----------------

PsychoPy3 is the new phase of development including support for online studies
at the Pavlovia.org experiment server. Many of the features here are relatively
new and, although we have spent hundreds of hours developing and testing them
you should be more cautious than ever checking your experiment and data outputs.

PsychoPy 3.0.7
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- local project repeatedly asking to Create New Pavlovia project when one already exists `commit:c3f0d203f <https://github.com/psychopy/psychopy/commit/c3f0d203f>`_
- Fixed "No module named 'PyQt4'" on MacOS<10.10 caused by PyQt dropping support for Mac10.9 in PyQt5.9 `#2375 <https://github.com/psychopy/psychopy/issues/2375>`_
- don't allow movie->online to use units 'from experiment settings' `commit:8cbaf8a71 <https://github.com/psychopy/psychopy/commit/8cbaf8a713>`_
- Py3 string/byte fixes for CRS ColorCal `commit:3bf1b7e5d <https://github.com/psychopy/psychopy/commit/3bf1b7e5d4>`_ `commit:d49f154a0 <https://github.com/psychopy/psychopy/commit/d49f154a0>`_
- various fixes to Japanese translations

PsychoPy 3.0.6
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- `TrialHandler.next()` was accidentally removed by Python3 conversion and now added back in `commit:c44621ab0 <https://github.com/psychopy/psychopy/commit/c44621ab072ad>`_
- various fixes to iohub Python3 compatibility (especially for datastore)
- permit reading "xlsm" files as conditions files (Excel files with macros although these will be ignored by Python) `commit:9e11bfd61 <https://github.com/psychopy/psychopy/commit/9e11bfd61>`_
- added space key to the GlobalEventKeys `#2310 <https://github.com/psychopy/psychopy/issues/2310>`_
- fix to pating into Code Component with windows EOLs
- fixes to Japanese translation (and bug around saving Static Components in Japanese locale)
- packaging: PyQt package inside one of the Standalone distros was broken

PsychoPy 3.0.5
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- sounddevice backend not importing on systems that don't have readline `commit:a9bbe98b3 <https://github.com/psychopy/psychopy/commit/a9bbe98b3>`_
- better automated Pavlovia logging-in for users, based on project `commit:460889e5d <https://github.com/psychopy/psychopy/commit/460889e5d>`_
- faster auto-logging for changes involving numpy arrays (e.g. elexment arrays XYs) `commit:e5dfc9e7d <https://github.com/psychopy/psychopy/commit/e5dfc9e7d>`_
- fix paste when using legacy macOS end-of-lines (convert them to '\n' always) `commit:94c5ee6a2 <https://github.com/psychopy/psychopy/commit/94c5ee6a2>`_
- updated Japanese translations `#2292 <https://github.com/psychopy/psychopy/issues/2292>`_

PsychoPy 3.0.4
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- fixes to prevent stalled "Synchronizing..." message by preventing behaviours that would cause it `commit:8cadce02d <https://github.com/psychopy/psychopy/commit/8cadce02d>`_
- workaround to stop `sounddevice` backend from silencing `input()` `commit:1422fd7c9 <https://github.com/psychopy/psychopy/commit/1422fd7c9>`_
- prevent JS experiments being compiled with units of "use prefs" `commit:a686dbf52 <https://github.com/psychopy/psychopy/commit/a686dbf52>`_
- cleaner ioHub shutdown `commit:7a7751ca5 <https://github.com/psychopy/psychopy/commit/7a7751ca5>`_ and datastore `commit:209c4047f <https://github.com/psychopy/psychopy/commit/209c4047f>`_
- Slider in JS allows forceEndRoutine `commit:0694027b2 <https://github.com/psychopy/psychopy/commit/0694027b2>`_
- better error reporting when compiling scripts `commit:a01cb2982 <https://github.com/psychopy/psychopy/commit/a01cb2982>`_
- don't crash the app if no internet `commit:84b7602c3 <https://github.com/psychopy/psychopy/commit/84b7602c3>`_
- don't crash if scipy.optimize doesn't load `commit:0f8038629 <https://github.com/psychopy/psychopy/commit/0f8038629>`_
- set Slider label height to match tick height by default `commit:f8bdf2341 <https://github.com/psychopy/psychopy/commit/f8bdf2341>`_
- online sounds were never ending if duration was blank (now ends at end of file) `commit:6d91b3186 <https://github.com/psychopy/psychopy/commit/6d91b3186>`_
- problem converting EOLs between different formats when pasting code

ADDED:

- New Builder Pavlovia button to examine properties of current project
- Added star to ShapeStim (currently only in Python) `commit:8e6c40993 <https://github.com/psychopy/psychopy/commit/8e6c40993>`_
- Added tooltips for Pavlovia buttons

PsychoPy 3.0.3
~~~~~~~~~~~~~~~~~~~~~~

:noncompat:`CHANGED: Slight change to creation of *new* experiments, which will now default to`
the units of 'height' rather than 'use preferences' (which led to potential confusion
when the experiment moved to a different computer)

FIXED:

- Force End Routine wasn't working with Slider when online `commit:a0ca2e312 <https://github.com/psychopy/psychopy/commit/a0ca2e312>`_
- Fix to the online error about units: if an experiment is given units of "use preferences"
this will switch to height during HTML export `commit:a686dbf52 <https://github.com/psychopy/psychopy/commit/a686dbf52>`_
- First push of a new project to Pavlovia didn't note that remote now exists, so
tried to "first push" again `commit:f4134a670 <https://github.com/psychopy/psychopy/commit/f4134a670>`_
- fixed detection of correct non-response in JavaScript outputs (so no-go works online) `commit:0c3cea2b2 <https://github.com/psychopy/psychopy/commit/0c3cea2b2>`_
- added workaround for strange clash of `sounddevice` with `input()` `commit:f99bef4a9 <https://github.com/psychopy/psychopy/commit/f99bef4a9>`_
- various small fixes to iohub for Py3 `commit:e6a2169d6 <https://github.com/psychopy/psychopy/commit/e6a2169d6>`_ `commit:4ca503399 <https://github.com/psychopy/psychopy/commit/4ca503399>`_ `commit:cf432bc3c <https://github.com/psychopy/psychopy/commit/cf432bc3c>`_

ADDED:

- star available as a Shape in Builder (but not online yet)
- experiment info dialog now supports drop-downs to constrain options (e.g. ['male','female','other'] )
- BBTK now supports mode Digital Stimulus Response Echo `commit:5da328fcf <https://github.com/psychopy/psychopy/commit/5da328fcf>`_

PsychoPy 3.0.2
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- Builder's PsychoJS outputs were not updating their versions (pointing to the version the script was first created in, not the version currently used) `commit:789d24ee4 <https://github.com/psychopy/psychopy/commit/789d24ee45aa>`_
- sounddevice under Python2 had a bug with being unable to copy() `commit:c1317b6b6 <https://github.com/psychopy/psychopy/commit/c1317b6b6355e>`_
- now prevent the user from accessing `useVersion` if that version can't be supported by the current install (e.g. incompatible Python version or wx version)
- Windows Standalone version now includes dependency for [pyqmix](https://github.com/psyfood/pyqmix) pumps

PsychoPy 3.0.1
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- JS outputs were connecting to outdated PsychoJS version (3.0.0b11 instead of 3.0.0)
- updated numpy (to 1.15.4) and scipy (to 1.2.0) for windows installs using https://www.lfd.uci.edu/~gohlke/pythonlibs/ in the hope of fixing numpy problems for some windows boxes
- JS string values in Py27 were being convert to b'theString' in JS outputs which obviously broke JS

ADDED:

- Slider support from JS outputs

PsychoPy 3.0.0
~~~~~~~~~~~~~~~~~~~~~~

Although there were several beta versions preceding this, the changes described
below are the *broader* changes since 1.90.3 (the previous "stable" version).

NEW:

- supports heavily revamped PsychoJS library:
    - new PsychoJS supports text, images, keyboards, mouse, sounds, movies, sliders
    - you can also now include Builder Code Components that include both
      Python and JavaScript optional code so your components will work
      online too

- PsychoPy can search, sync and create experiments on Pavlovia.org:
    - search for existing studies
    - create your own
    - run (and collect data into csv files or mongoDB)
    - sync, including (push changes to the server and fetch back data)

- Additional new features:
  - Slider class, recommended replacement for RatingScale (more efficient, more
  flexible and simpler to use)
  - support for Oculus Rift (only on Windows 64bit Python 3) all due to Matthew
  Cutone

Many bugs have also been fixed, notably in terms of audio library problems and
memory problems with MovieStim3.


PsychoPy 3.0.0b7
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- New rating scale (Slider) handles color properly `#1944 <https://github.com/psychopy/psychopy/issues/1944>`_ and better handling of button drag `#1945 <https://github.com/psychopy/psychopy/issues/1945>`_
- 'newRating' Builder demo has been fixed (forceEndRoutine shouldn't have been happening)
- timeByFrames now renders the graph into the PsychoPy window (was sometimes hanging on mac otherwise)

PsychoPy 3.0.0b6
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- several sync problems with pavlovia.org: `commit:1f0d8bcab <https://github.com/psychopy/psychopy/commit/1f0d8bcab50c1528291adb3a689e95f6e3bf7fc5>`_
    - sync when an empty project already exists is now fine
    - after creating the project, changing a file and repeating sync, it didn't detect the changed file
    - sync to a project that has been deleted remotely now asks if you want to recreate the project
    - better reporting of error if sync fails

- further fix to memory leak in MovieStim3 `commit:9d0c127d8 <https://github.com/psychopy/psychopy/commit/9d0c127d8e6dfd6efba5f285bed93685980cd443>`_
- fix to PsychoJS output code: loops were not being compiled correctly `commit:6a8e700a3 <https://github.com/psychopy/psychopy/commit/6a8e700a350b660b6f588c5b902b04a736b023d2>`_
- when compiling to JS we now detect tuples and convert to lists for params (JS only has one sequence, with `[ ]` )

PsychoPy 3.0.0b4
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- some packaging issues on both Windows and Mac (e.g. updates to Pillow=5.2.0, soundfile=0.10.2) also fixes libsndfile error on Mac_Py2 standalone
- when the localRoot has been set for a project (before sync) we should get back the sync window
- clicking "runOnline" before creating/syncing your project with Pavlovia now does the right thing
- fix to MovieStim3 unloading of movies `#1917 <https://github.com/psychopy/psychopy/issues/1917>`_

PsychoPy 3.0.0b3
~~~~~~~~~~~~~~~~~~~~~~

FIXED:

- a further issue with the app not starting on some machines (due to the
  first-run wizard)
- searching pavlovia projects now support stars and forks in sorting
- Slider forceEndRoutine was having no effect
- sounddevice problem when playing a mono sound to stereo stream or vice-versa

ADDED:

- support for Oculus Rift (only on Windows 64bit Python 3) all due to Matthew Cutone
- Japanese translations to many of the new features/controls

PsychoPy 3.0.0b2
~~~~~~~~~~~~~~~~~~~~~~

FIXED: an issue with the app not starting (if git not installed)

PsychoPy 3.0.0b1
~~~~~~~~~~~~~~~~~~~~~~

PsychoPy3 is the new phase of development including support for online studies
at the Pavlovia.org experiment server. Right now this is BETA SOFTWARE. It WILL
contain bugs but we're fixing them as fast as we/you can find them!

NEW:

- supports heavily revamped PsychoJS library
    - new PsychoJS supports text, images, keboards, mouse and sounds
    - you can also now include Builder Code Components that include both
      Python and JavaScript optional code so your components will work
      online too

- PsychoPy can search, sync and create experiments on Pavlovia.org
    - search for existing studies
    - create your own
    - run (and collect data into csv files)
    - sync, including (push changes to the server and fetch back data)


PsychoPy 1.90
------------------------------

This is a very major refactor of many parts of the PsychoPy code. Treat very
carefully for the first few bug-fix releases as there are likely to be errors
some of which could be catastrophic to your data!!

This is the first attempt at support for Python 3, with maintained support for
Python 2.7. Note that both are available as Standalone packages for Win and Mac.
The Python3.6 version is labelled as Py3 in the download file.

Stick to Python 2.7 if you want your script to break less. If you upgrade to
Python 3 then you'll need to change any print statements to include brackets
and you may also get some new errors springing up about unicode/bytes objects.

PsychoPy 1.90.3
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released July 2018

FIXED:

* Fixes event code creation for Black Box ToolKit `#1830 <https://github.com/psychopy/psychopy/issues/1830>`_
* Removed redundant 'apply' button in preferences `#1832 <https://github.com/psychopy/psychopy/issues/1832>`_
* Fixes problem with setting gamma with pyglet v1.3+ `#1834 <https://github.com/psychopy/psychopy/issues/1834>`_
* Removes 'unknown color space' warning if user is using named colors `#1836 <https://github.com/psychopy/psychopy/issues/1836>`_
* Fixes refcount error, raised when monitor centre was closed `#1838 <https://github.com/psychopy/psychopy/issues/1838>`_
* For Py3, JSON calibration files are now loaded into monitor list `#1839 <https://github.com/psychopy/psychopy/issues/1839>`_
* Fixes layout problem with RTL locale causing broken dialogs in the app `#1840 <https://github.com/psychopy/psychopy/issues/1840>`_
* Anti-buzzing fix applied to sounddevice backend `#1847 <https://github.com/psychopy/psychopy/issues/1847>`_
* Implements checks for variable name clashes between builder and conditions file  `#1852 <https://github.com/psychopy/psychopy/issues/1852>`_
* Reduced code redundancy for _getRegionOfFrame, and can get single pixels from front buffer `#1854 <https://github.com/psychopy/psychopy/issues/1854>`_
* Hex color space can now be specified as a window setting in Experiment Settings `#1857 <https://github.com/psychopy/psychopy/issues/1857>`_
* Sound duration can now be specified in conditions files `#1858 <https://github.com/psychopy/psychopy/issues/1858>`_

PsychoPy 1.90.2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released May 2018

FIXED:

* TextStim now working GLFW backend `commit:a909c95f <https://github.com/psychopy/psychopy/commit/a909c95f>`_
* better checks for existing ffmpeg before trying to download `commit:a909c95f <https://github.com/psychopy/psychopy/commit/a909c95f>`_
* CRS Bits boxes bugs with Python3 `commit:ff5a4ab7 <https://github.com/psychopy/psychopy/commit/ff5a4ab7>`_
* Fixes to window position for Retina displays `commit:e7b111cc <https://github.com/psychopy/psychopy/commit/e7b111cc>`_ `commit:0d4538de <https://github.com/psychopy/psychopy/commit/0d4538de>`_
* Fixes to sound component with duration=None `commit:9b46ff0c <https://github.com/psychopy/psychopy/commit/9b46ff0c>`_
* Fix to Hex-specified colors `commit:6ffa413a <https://github.com/psychopy/psychopy/commit/6ffa413a>`_
* print(RunTimeInfo()) not working due to unicode/str error `commit:29de9501 <https://github.com/psychopy/psychopy/commit/29de9501>`_
* sounddevice stereo auto-detection wasn't working for wav files `commit:b07f8fb1 <https://github.com/psychopy/psychopy/commit/b07f8fb1>`_

PsychoPy 1.90.1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released April 2018

ADDED:

* Option to move Y position of `RatingScale` in code `#1776 <https://github.com/psychopy/psychopy/issues/1776>`_
* Added option of providing extra arguments to `scipy.optimize` functions when fitting from `psychopy.data` `#1772 <https://github.com/psychopy/psychopy/issues/1772>`_

FIXED:

* Problem with icon path in GLFW backend on linux `commit:bbf515216 <https://github.com/psychopy/psychopy/commit/bbf51521664>`_
* PUINT didn't exist in older `win32` package but was expected by `pyglet`
* Better handling of conditions file with empty columns (from Excel adding them or from missing headers)
* Several fixes to ioHub in Python3 `#1770 <https://github.com/psychopy/psychopy/issues/1770>`_ `#1771 <https://github.com/psychopy/psychopy/issues/1771>`_ and `#1775 <https://github.com/psychopy/psychopy/issues/1775>`_
* Mouse reporting incorrect position when using Mac Retina display `commit:54ced9c26 <https://github.com/psychopy/psychopy/commit/54ced9c2644e>`_
* `sounddevice` was failing to find `portaudio.dylib` on Mac


PsychoPy 1.90.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released March 2018

ADDED:

* Standalone distributions for Python 3.6 as well as Python 2.7
* Using `pip install psychopy` now installs all the necessary dependencies, making it much easier to install to your own Python installation
* Noise stimuli for presenting filtered noise in vision studies (thanks Andrew Schofield)
* Second order stimuli for contrast modulated gratings (thanks Andrew Schofield)
* Builder: Mouse now allows stimuli to be "clickable" turning them in to buttons
* Builder: ShapeStim now handles additional shapes, like Cross (also takes names for shapes rather than just n vertices)
* Monitors calibration files can now be saved/loaded in JSON format

:noncompat:`CHANGED:`

* Image stimuli given an image of None (or blank in Builder) will now not display anything, whereas they previously showed a blank white (or colored) patch. To get that behaviour you can set the image to be `color` (in Builder) or "color" (in code).


PsychoPy 1.85
------------------------------

PsychoPy 1.85.6
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A bug-fix release to solve a few machine-specific issues.

FIXED:
    * on some computers the data weren't being saved if user pressed 'Esc' during experiment. `commit:193ce541 <https://github.com/psychopy/psychopy/commit/193ce541>`_
    * fix for the "Unable to share contexts" error on machines that don't support OpenGL shadow_window `commit:a1c29d3a <https://github.com/psychopy/psychopy/commit/a1c29d3a>`_
    * pyo not always closing properly `#1614 <https://github.com/psychopy/psychopy/issues/1614>`_
    * problem with non-ascii characters in conditions file name `commit:32204a200 <https://github.com/psychopy/psychopy/commit/32204a200>`_
    * loading of preferences was failing if the audio backend wasn't a valid option `commit:c2d11477b <https://github.com/psychopy/psychopy/commit/c2d11477b5>`_
    * Builder demo images_blocks had wrong units for images `#1601 <https://github.com/psychopy/psychopy/issues/1601>`_
    * no longer tell people to upgrade if their version is *newer* than the "latest" `#1567 <https://github.com/psychopy/psychopy/issues/1567>`_
    * added support for newer PST box in ioHub (with 7 buttons not 5) `commit:b9534a288 <https://github.com/psychopy/psychopy/commit/b9534a28896>`_
    * Monitor.linearizeLums() was raising an error due to a change in import name
    * stimuli not switching correctly to desired window in multi-window setups `#1514 <https://github.com/psychopy/psychopy/issues/1514>`_
    * opencv movie backend had an error that `'float' object cannot be interpreted as an index` `#1510 <https://github.com/psychopy/psychopy/issues/1510>`_
    * cedrus box had error `AttributeError: 'ResponseDevice' object has no attribute 'status'` `#1493 <https://github.com/psychopy/psychopy/issues/1493>`_
    * retina displays had some bad scaling. Now strongly recommend using `retina=True` `commit:08163f78a <https://github.com/psychopy/psychopy/commit/08163f78a9c8ab9b>`_


PsychoPy 1.85.4
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Sept 2017

There was an error building the 1.85.3 release. Rather than building a bug-fix-inly release, version 1.85.3 has accidentally included some substantial code refactoring intended for the 1.86.0 release.

This version, which we will call 1.85.4 is to replace that 1.85.3 release and provides the same fixes (but not the code refactoring) that was intended in 1.85.3

PsychoPy 1.85.3
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2017

This release fixes several bugs but it does also add 2 new dependencies:

* `json_tricks` and `future` are bother required for this version
* these are paving the way for updating Python3 (which will be enabled in 1.86.x series of releases)

FIXED:
    * Problem with text stimuli on Windows not rendering if large (was a bug in pyglet, fixed in 1.3.0b1)
    * Whitespace/indentation guides were not toggling on/off correctly in Coder `commit:4ebbdb9c5 <https://github.com/psychopy/psychopy/commit/4ebbdb9c5468beebb50d817697c0665450e9a5ad>`_
    * Added status property to labjack U3 in Builder scripts `commit:b4d16d3d6 <https://github.com/psychopy/psychopy/commit/b4d16d3d6319d0edeb7a95e774ff60c0ea51a1cf>`_
    * Fix to iohub.launchHubServer() under Linux `commit:a9392f62e <https://github.com/psychopy/psychopy/commit/a9392f62e5e819788e77553583b6776d5992b849>`_
    * Fix to config file for iViewX on ioHub `commit:590fb20de <https://github.com/psychopy/psychopy/commit/590fb20de193fd85f66655c0983107a561f3f2d1>`_

PsychoPy 1.85.2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: June 2017

FIXED:
* several errors with **PsychoJS** outputs from Builder (mostly thanks to Jon Roberts at Colorado):
    * nReps and randomisation now being handled correctly by PsychoJS `commit:ad9a931 <https://github.com/psychopy/psychopy/commit/ad9a931>`_
    * "correct" responses were being overwritten by non-responses `commit:f903210 <https://github.com/psychopy/psychopy/commit/f903210>`_
    * Text components that were static caused a crash (were erroneously given two single-quotes) `commit:b399a50 <https://github.com/psychopy/psychopy/commit/b399a50>`_

* Staircase would finish prematurely if nReversals was None `commit:7148cad <https://github.com/psychopy/psychopy/commit/7148cad>`_
* PsychoPy would crash if sound device contained a unicode character `commit:c1ff68f <https://github.com/psychopy/psychopy/commit/c1ff68f>`_
* FrameBufferObject not working correctly for dual-window setups `commit:5e1c045 <https://github.com/psychopy/psychopy/commit/5e1c045>`_
* removed some annoying junk messages about sounddevice `commit:e5ae2fc <https://github.com/psychopy/psychopy/commit/e5ae2fc>`_

PsychoPy 1.85.1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: April 2017

FIXED:
- several errors with **PsychoJS** outputs from Builder:
    - early termination of experiments `commit:f1bd15047 <https://github.com/psychopy/psychopy/commit/f1bd15047>`_
    - incorrect blank email field in info.php `commit:d68c36bf9 <https://github.com/psychopy/psychopy/commit/d68c36bf9>`_
    - incorrect component name sin endRoutine `commit:e47d90a36 <https://github.com/psychopy/psychopy/commit/e47d90a36>`_
    - incorrect default units for image stims `commit:8c32d1c9a <https://github.com/psychopy/psychopy/commit/8c32d1c9a>`_

- several problems with **sound**:
    - pyo not loading `#1365 <https://github.com/psychopy/psychopy/issues/1365>`_
    - searching for 'auto' instead of 'default' device `commit:d54d14fe <https://github.com/psychopy/psychopy/commit/d54d14fe>`_
    - fixed duration calculation (bug in soundfile) for sounddevice `commit:e0e01ad <https://github.com/psychopy/psychopy/commit/e0e01ad>`_

- textbox v textstim demo wasn't working `commit:b2913c124 <https://github.com/psychopy/psychopy/commit/b2913c12476>`_

- error with colors when using TextStim with blendmode='add'

- errors in installer package:
    - windows installer could overwrite system path setting
      rather than append (NSIS short-string problem came back!)
    - freetype 32 bit dll is being provided again (was in matplotlib
      before but disappeared?)

PsychoPy 1.85.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Feb 2017

ADDED:
    * `Online experiments now supported <https://www.psychopy.org/online/online.html>`_ using new `PsychoJS library <https://github.com/psychopy/psychopy/tree/master/psychojs>`_. See what is supported so far at `PsychoPy online status <https://www.psychopy.org/online/status.html>`_
    * New sound engine using `sounddevice <https://github.com/spatialaudio/python-sounddevice/>`_
    * Checking of image paths for stimuli (did you forget to add ".jpg"?)
    * Copy/paste of a Component is now possible in Builder (right-click the component to copy, use the Experiment menu to paste). This essentially duplicates the component.

FIXED:
    * crash when increasing size of Flow in Builder `#1272 <https://github.com/psychopy/psychopy/issues/1272>`_
    * bug in pysoundcard backend preventing file-based sounds playing `#1299 <https://github.com/psychopy/psychopy/issues/1299>`_
    * excel outputs were failing to save on new versions of openpyxl `#1276 <https://github.com/psychopy/psychopy/issues/1276>`_
    * `useVersion()` was not fetching new (uninstalled) versions correctly `#1301 <https://github.com/psychopy/psychopy/issues/1301>`_
    * DotStim now has the option to reset the dots at the beginning of a trial `commit:db6f53d50 <https://github.com/psychopy/psychopy/commit/db6f53d50>`_
    * better handling of blank cells in Excel conditions files (and xls files now supported)
    * Excel conditions files now import the "value" of a cell rather than the formula `commit:7f753f5 <https://github.com/psychopy/psychopy/commit/7f753f5>`_

DEPENDENCIES/PACKAGING:
    * pyserial and pyxid were incompatible versions
    * now packaging 1.2-maintenance branch of pyglet including Text memory fixes

PsychoPy 1.84
------------------------------

PsychoPy 1.84.2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Sept 2016

FIXED:
    * Problem with renaming of Routines preventing experiment from re-loading `#1248 <https://github.com/psychopy/psychopy/issues/1248>`_
    * Several bugs with Builder code generation since PEP8 refactoring:
        * Static Components gave error compiling script
        * some Keyboard Components (with variable "allowed keys" settings) gave error compiling script `#1245 <https://github.com/psychopy/psychopy/issues/1245>`_
        * Mouse Component with "Save state at end of trial" gave indentation error `#1253 <https://github.com/psychopy/psychopy/issues/1253>`_
        * Loops gave error compiling script if conditions file was a formatted string `#1253 <https://github.com/psychopy/psychopy/issues/1253>`_

    * Standalone distributions were not including the correct `pylink 1.1.0.4` and `pyxid` packages

ADDED:
    * Keyfinder demo to Builder view `#1252 <https://github.com/psychopy/psychopy/issues/1252>`_
    * Support for key modifiers using `event.getKeys()` `#1242 <https://github.com/psychopy/psychopy/issues/1242>`_

PsychoPy 1.84.1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Sept 2016

FIXED:
    * Builder Keyboard component was treating non-response as correct answer. `#1230 <https://github.com/psychopy/psychopy/issues/1230>`_ Thanks Jarrod
    * MovieStim2 (opencv) now compatible with newer versions of opencv (v3.x) `#1223 <https://github.com/psychopy/psychopy/issues/1223>`_
    * SSL certificates for OS X causing failure to connect to osf.io for projects
    * dependencies added/updated in Standalone packages:

        * pyHook, pygame, pylink 0.3.2,  (win32)
        * pysoundcard (OS X)

    * hello_world demo crashing the app on load

ADDED:
    * Movie **outputs** in gif, mp4, mov formats automatically, using moviepy `#1228 <https://github.com/psychopy/psychopy/issues/1228>`_

PsychoPy 1.84.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2016

ADDED:
    * :ref:`Projects menu <projects>`, which can sync files with Open Science Framework
    * Movies in Builder can now avoid loading audio (i.e. mute). As well as meaning your movie is genuinely silent this saves processing for the computer, so do it unless you need the sound!
    * menu item to create a .csv (data) file from a .psydat file; see Coder > Tools menu (also: Coder > Demo menu)
    * Builder experiments force a save before the end of the study so pressing the red stop button is less likely to lose data for you
    * You can now **rename a Routine** `#1136 <https://github.com/psychopy/psychopy/issues/1136>`_
    * a Builder experiment setting to specify the version of PsychoPy to be used when running the experiment `#1137 <https://github.com/psychopy/psychopy/issues/1137>`_

:noncompat:`CHANGED:`

    * MAJOR REFACTOR: A lot of code has been refactored to be more in line with a thing called PEP8. If that doesn't mean anything to you don't worry, it shouldn't affect you. If you like that sort of thing, sorry we didn't got further and get rid of camelCase. ;-)
    * setting ShapeStim vertices dynamically now requires an explicit assignment of the new vertex list to shape.vertices; this can be slow for filled shapes with many vertices. See shapes.py, selfx example.
    * Some file names and locations have changed. To update, replace OLD form in your scripts with NEW form:

      * OLD form --> NEW form
      * Deprecated since 2012, must now update:
        * `from psychopy import calib` --> `from psychopy import monitors as calib` (or just use `monitors`)
        * `from psychopy import bits` --> `from psychopy.hardware.crs import bits`
        * `from psychopy import log` --> `from psychopy import logging`
      * Newly deprecated (the old way still works but logs a warning):
        * `from psychopy import _shadersPyglet` --> `from psychopy.visual import shaders`
        * `from psychopy import gamma` --> `from psychopy.visual import gamma`
        * `from psychopy import filters` --> `from psychopy.visual import filters`
      * API change (only affects people who write their own Builder components):
        * `from psychopy.app.builder.components._visual import VisualComponent` --> `from psychopy.app.builder.components._base import BaseVisualComponent`

    * PyQt is now default over wx for dialog boxes (if either PyQt4 or PyQt5 are installed). Also fixed bug to support PyQt5
    * No Static Components are created by default (e.g. ISI). Have to add them manually

IMPROVED:
    * ShapeStim can properly fill arbitrary shapes (using tessellation); see new shapes.py Coder demo for examples.
    * Coder view now has better support for Retina display on OSX. visual.Window also has a new option to use retina for rendering in the experiment (off by default)
    * better warnings about VLC being wrong architecture for this python install
    * Code Components now indicate which ones actually contain code. `#1204 <https://github.com/psychopy/psychopy/issues/1204>`_

FIXED:
    * bug with Monitor center not creating/saving monitor due to lack of SizePix `#1208 <https://github.com/psychopy/psychopy/issues/1208>`_
    * window viewScale and viewPos combine correctly; viewScale handles negative values, mirror-image flips the window correctly (except for Text)
    * Builder experiments will always add their extension (to stop people overwriting them with the python script of the same experiment)
    * faster writing of multiple lines (bits) to the LabJack
    * sampling rate when using binocular mode in eyelink 1000 `#1146 <https://github.com/psychopy/psychopy/issues/1146>`_
    * Aperture now supports infinite durations in Builder `#1122 <https://github.com/psychopy/psychopy/issues/1122>`_
    * ColorCal II now supports newer pyserial version `#1138 <https://github.com/psychopy/psychopy/issues/1138>`_
    * Erroneous extra data column added if experiment was aborted `#1115 <https://github.com/psychopy/psychopy/issues/1115>`_
    * Ubuntu buglet with importing iohub devices caused by outdated psutils `#1172 <https://github.com/psychopy/psychopy/issues/1172>`_

PsychoPy 1.83
------------------------------

PsychoPy 1.83.04
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Feb 2016

* FIXED:
  * Mac Standalone was (still) not launching on some versions of OSX
  * MovieStim3 not working on all graphics cards (glPopAttrib). Thanks Bryan Cort and Frank Papenmeier for their help
  * MovieStim3 bug with movies that had no audio stream
  * Data saving is forced at the end of Builder Experiments even if script fails to exit properly (red stop button less likely to lose data)
  * Setting gamma on OSX 10.11 wasn't working (Apple moved the lib to a new location). `#1089 <https://github.com/psychopy/psychopy/issues/1089>`_
  * Option to turn off audio in Movies from Builder when not needed (better performance and fewer shutdown-probs)

PsychoPy 1.83.03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Dec 2015 (NB 1.83.02 was never publicly released)

* FIXED:
  * problems with the Mac Standalone failing to launch on some OSX versions
  * reduced impact of pyglet text memory leaks (make fewer updates). (NB There is still a leak in Pyglet's code that we can't fix)
  * several fixes to RatingScale
  * window viewScale and viewPos combine correctly; viewScale handles negative values, mirror-image flips the window correctly (except for Text) `#1011 <https://github.com/psychopy/psychopy/issues/1011>`_
  * fixed memory leak in sounds on 64bit Mac installation (error in pyo)
  * MovieStim3 was interacting badly with ShapeStim `#981 <https://github.com/psychopy/psychopy/issues/981>`_
  * MovieStim3 was failing if no audio stream was present in the file `#984 <https://github.com/psychopy/psychopy/issues/984>`_
  * PsychoPy app now gives a warning message if it can't start due to permissions error `#1055 <https://github.com/psychopy/psychopy/issues/1055>`_
  * Faster rendering of MovieStim2 and Moviestim3 due to removal of mipmapping code

PsychoPy 1.83.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Oct 2015

* FIXED:
  * new bug with pygame sounds giving fileName not defined
  * several RatingScale bugs; reduce the memory leak (due to pyglet as used in TextStim)
  *
* ADDED: voice-key capability, e.g., for word-naming studies; includes a demo, auxiliary functions (smoothing, zero-crossing, etc), and file-format options (all those supported by pyo)
* :noncompat:`CHANGED: remove support for google's speech to text (the new google API is for chrome / chromium developers only)`
* :noncompat:`CHANGED: deprecate psychopy.web.upload(); use the requests package instead: requests.post()`

PsychoPy 1.83.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Oct 2015

* ADDED: MovieStim3 using an alternative backend that doesn’t require avbin, vlc or streamer. It just uses a couple of python libs and FFMPEG, which are relatively easy to package. Seems to have good performance too but this needs more testing
* IMPROVED: speed to load psychopy.visual (“lazy loading” only the stimuli you use are loaded)
* ADDED: RatingScale precision=60 allows display of time-based values (min:sec or hours:min). Values from .getRating() are decimal proportions (1 min: 59 seconds -> 1.9833 minutes).
* ADDED: Coder view can now be set to read-only mode to prevent subjects accidentally altering study `#945 <https://github.com/psychopy/psychopy/issues/945>`_
* ADDED: TextStim now has property `boundingBox` telling you the maximum area of the letters (defined by the font, not by the actual rendered letters) `commit:35c168f1 <https://github.com/psychopy/psychopy/commit/35c168f1>`_
* ADDED: Aperture can now be created using images (anything that worked with ImageStim) `#923 <https://github.com/psychopy/psychopy/issues/923>`_ and can also be inverted so that opaque becomes transparent and vice versa `#922 <https://github.com/psychopy/psychopy/issues/922>`_ Thanks Thomas Emerling for both
* ADDED: New visual stimulus EnvelopeGrating for contrast-modulated gratings. Thanks Andrew Schofield
* ADDED: option to set mouse_exclusive mode (mouse locked to the window boundary and invisible) Thanks Suddha Sourav `#898 <https://github.com/psychopy/psychopy/issues/898>`_
* FIXED: DotStim can now change field size on the fly
* FIXED: several (but probably not all) annoying error messages that were unimportant
* FIXED: Condition file in Builder no longer abbreviated. Thanks Mike `#913 <https://github.com/psychopy/psychopy/issues/913>`_

PsychoPy 1.82
------------------------------

PsychoPy 1.82.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2015

    - FIXED: TrialHandler wasn't saving extraInfo (was overwritten during trials) `#815 <https://github.com/psychopy/psychopy/issues/815>`_
    - FIXED: don't have pickle file re-saving itself when it comes back from pickling `#833 <https://github.com/psychopy/psychopy/issues/833>`_
    - FIXED: Mouse Component could crash data saving if no response was made `#839 <https://github.com/psychopy/psychopy/issues/839>`_
    - FIXED: memory leaks in MovieStim2 (opencv backend) `#838 <https://github.com/psychopy/psychopy/issues/838>`_ and `#919 <https://github.com/psychopy/psychopy/issues/919>`_
    - FIXED: checked that window positions are integers `#854 <https://github.com/psychopy/psychopy/issues/854>`_
    - FIXED: OSX "10.10" incorrectly looked older than "10.9" `#866 <https://github.com/psychopy/psychopy/issues/866>`_
    - FIXED: RatingScale would show "False" for scale description in some cases `#870 <https://github.com/psychopy/psychopy/issues/870>`_
    - FIXED: problem with microphone saving files that end with w, a or v `#875 <https://github.com/psychopy/psychopy/issues/875>`_
    - FIXED: MonitorCenter failing to create new monitor `#887 <https://github.com/psychopy/psychopy/issues/887>`_
    - FIXED: universal line endings in csv outputs files `#889 <https://github.com/psychopy/psychopy/issues/889>`_
    - FIXED: unicode in conditions files `#892 <https://github.com/psychopy/psychopy/issues/892>`_
    - FIXED: `iohub` not detecting Linux mouse events `#894 <https://github.com/psychopy/psychopy/issues/894>`_
    - FIXED: if output file is set to be `stdout` this should then be closed `#902 <https://github.com/psychopy/psychopy/issues/902>`_
    - FIXED: don't abbreviate the path name of conditions files `#913 <https://github.com/psychopy/psychopy/issues/913>`_
    - FIXED: minor error in logging for `rush()` under win32 `#914 <https://github.com/psychopy/psychopy/issues/914>`_
    - FIXED: unicode issues in user preferences panel `#930 <https://github.com/psychopy/psychopy/issues/930>`_ `#932 <https://github.com/psychopy/psychopy/issues/932>`_
    - FIXED: MonitorCenter won't lock you out if given an invalid screen number `#937 <https://github.com/psychopy/psychopy/issues/937>`_
    - FIXED: mono++ mode in CRS Bits++/#/Display++ is now using full dynamic range (previously 8bit blue gun overlay was overriding the 16bit screen buffer)

PsychoPy 1.82.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Feb 2015


PsychoPy 1.82.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Feb 2015

* FIXED: problem with MovieStim2 showing black box instead of movie on certain systems
* FIXED: problem with Tobii eye tracker not closing calibration window (Sol)
* FIXED: better timing for non-slip routines that follow dynamic routines (Jeremy) `#822 <https://github.com/psychopy/psychopy/issues/822>`_
* FIXED: problem with stimuli (e.g. shapes) not appearing if a texture had just been created and not yet drawn
* FIXED: pygame sound engine complained about "global variable loops not defined"
* ENHANCED: Filename collision handling for ExperimentHandler (Richard Höchenberger)
* :noncompat:`CHANGED: for text data outputs that give delim='\t' the file extension '.tsv' is added instead of '.dlm' (Richard Höchenberger)`


PsychoPy 1.82.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Jan 2015

* ENHANCED: slightly faster rendering of movies for high-rate HD stimuli
* :noncompat:`CHANGED: 'pandas' is now a strict requirement for the 'psychopy.data' module`
* FIXED: Builder sounds from file no longer loop indefinitely
* FIXED: Builder: microphone recordings are explicitly stopped at the end of every trial
* FIXED: Static Components could become hidden by having unknown durations and then couldn't be changed. Now they are always shown even when times are unknown (Jeremy)
* ADDED: improved support for Cambridge Research Systems Display++ and Bits# devices:

    * Color++ and Mono++ modes now supported using shaders
    * fixed some bugs with search for identityLUT in Display++

* ADDED: Psi adaptive staircase method (thanks Joseph Glavan for writing this)
* ADDED: `bidi` and `xlwt` packages to the Standalone distribution
* ADDED: support for Mouse.setPos() under pyglet back end (Jeremy)
* ADDED: support for PST response box (Richard Höchenberger)
* FIXED: extraInfo was not being saved in wide-text format
* FIXED: Builder was not respecting order for drawing polygon - it was always drawn first
* ADDED: Builder now supports 'degFlat and 'degFlatPos' units and documentation has been added for these

PsychoPy 1.81
------------------------------

PsychoPy 1.81.03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Dec 2014

* ADDED: Sounds in Builder can now have a duration set by a variable (changing each repeat). The work on this may cause some systems to have a periodic 'tick' in the sound if they last longer than 10s (probably dependent on sound card and driver)
* IMPROVED: RatingScale will always display a custom description ('scale') if provided by the user
* ADDED: Monitor Center can now calibrate non-primary monitors
* FIXED: components in Builder can now be 'stopped' at the same time as they are started and never show up (previously at least one frame was always required)
* FIXED: several issues with Bits++ causing a rendering glitch and not being able to calibrate from Monitor Centre
* FIXED: choice selection boxes stopped working in monitor centre (caused by hardware.crs.bits importing pyglet.gl)
* FIXED: Bits# can be set to do gamma correction in the PsychoPy LUT ('software') rather than using the on-board gamma table file ('hardware')
* FIXED: bug with monitor calib files not returning their linearization method correctly
* ADDED: psychopy.qtgui as alternative to gui which doesn't duffer from problem with choice boxes and pyglet clashing (thanks Sol)
* FIXED: data files now correctly include the originPath (the path to the script that created them). Thanks Alex Holcombe for the fix

PsychoPy 1.81.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Oct 2014

* FIXED: bug with gamma not being set from the Monitor file
* FIXED: MovieStim2 warnings about dropped frames were crippling the output window
* FIXED: new issue (in 1.81.01) with several drop-down menus in Builder not allowing to select that option

PsychoPy 1.81.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Oct 2014

* FIXED: bug with rendering of Movies from Builder (autoDraw() not working)
* ADDED: option to use new movie backend from Builder (there is now an option to select `opencv` or `avbin` for movie rendering)
* FIXED: if MovieStim2 couldn't load frames fast enough it ran slow (should drop frames but stay synchronised). (Sol)
* FIXED: fix spurious warnings about GratingStim.__del__
* FIXED: pyo audio crashed on windows if no mic/input was found (Sogo Hiroyuki)
* ADDED: serial port device in iohub (Sol)

PsychoPy 1.81.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Sept 2014

* IMPROVED: cross-version compatibility:

    * In Builder experiments from 'future' versions can be opened and unknown objects will be ignored (but kept)
    * In Code you can now do `import psychopy; psychopy.useVersion('X.XX.XX')` to switch to any version greater than 1.76.00 (including versions not installed and future versions). This only affects the lib, not the application. (Thanks Erik Kastman for most of the work on this)

* IMPROVED: better unit tests for visual stimuli to prevent future bugs
* :noncompat:`CHANGED: MovieStim was right-left flipping movies and this has been corrected. If you had been working around that by setting flipVertical=True then you'll need to undo that correction`
* IMPROVED: Can now select a subset of conditions in Builder loops and in `data.importConditions()` function (thanks Mike MacAskill for help)
* IMPROVED: In Builder, loops that don't reflect trials (e.g. stimuli within a trial or blocks of trials) can be flagged as such, resulting in neater data files
* ADDED: support for additional hardware:

    * basic support for interacting with BlackBoxToolkit v2 psychopy.hardware.bbtk
    * :noncompat:`CHANGED: added basic support for CRS Bits# in psychopy.hardware.crs. New way to interface with Bits++ as well, using a class rather than a Window argument. See demo in demos>hardware`
    * labjack digital outputs can be used as a Parallel Port Component in Builder
    * the screen rendering can now include a warping step to simulate spherical, cylindrical or custom warping (Jay Borseth)
    * the screen now supports 'frame packing' whereby sequential frames can be packed into one, as the red, green and blue channels for monochrome high-rate projectors (Jay Borseth)
    * ioHub eye tracker interface for GazePoint GP3 (Martin Guest)
    * ioHub Serial device:

        * Support for simple fixed width or marker delimited serial rx stream -> device event parsing.
        * Demo created showing usage with PST Response box added (Richard Höchenberger)
    * ioHub ioSync device:

        * Use Teensy 3.0 / 3.1 MCU. Connect via USB 2.0.
        * 8 / 8 digital inputs / outputs
        * 8 analog inputs (~12 - 13 bit effective resolution)
        * 1000 Hz sampling rate for analog and digital inputs.
        * Keyboard Host support (useful for testing keyboard delay variability from software alone)

* IMPROVED packaging:

    * can now install on OSX using miniconda/anaconda distribution (Erik Kastman)
    * pyopencv (cv2) added to Standalone as an alternative to avbin
    * PySoundCard and PySoundFile added to Standalone
    * psutil added to Standalone
    * application is now compatible with wxPython 2.8, 2.9 and 3.0

* ADDED: MovieStim2 stimulus type. Compared to MovieStim, improved performance and wider range of media encoding support has been reported from testing feedback on all OS's.
* IMPROVED: stimulus attributes:

    * Nearly all stimulus attributes now support new syntax, e.g. `stim.pos = [0,0]` as well as the previous `stim.setPos([0,0])`. All docs are update to reflect this change.
    * All numeric stimulus attributes now support operations. Use e.g. `stim.pos += [0,0.5]`. Read more in :ref:`Operations <attrib-operations>`.
    * Many more stimulus attributes can now be set after initialization. They have the same name as the init parameters. E.g. `stim.win = mySecondWindow` changes which Window the stimulus is drawn to

* IMPROVED: logging

    * :noncompat:`CHANGED: 'log=None' and 'autoLog=None' inherits from parents, with 'visual.Window' at the top of the hierarchy. None is now default for all stimuli and setter methods.`
    * FIXED: removed unnecessary (e.g. duplicate) logging.
    * IMPROVED: unnamed stimuli are now given a default name in the logs for easier identification, e.g. "unnamed ShapeStim".

* IMPROVED: you can now specify the standard deviation (default=3) for gaussian mask in various stimuli by setting e.g. `maskParams={'sd':5}` during init or after init.
* ADDED: language localization (Builder and Coder)

    * Can now display the app menus, tooltips, and so on in a language other than US English (selectable via prefs -> app -> locale)
    * Almost all displayed text can be translated (Jeremy Gray, Hiroyuki Sogo)
    * A Japanese translation is available (Hiroyuki Sogo)
    * Other translations will be easy to add; see online developer notes on using Poedit

* IMPROVED: psychopy.ioHub

    * :noncompat:`CHANGED: Keyboard device and events are more user-friendly.`
      Note: This release is not backwards compatible with earlier versions of the ioHub Keyboard device or event data file.
      Please see documentation for details.
    * Backend integration between iohub and psychopy continues to improve.
    * ioHub can now be used in OS X 10.9 with PsychoPy Coder. NOTE: Must add Coder app to accessibility list.
    * Several bug fixes.

* FIXED: several other minor bugs (that would have given exceptions if encountered). Thanks particularly to Philip Wiesemann for finding several of these
* FIXED: machines that didn't support shaders or framebuffer objects were raising an error on win.flip() if the useFBO argument was not manually set to False. Machines that don't support the new rendering methods are now handled more gracefully

PsychoPy 1.80
------------------------------

PsychoPy 1.80.08
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2014

FIXED: bug with using numpy arrays as masks; they were being interpreted as floats but should have been bytes


PsychoPy 1.80.07
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2014

FIXED: bug with timing of keys when using the `timestamped` argument

PsychoPy 1.80.06
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: June 2014

* FIXED: problem with using the framebuffer object (nothing was rendered at all)
* ENH: added support for using a stencil when the framebuffer object is turned on

PsychoPy 1.80.05
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: June 2014

* IMPROVED: better unit tests for visual stimuli to prevent further regressions of the issues below
* FIXED: machines that didn't support shaders or framebuffer objects were raising an error on win.flip() if the useFBO argument was not manually set to False. Machines that don't support the new rendering methods are now handled more gracefully.
* FIXED: further fixes to greyscale coloring (some images were not correctly detected as greyscale by PIL so tests weren't working)
* FIXED: machines that didn't support shaders or framebuffer objects were raising an error on win.flip() if the useFBO argument was not manually set to False. Machines that don't support the new rendering methods are now handled more gracefully
* FIXED: named colors were not interpreted correctly by the visual.Window (but worked fine for stimuli)
* FIXED: the error message about TextBox/FontManager not working doesn't show up any more
* FIXED: reinstated the requirement that wx is version 2.8.x only until we get time to check 3.0 compatibility more deeply

PsychoPy 1.80.04
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: April 2014

* FIXED: buglets in logging. Logging wasn't encoding unicode correctly for console targets (but file targets were OK) and some duplicate messages were occurring for stimulus autologs
* FIXED: buglet with GratingStim/PatchStim when texture was not a square power of two (was crashing due to incorrect global variable)
* FIXED: ElementArrayStim was not updating its position using .setFieldPos()

PsychoPy 1.80.03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: April 2014

* FIXED: Shader code was ignoring opacity setting for ImageStim
* FIXED: Mouse clock was not the same as PsychoPy's general events clock (so out of sync) (Sol & Jeremy)

PsychoPy 1.80.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: April 2014

* FIXED: ImageStim did not use its mask on some machines (nVidia and ATI?) or did not render at all on others (intel graphics?)
* :noncompat:`CHANGED: Sound object now checks if the sound is a note name before checking for file names (only affects cases where the file name was something like A.wav)`
* ADDED: Aperture now supports contains() and overlaps() methods
* ADDED: Image/Grating masks can now also be 'cross' (Suddha Sourav)
* FIXED: Unicode problem for microphone on non-English installs of win32
* FIXED: StairHandler first reversal now changes step size correctly and added option not to use the initial 1-up,1-down regime (Jon maintains that you should though!) (thanks Nathanael Larigaldie)
* FIXED: emulator LaunchScan uses new RatingScale syntax

PsychoPy 1.80.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Mar 2014

* FIXED: buglet with movie glPopAttrib() on Intel gfx cards (thanks Bryan Cort)
* FIXED: problem trying to use FrameBufferObject (FBO) on Intel GMA graphics cards
* FIXED: problem with ImageStim not respecting setColor() and setContrast()
* FIXED: some stimuli were failing to switch to a second window when requested
* FIXED: some rendering glitches with ShapeStim caused by interpolation settings (thanks to Soyogu Matsushita for finding this fix)
* FIXED: automated import of gamma for known monitors, which was failing on some monitor calibration files
* FIXED: a single-line conditions file is now imported correctly by Builder (Jeremy Gray)
* IMPROVED: a Routine not included in a loop now saves its data to a default 'loop' (Jeremy Gray)
* IMPROVED: Coder checks for consistency of end-of-line options (thanks Wilbert van Ham)

PsychoPy 1.80.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Mar 2014

* Improvements to user interface:

    * the glitch that prevented scrolling the Routine view is gone (win32)
    * dialog boxes in the Builder now have tabs for categories of controls
    * Code Components have much more space for each piece of code (again due to tabs)

* ADDED: In Builder you can now customise the data filename/path in the Experiment Settings. Any variables in the `expInfo` dialog box can be used to create this path. See :ref:`dataFileName` for further info
* ADDED: support for advanced rendering modes. Can now 'add' rather than average when using transparency. This is better for visual compound stimuli like plaids, and essential for colored anaglyph stimuli where the resulting image needs to be the sum of the left and right eye images.
* ADDED: new visual unit options: 'degFlatPos' and 'degFlat' provide more accurate conversions from degrees to pixels for drawing stimuli (although they're more accurate, accounting for the flat screen, they may look strange because 1 degree gets larger with greater eccentricity on a flat screen). The previous unit 'deg' still exists and remains default as, for many studies, these are expected
* ADDED: wider support for the functions `contains` and `overlaps`. Most stimuli now have these methods. Also they can now be used irrespective of whether the stimulus and other object have the same units (they used only to work for units of pix)
* ADDED: support for other shapes in the Aperture stimulus (and its Builder Component). You can either specify the number of vertices `nVert` and a `size` to get a regular polygon aperture, or you can provide a set of arbitrary vertices as your `shape` argument
* :noncompat:`CHANGED: Size of 'square' or 'triangle' apertures used to represent the radius of the circle on which their vertices lay. It is now a height/width as you would more likely expect. This means aperture code in scripts may need rewriting to be smaller.`
* IMPROVED: stimulus duration is now more precise when using `duration (s)` or `time (s)` although using `nFrames` option is still advised for brief stimuli
* IMPROVED: there are now fewer irrelevant lines in the log file as stimuli are initially created
* IMPROVED: Staircase loops in Builder now initialise just before the staircase is run, rather than at the start of the experiment. This means they can be controlled by an outer loop and, effectively, restarted
* FIXED: ElementArrayStim can take Nx3 or 1x3 values for colors again
* FIXED: variable names in Builder are now case-sensitive again (they were being forced to lower case when importing csv files)
* FIXED: incorrect equation for the Cumulative Normal fitting function
* FIXED: If your variable had a new line character in it this was causing a new line to be started in the csv data file. These are now handled correctly

* ADDED: RatingScale markerStart position can be arbitrary, e.g., can start between items or beyond the end of scale
* ADDED: RatingScale tickHeight can be used to control the height of tickMarks, including no tick marks (tickHeight=0)
* ADDED: RatingScale marker='hover' is similar to HTML-style hovering over clickable elements

*psychopy.visual.RatingScale Changes* :

* :noncompat:`CHANGED: Builder: remove option: choiceLabelsAboveLine; change lowAnchorText, highAnchorText -> labels`
* :noncompat:`CHANGED: skipping a rating now adds None as the final element in the history`
* :noncompat:`CHANGED: the default minTime is shorter, now 0.4s`
* :noncompat:`CHANGED: more info in the log when creating a rating scale object`
* :noncompat:`CHANGED: removed showAnchors: now use labels=None (instead of showAnchors=False)`
* :noncompat:`CHANGED: removed lowAnchorText & highAnchorText: now use labels=['leftAnchor', 'rightAnchor'] or with optional 3rd midpoint label`
* :noncompat:`CHANGED: renamed several parameters: stretchHoriz -> stretch, textSizeFactor -> textSize, ticksAboveLine -> tickHeight, displaySizeFactor -> size, markerStyle -> marker, customMarker -> marker`
* :noncompat:`CHANGED: removed showScale: now use scale=None (instead of showScale=False)`
* :noncompat:`CHANGED: removed allowSkip: now use skipKeys=None (instead of allowSkip=False)`
* :noncompat:`CHANGED: removed escapeKeys; no longer supported but it's easy to implement (as now done in the coder demo)`

PsychoPy 1.79
------------------------------

PsychoPy 1.79.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Dec 2013

* FIXED: startup crash in 1.79.00
* FIXED: long-standing memory leak in MovieStim
* FIXED: fixed problem with MovieStim not displaying the image but playing the audio
* ADDED: volume attribute to MovieStim (Frank Papenmeier)
* FIXED: experiments were crashing if first line of a conditions file contained a float but the rest were integers
* FIXED: QuestHandler.addResponse() should not try to replace existing intensity on first trial (Richard Höchenberger)
* FIXED: Window's viewPos and viewScale attributes could not be changed
* FIXED: Builder code generation for Cedrus Box when user provided a limited set of available buttons
* FIXED: multiple issues causing fatal errors when setting stimulus parameters (Pieter Moors and Damien Mannion)
* FIXED: Builder experiments would crash under certain conditions when there was no 'participant' in the info dialog box (Philipp Wiesemann)
* FIXED: bug toggling readme file window in Builder (Philipp Wiesemann)
* FIXED: further fix to the Coder raising excessive 'this file has changed' warnings
* FIXED: Component names now update on the Routine panel after being changed in a dialog (Philipp Wiesemann)
* FIXED: bug importing conditions if the first row of numbers was the only float. (importFromConditions now uses numpy instead of matplotlib)
* FIXED: further fix to the extra "file close" queries during shut-down

PsychoPy 1.79.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Dec 2013

* ADDED: attributes for some stimuli can now be updated using e.g. `stim.pos = newPos` rather than using `stim.setPos(newPos)` to make things more like standard Python (thanks Jonas Lindeløv). This version also involved some major restructuring behind the scenes that should not be visible to users (thanks Todd Jennings)
* ADDED: Builder Components for
    * ioLab Systems button-box; refactor PsychoPy's ioLabs code (Jeremy)
    * Cedrus button-box (tested on RB730)
    * parallel port output component
* ADDED: option for sounds to `loop`
* ADDED: volume argument for MovieStim so that sound can be muted (Frank Papenmeier)
* ADDED: window now prevents system from sleep/screensaver on windows and OS X
* ADDED: builder demo for mental rotation task
* ADDED: Alternative Text stimulus, psychopy.visual.TextBox (Sol Simpson)
        * Two demos in psychopy.coder.visual.textbox
        * Requires: freetype lib (included in Standalone)
        * Advantages: Very fast update following text change; very precise character placement.
        * Disadvantages: Supports monospace fonts only.
        * IMPORTANT: TextBox is still being finalized and completed; expect to find (and please report) issues. API changes guaranteed.
* FIXED: misaligned responses in csv output for QuestHandler (Zhili Zheng)
* FIXED: bug when using ElementArrayStim with numpy 1.7.1. Most elements were receiving SF=0
* FIXED: 'semi-automatic' calibration (thanks Flip Phillips)
* FIXED: shut-down issues. Builder now remembers its last experiment and you don't get multiple messages about the scripts that have changed
* FIXED: bugs with MultiStairHandler that were making it unusable (in code and Builder)
* FIXED: lists of key presses can now be considered `correct` (Ian Hussey)
* FIXED: certain further cases of bitmap images appearing desaturated
* FIXED: mono sounds now duplicate to both channels correctly
* changes to Standalone packages (require fetching the installer):
    * pyFileSec for uploading files to server using encryption (this is Jeremy's module)
    * pandas on win32 is now v1.3 (was already this version on OS X)
    * pyxid now includes Jared's upstream bug-fix
* FIXED: many user interface tweaks, documentation and help string corrections (Philip Wiesemann)
* FIXED: PsychoPy Coder view now closes the iohub process when the experiment script is terminated using 'Stop'. (Sol Simpson)
* FIXED: Builder use of single staircase loops now respects the min/max values
* :noncompat:`CHANGED: data curve fitting functions are now using scipy.optimise.curve_fit and should hopefully be more robust to local minima(?)`

*psychopy.iohub Changes* :

* ADDED: Initial release of the new Touch device:
    * currently supporting Elo brand Touch Screens.
    * any Elo model supporting the SmartSet protocol should work (Elo 2700 model used for testing to date)
    * Touch Events (TouchPress, TouchRelease, TouchMovement) are provided in a separate event stream
    * Touch and Mouse device events are independent of each other, so both devices can be used in parallel without interference
    * Touch screen calibration routine provided; calibration state can be saved to device hardware for persistence
    * See the demos.coder.iohub_extended Touch script for example of calibration graphics front end.
* ADDED: Keyboard and Mouse events can be restricted to those events targeted at a PsychoPy Window. Currently supported on Windows and Linux only.
* NEW: PsychoPy TrialHandler can now be used to feed experiment condition variables to the ioDataStore.
* NEW: Device configuration file can now be specified to the launchHubServer() function when starting the ioHub Process.
* NEW: Simple examples of how to use iohub within a Builder project using a Custom Code Component.
* FIXED: Analog Input Event delay calculation error that was causing incorrect time correction to be applied to this event type.
* NEW: LabJack AnalogInput interface now handles dropped samples and sampling rates that cause multichannel samples to be split between USB packets.
* FIXED: Gaze position calculation fix for the SMI eye tracker interface during binocular tracking.
* NEW: Enhanced Tobii eye tracker setup and calibration graphics:
    * Head position within the 3D eye tracking head box can be visualized before and after calibration
    * Animated fixation target support added during calibration routine
* ADDED: Following EXPERIMENTAL stage implementation (Use at Own Risk):
    * ioDataStore -> Pandas Data Frame based post processing API:
        * Creates a set of Pandas Data Frames for device events, experiment messages, and experiment condition variables.
        * Filter, Group, Join data using the Pandas API.
        * Access event information with associated condition variable states.
        * Define Interest Periods (IP):
            * filter event temporally based on start and end time criteria.
            * define an IP's start and end time criteria using experiment message events, or experiment condition variable columns.
            * re-occurring IP's supported.
            * overlapping IP's supported.
        * Define Regions of Interest (ROI),
            * filter Mouse, Eye Tracker, and Touch device events based on screen location.
            * circle, ellipse, rectangle, and general polygon ROI shapes supported. (ROI functionality is dependent on the shapely python package)
        * IMPORTANT: The ioDataStore->DataFrame API is still being designed and developed. Expect to find issues. API changes guaranteed.

PsychoPy 1.78
------------------------------

PsychoPy 1.78.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2013

* FIXED: Image Components were showing up a pastel versions when no actual image was provided
* FIXED: MultiStairHandler wasn't working on Builder, and had insufficient data outputs when using wide-text csv files
* FIXED: loops couldn't be deleted from the Flow if their conditions file couldn't be found (e.g. had been moved)
* FIXED: setting of color values was not honouring the autolog setting (was always logging)
* FIXED: gui choice boxes now handle unicode in their options as well as ASCII strings (thanks Anne Peschel)
* FIXED: Scaling bug for SMI eye-tracker in binocular mode (thanks Sol)
* FIXED: Builder Code Components that were showing up in unreadable, single-line boxes
* IMPROVED: All Builder Dialogs now appear close to the top of the screen (so they don't shoot off the bottom in most screens)

PsychoPy 1.78.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: Aug 2013

* ADDED: option to preload during Builder scripts using :ref:`static`, which uses :class:`~psychopy.core.StaticPeriod` class
* ADDED: Polygon Component to Builder for drawing regular polygons (including simple lines)
* ADDED: TrialHander can now fetch previous trials as well as future ones (thanks Mike MacAskill)
* ADDED: BufferImageStim accepts mask and pos params (thanks Jeremy)
* ADDED: generated Sounds (not sound files) now use a Hamming window to get rid of sharp onset/offset noises (thanks Jeremy)
* ADDED: microphone component able to play & identify a marker tone (for vocal RT), compute loudness, compression (Jeremy)
* ADDED: sound files: lossless compress / uncompress (requires flac executable installed separately) (Jeremy)
* ADDED: microphone compress() audio recordings; requires flac download (not packaged with PsychoPy)
* ADDED: new preference `flac` = system path for flac, e.g. c:/Program Files (x86)/FLAC/flac.exe (not always needed)
* FIXED: greyscale images were being distorted during display since 1.77.00
* FIXED: reduced number of queries when closing down and provides filenames of changed files in msg (thanks Piot Iwaniuk)
* FIXED: movieStim.contains() and .overlaps() can work, requires that the visual.Window has units of pix

PsychoPy 1.77
------------------------------

PsychoPy 1.77.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: July 2013

* FIXED: problem with Builder Images appearing grey unless they were 'constant'. This is a bug that was introduced in 1.77.00 with the faster loading of images.
* FIXED: having a monitors folder with a unicode character in the path doesn't break the app (thanks Sebastiaan Mathot)

PsychoPy 1.77.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: June 2013

* Standalone package changes:
    - pytables downgraded to 2.3.5 on Win32 (to be compatible with WinXP)
    - pyo upgraded to 0.6.6 on OSX and Win32
* FIXED: The recent files list in Builder now contains recent files! (Thanks Piotr Iwaniuk)
* FIXED: Timing issue with LC Tech eye-tracker in iohub

PsychoPy 1.77.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Released: June 2013

* ADDED: preview of Sol Simpson's **ioHub** for faster (asynchronous) polling of hardware including mouse, keyboard, eyetrackers and other devices. See iohub demos for example usage. This provides many advantages over previous event polling:
    - asynchronous process allows constant polling (not tied to refresh rates) in a way that won't impact the rendering of your stimuli. It even runs on a separate CPU core if possible.
    - provides up/down/duration for key presses
    - provides unicode character (rather than simply key name for keyboard)
    - provides a unified API for eyetracker classes
    - provides async access to the parallel port
    - provides an alternative data output format (using hdf5) particularly useful for high-output streaming data (e.g. eye-trackers)

* DEPRECATED: opensslwrap will soon be replaced by pyFileSec, a much-improved version of the same package (= file-oriented encryption)
* IMPROVED: substantially (~40%) faster loading of RGB images from disk (by using byte format rather than float). May also allow storing of more images on graphics card than previously
* ADDED: `AdvancedMicrophone` class to add and retrieve a high-frequency tone to indicate the start of recording (e.g., to allow accurate vocal RT estimation), with demo (Jeremy Gray)
* REFACTORED: parallel port support. Support for Windows via inpout32/inpout64 and Linux via pyparallel added.  Existing API maintained for single port usage, but new PParallel classes added to provide more flexibility when dealing with multiple ports. see `parallel` (Thanks Mark Hymers)
* ADDED: `MovieStim` now updates its `status` attribute to FINISHED, in line with other stimuli
* :noncompat:`CHANGED: microphone default file names include milliseconds (to avoid two files with the same name)`
* ADDED: color-word speech-recognition demo (coder > input > speech_recognition.py)
* ADDED: in Builder components dialog boxes, text that will be interpreted as code is displayed in monospace font
* ADDED: remove and warn about trailing whitespace in Builder component values (but not Text fields)
* ADDED: support for pyglet version 1.2 alpha (but 1.1.4 is still recommended - it appears to render faster)
* ADDED: more sound.SoundPyo methods (get & set duration, volume, looping)
* FIXED: event.Mouse() can obtain a default visual.Window(), if one has already been created
* ADDED: Builder components generate a compile-time warning if a field's value looks dynamic but its updating is constant (Jeremy Gray)
* ADDED: better simulated scanner-noise in launchScan (just for fun)
* ADDED: RatingScale.getHistory() returns intermediate time-stamped ratings; allows "continuous" ratings
* :noncompat:`CHANGED: RatingScale.getRating() no longer returns False prior to an accepted rating (now returns the currently selected value)`

PsychoPy 1.76
------------------------------

PsychoPy 1.76.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The compatibility changes in this release below are likely to affect very few users.

* ADDED: Window.callOnFlip() function to allow arbitrary functions to be called, timed precisely to the point where the frame flip has occurred (see Coder Demos>Timing>callOnFlip)
* FIXED: a scaling bug in RatingScale descriptions (Giuseppe Pagnoni)
* ADDED: support for mirror-image text, and mirror-image BufferImageStim (Jeremy Gray)
* ADDED: support for lower latency sound with the pyo library. For now pygame remains the default but this can be changed by setting the order in preferences>general>audio
* :noncompat:`CHANGED: PsychoPy Standalone is now being built using python 2.7.3 (rather than 2.6). Under OSX psignifit has been removed from this distribution, as have the libraries to create .mov files using Window.saveMovieFrames(). If you need those features then install the 1.75 Standalone and then update to 1.76 using the auto-update system.`
* ADDED: sound objects (either pygame or pyo) now support autologging
* FIXED: a bug in the generation of the LMS color space conversion matrix. It seems nobody was actually using this for real, but if you were contact Jon for details!
* :noncompat:`CHANGED: various changes to RatingScale (thanks Henrik Singman):`
   * :noncompat:`CHANGED: choices are now displayed at the tick marks by default (instead of above the line). To restore the old behavior set labels=False. This does not affect experiments created in older versions of the builder.`
   * ADDED: check box "choiceLabelsAboveLines" to the RatingScale component of the builder (advanced tab) to still have the choice labels above the line.
   * ADDED: arguments tickMarks and labels to RatingScale class to control where tick marks (for quantitative rating scales) should be placed at the line and how these should be labeled.
   * ADDED: argument ticksAboveLine to RatingScale class. Controls where the tick marks should be plotted (above or below the line).
* FIXED: problem with unset exp.name (was causing wx.Dialog error "TypeError: String or Unicode type required" on new experiments)
* :noncompat:`CHANGED: exp.name is no longer available from Builder scripts (can use exp.getExpName() instead)`
* FIXED: problem with tiling of depth values for ElementArrayStim (thanks Yuri Spitsyn)
* FIXED: Fix to setContrast for certain visual stimuli (Jonas Lindeløv)
* FIXED: inability to launch scripts/experiments if the Mac Standalone was in a folder with a space in it
* FIXED: Aperture Component now honours the 'units' (Hiroyuki Sogo)
* FIXED: stimulus contains/overlaps functions now use stimulus 'units' and take stimulus orientation into account (Hiroyuki Sogo) NB if you had code in place to perform these corrections yourself you should now remove it!
* FIXED: some data outputs were not honouring the 'matrixOnly' option (Mike MacAskill)
* FIXED: when loading a psydat file of an ExperimentHandler the file automatically saved new copies of its csv/excel outputs. This no longer occurs (if loaded using misc.fromFile)
* ADDED: timestamp option to event.waitKeys() (Jonas Lindeløv)
* ADDED: a first-run wizard to check the system, report as html (somewhat experimental) (Jeremy Gray)
* ADDED: a benchmark wizard (Tools menu) to test hardware & software, option to share on psychopy.org (Jeremy Gray)
* ADDED: info.getRAM() (Jeremy Gray)

PsychoPy 1.75.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* FIXED: Bug with not being able to play sounds of blank (infinite) duration from Builder

PsychoPy 1.75.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* :noncompat:`CHANGED: New Builder experiments will, by default, save a single csv file, a single psydat file and a single log file. Was previously also saving an Excel file (with one sheet per loop) and many psydat files (one per loop). Psydat files can still be used to re-output any format of data file.`
* IMPROVED: Experiment info dialog box easier to control now from experiment settings (user doesn't need to write a dictionary by hand any more)
* IMPROVED: Components in the Builder are now arranged in categories, including a special 'Favorites' category
* IMPROVED: Code Components now support full syntax highlighting and code folding (but still aren't quite big enough!)
* ADDED: Builder undo/redo now gives info about what is going to be un/redone
* ADDED: Window now supports a `stereo` flag to provide support for quad-buffers (advanced graphics cards only)
* FIXED: bug with copying/pasting Routines that was breaking Flow in certain situations and corrupting the experiment file
* FIXED: fatal typo in QuestHandler code (Gary Lupyan)
* FIXED: data outputs for multiple key/mouse presses
* ADDED: Microphone now supports `stop` to abort recording early (Jeremy Gray)
* ADDED: beginning of error reporting when generating Builder experiments (thanks Piotr Iwaniuk)
* FIXED: csv files now generated from Builder as expected not dlm files (tab-delimited)

PsychoPy 1.74
------------------------------

PsychoPy 1.74.04
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* IMPROVED: larger Code Component boxes (and fixed bug with being only one line on linux)
* FIXED: Builder code syntax error when using Mouse set state 'every frame'
* FIXED: Builder was erroneously using 'estimated duration' for constraining non-slip timing
* FIXED: Builder couldn't open Experiment Settings if the expected screen number didn't exist on this system

PsychoPy 1.74.03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Aug 2012)

* FIXED: the multiline text entry box in the Builder Text Component was broken (thanks Piotr Iwaniuk)
* IMPROVED: serial (RS232) interface to fORP button box to avoid recording repeated presses (thanks Nate Vack). Does not affect use of fORP box from USB interface.

PsychoPy 1.74.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Aug 2012)

* FIXED: bug leading to message: `IndexError: string index out of range.` This was caused by problem saving excel files
* FIXED: bug leading to message: `AttributeError: ImageStim instance has no attribute 'rgbPedestal'.` Was only occurring on non-shaders machines using the new ImageStim.
* FIXED: problem loading old ExperimentHandlers that contained MultiStairHandlers
* FIXED: Builder Text Components gave an error if letter height was a variable
* ADDED: Window.flip() now returns the timestamp for the flip if possible (thanks Sol Simpson)
* ADDED: misc.sph2cart (Becky Sharman)
* ADDED: warning when user presents SimpleImageStim that seems to extend beyond screen (James McMurray)

PsychoPy 1.74.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: July 2012)

* FIXED: the pyo package is now included in the windows Standalone distribution (making audio input available as intended)
* FIXED: error saving excel data from numpy.int formats (Erik Kastman)
* FIXED: error at end of automated gamma calibration (which was causing a crash of the calibration script)
* FIXED: misc.getDateStr() returns numeric date if there's an error with unicode encoding (Jeremy)
* FIXED: added partial support for non-ASCII keyboards (Sebastiaan Mathot)

PsychoPy 1.74.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(https://github.com/psychopy/psychopy)

Major changes (and compatibility changes):

* ADDED: Long-wide data file outputs, which are now the default for all new Builder experiments.
* ADDED: basic audio capture (and speech recognition via google!). Builder now has a Microphone Component to record inputs, but does not yet use the speech recognition facility. See psychopy.microphone library, coder demo "input/say_rgb.py" and Builder demo "voiceCapture".  (Jeremy)
* ADDED: HSV color space for all stimuli
* :noncompat:`CHANGED: in Builder the default dotstim has signal dots='same' (once a signal dot, always a signal dot). Only affects new experiments.`

Tweaks and fixes:

* FIXED: missing parameter name in conditions file is detected, triggers more informative error message
* ADDED: fORP: option asKeys to handle button presses as pyglet keyboard events (when using a serial port); faster getUniqueEvents()
* ADDED: basic file encryption (beta) using RSA + AES-256; see API encryption for usage and caveats
* ADDED: upload a file to a remote server over http (libs: web.upload) with coder demo, php scripts for server `contrib/http/*`
* ADDED: Builder demo (dualRatingScales): show a stim, get two different ratings side by side [unpack the demos again]
* ADDED: rating scale options: 'maxTime' to time-out, 'disappear' to hide after a rating; see new Builder demo
* FIXED: rating scale bug: skipKeys was not handling 'tab' properly (no skip for tab-key, do skip for 't', 'a', or 'b')
* ADDED: new locale pref for explicitly setting locale, used in date format and passed to builder scripts (Jeremy, Hiroku Sogo)
* ADDED: 'enable escape' option in experiment settings, default is 'enabled'
* ADDED: support for ElementArrayStim to use the same set of color spaces as other stimuli
* :noncompat:`CHANGED: removed python 2.4 version of sha1 digest from :class:'~psychopy.info.RunTimeInfo'`
* :noncompat:`CHANGED: removed any need for PyOpenGL (pyglet.gl now used throughout even for pygame windows)`
* FIXED: Builder was ignoring changes to DotStim FieldPos (thanks Mike MacAskill)
* FIXED: Builder Flow is smarter about Loops and now stops you creating 'broken' ones (e.g. Loops around nothing)
* FIXED: MovieStim used from Builder was not working very well. Sounds continued when it was told to stop and the seek(0.0001) line was causing some file formats not to work from Builder only (those that don't support seeking)
* FIXED: Mouse component was not saving clicks in Builder experiments if forceEndOnClick was set to be False
* FIXED: DotStim.setFieldCoherence was having no effect if noise dots were updating by 'position'

PsychoPy 1.73
------------------------------

PsychoPy 1.73.06
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: April 2012)

* FIXED: xlsx outputs were collapsing raw data from trials with non-response
* FIXED: monitor gamma grids are now returned as arrays rather than lists (Ariel Rokem)
* FIXED: bug with Window.setColor being incorrectly scaled for some spaces
* FIXED: buglet preventing unicode from being used in TrialHandler parameter names (William Hogman) and saving to data files (Becky Sharman)
* FIXED: StairHandler in Builder now saves the expInfo dictionary (Jeremy)
* FIXED: can unpickle from either old-style or new-style data files (using psychopy.compatibility.fromFile()) (Erik Kastman)

PsychoPy 1.73.05
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: March 2012)

* FIXED: Joystick error when calling .getHat() or .getHats() (fixed by Gary Lupyan)
* FIXED: BufferImageStim crashing on some linux boxes (due to bug with checking version of OpenGL) (fixed by Jonas Lindelov)
* FIXED: fMRI emulator class was providing old-format key events (fixed by Erik Kastman and Jeremy)
* FIXED: Win.setRecordFrameIntervals(True) was including the time since it was turned off as a frame interval (fixed by Alex Holcombe)
* FIXED: using forceEndtrial from a mouse component in Builder wasn't working (thanks Esteban for the heads-up)
* FIXED: visual.Circle now respects the edges parameter (fixed by Jonas Lindelov)
* FIXED: having IPython v0.12 should no longer crash psychopy on startup (Jeremy)
* FIXED: non-ascii month-name (eg Japanese) from %B is now filtered out to avoid crash when compile a psyexp script (Jeremy)
* ADDED: support for usb->serial devices under linux (William Hogman)
* ADDED: option to vertically flip a BufferImageStim upon capture (esp for fMRI-related presentation of text) (Jeremy)
* ADDED: option to play a sound (simple tone) during fMRI launchScan simulation (Jeremy)

PsychoPy 1.73.04
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Feb 2012)

* :noncompat:`CHANGED: Builder scripts now silently convert division from integers to float where necessary. That means 1/3=0.333 whereas previously 1/3=0. This is done simply by adding the line 'from __future__ import division' at the top of the script, which people using Coder might want to think about too.`
* FIXED: problem with loading .psydat files using misc.fromFile (thanks Becky)
* FIXED: issue on OSX with updating from 1.70 binaries to 1.73 patch release

PsychoPy 1.73.03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Jan 2012)

* FIXED: problem with loops crashing during save of xlsx/csv files if conditions were empty
* FIXED: bugs in Builder setting Dots coherence and direction parameters
* FIXED: problem with strange text and image rendering on some combinations of ATI graphics on Windows machines

PsychoPy 1.73.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Jan 2012)

* ADDED: loop property to MovieStim for coder only so far (thanks Ariel Rokem)
* FIXED: buglet requesting import of pyaudio (thanks Britt for noticing and Dan Shub for fixing)
* FIXED: problem with avbin (win32)
* FIXED: problem with unicode characters in filenames preventing startup
* FIXED: bug with 'fullRandom' method of TrialHandler missing some trials during data save
* FIXED: Mouse.clickReset() now resets the click timers
* FIXED(?): problem with avbin.dll not being found under 64-bit windows

PsychoPy 1.73.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Jan 2012)

* :noncompat:`CHANGED: psychopy.log has moved to psychopy.logging (Alex Holcombe's suggestion). You'll now get a deprecation warning for using psychopy.log but it will still work (for the foreseeable future)`
* ADDED: new hardware.joystick module supporting pyglet and pyjame backbends for windows and OSX. Demo in Not working on Linux yet. See demos>input
* ADDED: support for CRS ColorCAL mkII for gamma calibrations in Monitor Center.
* ADDED: data.ExpHandler to combine data for multiple separate loops in one study, including output of a single wide csv file. See demos>experimental control>experimentHandler. Support from Builder should now be easy to add
* ADDED: ability to fix (seed) the pseudorandom order of trials in Builder random/full-random loops
* ADDED: auto-update (and usage stats) can now detect proxies in proxy.pac files. Also this now runs in a low-priority background thread to prevent any slowing at startup time.
* FIXED: bug when passing variables to Staircase loops in Builder
* FIXED: mouse in Builder now ignores button presses that began before the 'start' of the mouse
* FIXED: can now use pygame or pyaudio instead of pygame for sounds, although it still isn't recommended (thanks Ariel Rokem for patch)

PsychoPy 1.72.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(rc1 Released: Nov 2011)

* :noncompat:`CHANGED: gui.Dlg and gui.dlgFromDict can now take a set of choices and will convert to a choice control if this is used (thanks Manuel Ebert)`
    - for gui.Dlg the `.addField()` method now has `choices` attribute
    - for gui.dlgFromDict if one of the values in the dict is a list it will be interpreted as a set of choices (NB this potentially breaks old code)
    - for info see API docs for psychopy.gui

* ADDED: improvements to drawing of shapes (thanks Manuel Ebert for all)
    - ShapeStim now has a size parameter that scales the locations of vertices
    - new classes; Rect, Line, Circle, Polygon

* FIXED: error with DotStim when fieldSize was a tuple and fieldShape was 'sqr'
* FIXED: calibration plots in Monitor Center now resize and quit as expected
* FIXED: conditions files can now have lists of numbers [0,0]
* FIXED: buglet with flushing mouse events (thanks Sebastiaan Mathot)
* FIXED: Builder components now draw in order, from top to bottom, so lower items obscure higher ones
* FIXED: problem with Patch Component when size was set to be dynamic
* FIXED: problem with Builder loops not being able to change type (e.g. change 'random' into 'staircase')
* FIXED: data from TrialHandler can be output with unicode contents (thanks Henrik Singmann)

PsychoPy 1.71
------------------------------

PsychoPy 1.71.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Oct 2011)

* :noncompat:`CHANGED: the number of stimulus-resized and frames-dropped warnings is now limited to 5 (could become a preference setting?)`
* FIXED: Builder now allows images to have size of None (or 'none' or just blank) and reverts to using the native size of the image in the file
* FIXED: occasional glitch with rendering caused by recent removal of depth testing (it was getting turned back on by TextStim.draw())
* FIXED: opening a builder file from coder window (and vice versa) switches view and opens there
* FIXED: problem showing the About... item on OS X Builder view
* FIXED problem with loops not showing up if the conditions file wasn't found
* FIXED: runTimeInfo: better handling of cwd and git-related info
* FIXED: rating scale: single click with multiple rating scales, auto-scale with precision = 1
* IMPROVED: rendering speed on slightly older nVidia cards (e.g. GeForce 6000/7000 series) under win32/linux. ElementArrays now render at full speed. Other cards/systems should be unchanged.
* IMPROVED: rating scale: better handling of default description, scale=None more intuitive
* ADDED: new function getFutureTrial(n=1) to TrialHandler, allowing users to find out what a trial will be without actually going to that trial
* ADDED: misc.createXYs() to help creating a regular grid of xy values for ElementArrayStim

PsychoPy 1.71.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Sept 2011)

* :noncompat:`CHANGED: Depth testing is now disabled. It was already being recommended that depth was controlled purely by drawing order (not depth settings) but this is now the *only* way to do that`
* :noncompat:`CHANGED: The Builder representation of the Components onset/offset is now based on 'estimatedStart/Stop' where a value has been given. NB this does not affect the actual onset/offset of Components merely its representation on the timeline.`
* ADDED: Builder loop conditions mini-editor: (right-click in the filename box in a loop dialog)
    - create, edit, and save conditions from within PsychoPy; save & load using pickle format
    - preview .csv or .xlsx conditions files (read-only)
* ADDED: RatingScale method to allow user to setMarkerPosition()
* ADDED: Builder dialogs display a '$' to indicate fields that expect code/numeric input
* ADDED: Text Component now has a wrapWidth parameter to control the bounding box of the text
* ADDED: Opacity parameter to visual stimulus components in the Builder, so you can now draw plaids etc from the builder
* FIXED: can edit or delete filename from loop dialog
* FIXED: bug in RunTimeInfo (no longer assumes that the user has git installed)
* FIXED: bug in BufferImageStim
* FIXED: bug in Builder Ratingscale (was always ending routine on response)
* FIXED: problem with nested loops in Builder. Inner loop was not being repeated. Loops are now only created as they are needed in the code, not at the beginning of the script
* FIXED: rendering of many stimuli was not working beyond 1000 elements (fixed by removal of depth testing)
* FIXED: mouse component now using start/duration correctly (broken since 1.70.00)
* FIXED: when changing the texture (image) of a PatchStim, the stimulus now 'remembers' if it had been created with no size/sf set and updates these for the new image (previously the size/sf got set according to the first texture provided)
* FIXED: putting a number into Builder Sound Component does now produce a sound of that frequency
* FIXED: added 'sound','misc','log' to the component names that PsychoPy will refuse. Also a slightly more informative warning when the name is already taken
* FIXED: Opacity parameter was having no effect on TextStim when using shaders
* FIXED bug with MovieStim not starting at beginning of movie unless a new movie was added each routine


PsychoPy 1.70
------------------------------

PsychoPy 1.70.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Aug 2011)

* FIXED: buglet with Builder (1.70.00) importing older files not quite right and corrupting the 'allowedKeys' of keyboard component
* FIXED: buglet with SimpleImageStim. On machines with no shaders some images were being presented strangely
* FIXED: buglet with PatchStim. After a call to setSize, SF was scaling with the stimulus (for unit types where that shouldn't happen)

PsychoPy 1.70.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: Aug 2011)

*NB This version introduces a number of changes to Builder experiment files that will prevent files from this version being opened by earlier versions of PsychoPy*

* :noncompat:`CHANGED use of allowedKeys in Keyboard Component. You used to be able to type 'ynq' to get those keys, but this was confusing when you then needed ''space'' or ''left'' etc. Now you must type 'y','n','q', which makes it more obvious how to include 'space','left','right'...`
* :noncompat:`CHANGED dot algorithm in DotStim. Previously the signalDots=same/different was using the opposite to Scase et al's terminology, now they match. Also the default method for noiseDots was 'position' and this has been changed to 'direction'. The documentation explaining the algorithms has been clarified. (see :ref:'dots')`
* :noncompat:`CHANGED 'MovieStim.playing' property to be called 'MovieStim.status' (in keeping with other stimuli)`
* :noncompat:`CHANGED names:`

    - `data.importTrialTypes` is now `data.importConditions`
    - `forceEndTrial` in Keyboard Component is now `forceEndRoutine`
    - `forceEndTrialOnPress` in Mouse Component is now `forceEndRoutineOnPress`
    - `trialList` and `trialListFile` in Builder are now `conditions` and `conditionsFile`, respectively
    - 'window units' to set Component units is now 'from exp settings' for less confusion

* :noncompat:`CHANGED numpy imports in Builder scripts:`

    - only a subset of numpy features are now imported by default: numpy: sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray, random, randint, normal, shuffle
    - all items in the numpy namespace are available as np.*
    - if a pre-v1.70 script breaks due to this change, try prepending 'np.' or 'np.random.'

* :noncompat:`CHANGED Builder use of $. $ can now appear anywhere in the field (previously only the start). To display a '$' character now requires '\$' in a text field (to prevent interpretation of normal text as being code).`

* ADDED flexibility for start/stop in Builder Components. Can now specify stimuli according to;

    - variable values (using $ symbol). You can also specify an 'expected' time/duration so that something is still drawn on the timeline
    - number of frames, rather than time (s), for greater precision
    - an arbitrary condition (e.g. otherStim.status==STOPPED )

* ADDED the option to use a raised cosine as a PatchStim mask (thanks Ariel Rokem)
* ADDED a preference setting for adding custom path locations to Standalone PsychoPy
* ADDED Dots Component to Builder interface for random dot kinematograms
* ADDED wide-format data files (saveAsWideText()) (thanks Michael MacAskill)
* ADDED option for full randomization of repeated lists (loop type 'fullRandom') (Jeremy)
* ADDED builder icons can now be small or large (in prefs)
* ADDED checking of conditions files for parameter name conflicts (thanks Jeremy)
* ADDED emulate sync pulses and user key presses for fMRI or other scanners (for testing); see hardware/launchScan in the API reference, and Coder `demos > experimental control > fMRI_launchScan.py` (Jeremy)
* ADDED right-clicking the expInfo in Experiment Settings tests & previews the dialog box (Jeremy)
* ADDED syntax checking in code component dialog, right-click (Jeremy)
* IMPROVED documentation (thanks Becky Sharman)
* IMPROVED syntax for using $ in code snippets (e.g., "[$xPos, $yPos]" works) (Jeremy)
* IMPROVED Flow and Routine displays in the Builder, with zooming; see the View menu for key-board shortcuts (Jeremy)
* IMPROVED Neater (and slightly faster) changing of Builder Routines on file open/close
* FIXED demos now unpack to an empty folder (Jeremy)
* FIXED deleting an empty loop from the flow now works (Jeremy)
* FIXED further issue in QUEST (the addition in 1.65.01 was being used too widely)
* FIXED bug with updating of gamma grid values in Monitor Center

PsychoPy 1.65
------------------------------

PsychoPy 1.65.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: July 2011)

* FIXED Builder keyboard component was storing 'all keys' on request but not all RTs
* FIXED Aperture Component in Builder, which was on for an entire Routine. Now supports start/stop times like other components
* IMPROVED Sound stimuli in Builder:

    * FIXED: sounds could be distorted and would repeat if duration was longer than file
    * ADDED volume parameter to sound stimuli
    * FIXED: duration parameter now stops a file half-way through if needed

* FIXED buglet preventing some warning messages being printed to screen in Builder experiments
* FIXED bug in the copying/pasting of Builder Routines, which was previously introducing errors of the script with invalid _continueName values

PsychoPy 1.65.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: July 2011)

* FIXED buglets in QUEST handler (thanks Gerrit Maus)
* FIXED absence of pygame in 1.65.00 Standalone release
* ADDED shelve module to Standalone (needed by scipy.io)
* ADDED warnings about going outside the monitor gamut for certain colors (thanks Alex Holcombe)

PsychoPy 1.65.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(Released: July 2011)

* ADDED improved gamma correction using L=a+(b+kI)**G formula (in addition to industry-standard form). Existing gamma calibrations will continue to use old equation but new calibrations will take the new extended formula by default.
* ADDED MultiStairHandler to run multiple interleaved staircases (also from the Builder)
* ADDED createFactorialTrialList, a convenience function for full factorial conditions (thanks Marco Bertamini)
* :noncompat:`CHANGED Builder keyboard components now have the option to discard previous keys (on by default)`
* :noncompat:`CHANGED RatingScale:`

  - ADDED: argument to set lineColor independently (thanks Jeff Bye)
  - :noncompat:`CHANGED default marker is triangle (affects windows only)`
  - ADDED single-click option, custom-marker support
  - FIXED: bug with precision=1 plus auto-rescaling going in steps of 10 (not 1)

* FIXED errors with importing from 'ext' and 'contrib'
* FIXED error in joystick demos
* FIXED bug in ElementArrayStim depth
* FIXED bug in misc.maskMatrix. Was not using correct scale (0:1) for the mask stage
* FIXED buglet in StairHandler, which was only terminating during a reversal
* FIXED bug when loading movies - they should implicitly pause until first draw() (thanks Giovanni Ottoboni)
* IMPROVED handling of non-responses in Builder experiments, and this can now be the correct answer too (corrAns=None). ie. can now do go/no-go experiments. (Non-responses are now empty cells in excel file, not "--" as before.)

PsychoPy 1.64
------------------------------

PsychoPy 1.64.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released: April 2011

* ADDED option to return field names when importing a trial list (thanks Gary Lupyan)
* ADDED Color-picker on toolbar for Coder and context menu for Builder (Jeremy Gray)
* ADDED CustomMouse to visual (Jeremy Gray)
* ADDED Aperture object to visual (thanks Yuri Spitsyn) and as a component to Builder (Jeremy Gray)
* :noncompat:`CHANGED RatingScale (Jeremy Gray):`
    - FIXED bug in RatingScale that prevented scale starting at zero
    - ADDED RatingScale "choices" (non-numeric); text size, color, font, & anchor labels; pos=(x,y) (Jeremy Gray)
    - :noncompat:`CHANGED RatingScale internals; renamed escapeKeys as skipKeys; subject now uses 'tab' to skip (Jeremy Gray)`
* ADDED user-configurable code/output font (see coder prefs to change)
* ADDED gui.Dlg now automatically uses checkboxes for bools in inputs (Yuri Spitsyn)
* ADDED RatingScale component for Builder (Jeremy Gray)
* ADDED packages to Standalone distros:
    - pyxid (Cedrus button boxes)
    - labjack (good, fast, cheap USB I/O device)
    - egi (pynetstation)
    - pylink (SR Research eye trackers)
    - psignifit (bootstrapping, but only added on mac for now)
* ADDED option for Builder components to take code (e.g. variables) as start/duration times
* ADDED support for RGBA files in SimpleImageStim
* IMPROVED namespace management for variables in Builder experiments (Jeremy Gray)
* IMPROVED prefs dialog
* IMPROVED test sequence for PsychoPy release (so hopefully fewer bugs in future!)
* FIXED bug with ElementArrayStim affecting the subsequent color of ShapeStim
* FIXED problem with the error dialog from Builder experiments not being a sensible size (since v1.63.03 it was just showing a tiny box instead of an error message)
* FIXED Coder now reloads files changed outside the app when needed (thanks William Hogman)
* FIXED Builder Text Component now respects the font property
* FIXED problem with updating to a downloaded zip file (win32 only)
* FIXED bug with ShapeStim.setOpacity when no shaders are available
* FIXED *long-standing pygame scaling bug*
* FIXED you can now scroll Builder Flow and still insert a Routine way to the right

PsychoPy 1.63
------------------------------

PsychoPy 1.63.04
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2011

* FIXED bug in windows prefs that prevents v1.63.03 from starting up
* FIXED bug that prevents minolte LS100 from being found

PsychoPy 1.63.03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2011

* ADDED Interactive shell to the bottom panel of the Coder view. Choose (in prefs) one of;
    * pyShell (the default, with great tooltips and help)
    * IPython (for people that like it, but beware it crashes if you create a psychopy.visual.Window() due to some threading issue(?))
* ADDED scrollbar to output panel
* FIXED small bug in QUEST which gave an incorrectly-scaled value for the next() trial
* FIXED ElementArrayStim was not drawing correctly to second window in multi-display setups
* FIXED negative sound durations coming from Builder, where sound was starting later than t=0
* FIXED a problem where Builder experiments failed to run if 'participant' wasn't in the experiment info dialog

PsychoPy 1.63.02
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2011

* ADDED clearFrames option to Window.saveMovieFrames
* ADDED support for Spectrascan PR655/PR670
* ADDED 'height' as a type of unit for visual stimuli
    NB. this is likely to become the default unit for new users (set in prefs)
    but for existing users the unit set in their prefs will remain. That means
    that your system may behave differently to your (new user) colleague's
* IMPROVED handling of damaged experiments in Builder (they don't crash the app any more!)
* IMPROVED performance of autoLogging (including demos showing how to turn of autoLog for dynamic stimuli)

PsychoPy 1.63.01
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released: Jan 2011

* FIXED bug with ElementArrayStim.setFieldPos() not updating
* FIXED mouse release problem with pyglet (since in 1.63.00)
* ADDED ability to retrieve a timestamp for a mouse event, similar to those in keyboard events.
    This is possible even though you may not retrieve the mouse event until later (e.g. waiting
    for a frame flip). Thanks Dave Britton
* FIXED bug with filters.makeGrating: gratType='sqr' was not using ori and phase
* FIXED bug with fetching version info for autoupdate (was sometimes causing a crash on startup
    if users selected 'skip this version')
* :noncompat:`CHANGED optimisation routine from fmin_powell to fmin_bfgs. It seems more robust to starting params.`

PsychoPy 1.63.00
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Released: Dec 2010

* **ADDED autoLog mechanism:**
    * many more messages sent, but only written when log.flush() is called
    * rewritten backend to logging functions to remove file-writing performance hit
    * added `autoLog` and `name` attributes to visual stimuli
    * added setAutoDraw() method to visual stimuli (draws on every win.flip() until set to False)
    * added logNextFlip() method to visual.Window to send a log message time-stamped to flip
* **FIXED bug in color calibration for LMS color space (anyone using this space should recalibrate immediately)** Thanks Christian Garber for picking up on this one.
* FIXED bug with excel output from StairHandler
* FIXED bug in ElemetArray.setSizes()
* FIXED bug in running QuestHandler (Zarrar Shehzad)
* FIXED bug trying to remove a Routine from Flow when enclosed in a Loop
* FIXED bug with inseting Routines into Flow under Linux
* FIXED bug with playing a MovieStim when another is already playing
* :noncompat:`CHANGED default values for Builder experiment settings (minor)`
* :noncompat:`CHANGED ShapeStim default fillColor to None (from (0,0,0))`
* FIXED DotStim now supports a 2-element fieldSize (x,y) again
* :noncompat:`CHANGED phase of RadialStim to be 'sin' instead of 'cosine' at phase=0`
* FIXED rounding issue in RadialStim phase
* FIXED ElementArrayStim can now take a 2x1 input for setSizes(), setSFs(), setPhases()
* ADDED packages to standalone distributions: pyserial, pyparallel (win32 only), parallel python (pp), IPython
* :noncompat:`CHANGED Builder demos are now back in the distributed package. Use >Demos>Unpack... to put them in a folder you have access to and you can then run them from the demos menu`
* FIXED bug with ShapeStim initialisation (since 1.62.02)
* UPDATED: Standalone distribution now uses Python2.6 and adds/upgrades;
    * parallel python (pp)
    * pyserial
    * ioLabs
    * ipython (for future ipython shell view in coder)
    * numpy=1.5.1, scipy=0.8.0, matplotlib=1.0
* UPDATED: Builder demos

PsychoPy 1.62
------------------------------

PsychoPy 1.62.02
~~~~~~~~~~~~~~~~~~~~~~~~
Released: Oct 2010

* FIXED: problem with RadialStim causing subsequent TextStims not to be visible
* FIXED: bug with saving StairHandler data as .xlsx
* ADDED: option for gui.fileOpenDlg and fileSaveDlg to receive a custom file filter
* FIXED: builder implementation of staircases (initialisation was buggy)
* FIXED: added Sound.setSound() so that sounds in builder can take new values each trial
* FIXED: when a Routine was copied and pasted it didn't update its name properly (e.g. when inserted into the Flow it kept the origin name)
* FIXED: color rendering for stimuli on non-shader machines using dkl,lms, and named color spaces
* ADDED: data.QuestHandler (Thanks to Zarrar Shehzad). This is much like StairHandler but uses the QUEST routine of Watson and Pelli
* :noncompat:`CHANGED: TextStim orientation now goes the other way, for consistency with other stimuli (thanks Manuel Spitschan for noticing)**`
* FIXED: Problem with DotStim using 'sqr' fieldShape
* ADDED: MovieStim now has a setMovie() method (a copy of loadMovie())
* FIXED: problem with MovieStim.loadMovie() when a movie had already been loaded

PsychoPy 1.62.01
~~~~~~~~~~~~~~~~~~~~~~~~
Released: Sept 2010

* ADDED: clicking on a Routine in the Flow window brings that Routine to current focus above
* ADDED: by setting a loop in the Flow to have 0 repeats, that part of your experiment can be skipped
* :noncompat:`CHANGED: builder hides mouse now during fullscreen experiments (should make this a pref or setting though?)`
* FIXED: rendering problem with the Flow and Routine panels not updating on some platforms
* ADDED: added .pause() .play() and .seek() to MovieStim (calling .draw() while paused will draw current static frame)
* FIXED: bug in MovieStim.setOpacity() (Ariel Rokem)
* FIXED: bug in win32 - shortcuts were created in user-specific start menu not all-users start menu
* :noncompat:`CHANGED: data output now uses std with N-1 normalisation rather than (scipy default) N`
* FIXED: bug when .psyexp files were dropped on Builder frame
* FIXED: bug with Builder only storing last letter or multi-key button (e.g. 'left'->'t') under certain conditions
* FIXED: when nReps=0 in Builder the loop should be skipped (was raising error)
* :noncompat:`CHANGED: mouse icon is now hidden for full-screen Builder experiments`
* FIXED: Builder was forgetting the TrialList file if you edited something else in the loop dialog
* ADDED: visual.RatingScale and a demo to show how to use it (Jeremy Gray)
* ADDED: The Standalone distributions now includes the following external libs:
    - pynetstation (import psychopy.hardware.egi)
    - ioLab library (import psychopy.harware.ioLab)
* ADDED: trial loops in builder can now be aborted by setting someLoopName.finished=True
* ADDED: improved timing. *Support for blocking on VBL for all platforms* (may still not work on intel integrated chips)
* FIXED: minor bug with closing Coder windows generating spurious error messages
* ADDED: 'allowed' parameter to gui.fileOpeNDlg and fileCloseDlg to provide custom file filters

PsychoPy 1.62.00
~~~~~~~~~~~~~~~~~~~~~~~~
Released: August 2010

* ADDED: support for Excel 2007 files (.xlsx) for data output and trial types input:
    - psychopy.data now has importTrialList(fileName) to generate a trial list (suitable for TrialHandler) from .xlsx or .csv files
    - Builder loops now accept either an xlsx or csv file for the TrialList
    - TrialHandler and StairHandler now have saveToExcel(filename, sheetName='rawData', appendFile=True). This can be used to generate almost identical files to the previous delimited files, but also allows multiple (named) worksheets in a single file. So you could have one file for a participant and then one sheet for each session or run.
* :noncompat:`CHANGED: for builder experiments the trial list for a loop is now imported from the file on every run, rather than just when the file is initially chosen`
* :noncompat:`CHANGED: data for TrialHandler are now stored as masked arrays where possible. This means that trials with no response can be more easily ignored by analysis`
* FIXED: bug opening loop properties (bug introduced by new advanced params option)
* FIXED: bug in Builder code generation for keyboard (only when using forceEnd=True but store='nothing')
* :noncompat:`CHANGED: RunTimeInfo is now in psychopy.info not psychopy.data`
* :noncompat:`CHANGED: PatchStim for image files now defaults to showing the image at native size in pixels (making SimpleImageStim is less useful?)`
* :noncompat:`CHANGED: access to the parameters of TrialList in the Builder now (by default) uses a more cluttered namespace for variables. e.g. if your TrialList file has heading rgb, then your components can access that with '$rgb' rather than '$thisTrial.rgb'. This behaviour can be turned off with the new Builder preference 'allowClutteredNamespace'.`
* FIXED: if Builder needs to output info but user had closed the output window, it is now reopened
* FIXED: Builder remembers its window location
* :noncompat:`CHANGED: Builder demos now need to be fetched by the user - menu item opens a browser (this is slightly more effort, but means the demos aren't stored within the app which is good)`
* :noncompat:`CHANGED: loops/routines now get inserted to Flow by clicking the mouse where you want them :-)`
* ADDED: you can now have multiple Builder windwos open with different experiments
* ADDED: you can now copy and paste Routines form one Builder window to another (or itself) - useful for reusing 'template' routines
* FIXED: color of window was incorrectly scaled for 'named' and 'rgb256' color spaces
* ADDED: quicktime movie output for OSX 10.6 (10.5 support was already working)
* ADDED: Mac app can now receive dropped files on the coder and builder panels (but won't check if these are sensible!!)
* ADDED: debugMode preference for the app (for development purposes)
* ADDED: working version of RatingStim

PsychoPy 1.61
------------------------------

PsychoPy 1.61.03
~~~~~~~~~~~~~~~~~~~~~~~~
Patch Released: July 2010

* FIXED: harmless error messages caused by trying to get the file date/time when no file is open
* :noncompat:`CHANGED: movie file used in movie demo (the chimp had unknown copyright)`
* FIXED: problem with nVidia cards under win32 being slow to render RadialStim
* FIXED bug in filters.makeGrating where gratType='sqr'
* FIXED bug in new color spaces for computers that don't support shaders
* ADDED option to Builder components to have 'advanced' parameters not shown by default (and put this to use for Patch Component)

PsychoPy 1.61.02
~~~~~~~~~~~~~~~~~~~~~~
Patch Released: June 2010

* ADDED: Code Component to Builder (to insert arbitrary python code into experiments)
* ADDED: visual.RatingScale 'stimulus' (thanks to JG). See ratingScale demo in Coder view
* FIXED: TrialHandler can now have dataTypes that contain underscores (thanks fuchs for the fix)
* FIXED: loading of scripts by coder on windows assumed ASCII so broke with unicode characters. Now assumes unicode (as was case with other platforms)
* FIXED: minor bugs connecting to PR650

PsychoPy 1.61.01
~~~~~~~~~~~~~~~~~~~~~~
Patch Released: May 2010

* FIXED: Bug in coder spitting out lots of errors about no method BeginTextColor
* FIXED: Buglet in rendering of pygame text with our shaders
* FIXED: broken link for >Help>Api (reference) menuitem

PsychoPy 1.61.00
~~~~~~~~~~~~~~~~~~~~~~
Released: May 2010

* :noncompat:`CHANGED: color handling substantially. Now supply color and colorSpace arguments and use setColor rather than setRGB etc. Previous methods still work but give deprecation warning.`
* ADDED: Colors can now also be specified by name (one of the X11 or web colors, e.g. 'DarkSalmon') or hex color spec (e.g. '#E9967A')
* REMOVED: TextStimGLUT (assuming nobody uses GLUT backend anymore)
* ADDED: 'saw' and 'tri' options to specify grating textures, to give sawtooth and triangle waves
* FIXED: visual.DotStim does now update coherence based on setFieldCoherence calls
* FIXED: bug in autoupdater for installs with setuptools-style directory structure
* FIXED: bug in SimpleImageStim - when graphics card doesn't support shaders colors were incorrectly scaled
* :noncompat:`CHANGED: console (stdout) default logging level to WARNING. More messages will appear here than before`
* ADDED: additional log level called DATA for saving data info from experiments to logfiles
* ADDED: mouse component to Builder
* ADDED: checking of coder script for changes made by an external application (thanks to Jeremy Gray)
* ADDED: data.RuntimeInfo() for providing various info about the system at launch of script (thanks to Jeremy Gray)
* FIXED: problem with rush() causing trouble between XP/vista (thanks to Jeremy Gray)
* AMERICANIZATION: now consistently using 'color' not 'colour' throughout the project! ;-)
* FIXED: problem with non-numeric characters being inserted into data structures
* :noncompat:`CHANGED: stimuli using textures now automatically clean these up, so no need for users to call .clearTextures()`

PsychoPy 1.60
------------------------------

PsychoPy 1.60.04
~~~~~~~~~~~~~~~~~~~~~~
Released: March 2010

* FIXED build error (OS X 10.6 only)

PsychoPy 1.60.03
~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2010

* FIXED buglet in gui.py converting 'false' to True in dialogs (thanks Michael MacAskill)
* FIXED bug in winXP version introduced by fixes to the winVista version! Now both should be fine!!

PsychoPy 1.60.02
~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2010

* :noncompat:`CHANGED ext.rush() is no longer run by default on creation of a window. It seems to be causing more probs and providing little enhancement.`
* FIXED error messages from vista/7 trying to import pywintypes.dll

PsychoPy 1.60.01
~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2010

* FIXED minor bug with the new psychophysicsStaircase demo (Builder)
* FIXED problem with importing wx.lib.agw.hyperlink (for users with wx<2.8.10)
* FIXED bug in the new win.clearBuffer() method
* :noncompat:`CHANGED builder component variables so that the user inputs are interpretted as literal text unless preceded by $, in which case they are treated as variables/python code`
* :noncompat:`CHANGED builder handling of keyboard 'allowedKeys' parameter. Instead of '['1','2','q']' you can now simply use '12q' to indicate those three keys. If you want a key like ''right'' and ''left'' you now have to use '$['right','left']'`
* TWITTER follow on http://twitter.com/psychopy
* FIXED? win32 version now compatible with Vista/7? Still compatible with XP?

PsychoPy 1.60.00
~~~~~~~~~~~~~~~~~~~~~~
Released: Feb 2010

* simplified prefs:
       - no more site prefs (user prefs only)
       - changed key bindings for compileScript(F5), runScript(Ctrl+R), stopScript(Ctrl+.)
* ADDED: full implementation of staircase to Builder loops and included a demo for it to Builder
* :noncompat:`CHANGED: builder components now have a 'startTime' and 'duration' rather than 'times'`
* ADDED: QuickTime output option for movies (OSX only)
* ADDED: script is saved by coder before running (can be turned off in prefs)
* ADDED: coder checks (and prompts) for filesave before running script
* ADDED: setHeight to TextStim objects, so that character height can be set after initialisation
* ADDED: setLineRGB, setFillRGB to ShapeStim
* ADDED: ability to auto-update form PsychoPy source installer (zip files)
* ADDED: Monitor Center can be closed with Ctrl-W
* ADDED: visual.Window now has a setRGB() method
* ADDED: visual.Window now has a clearBuffer() method
* ADDED: context-specific help buttons to Builder dialogs
* ADDED: implemented of code to flip SimpleImageStim (added new methods flipHoriz() and flipVert())
* ADDED: Butterworth filters to psychopy.filters (thanks Yaroslav Halchenko)
* ADDED: options to view whitespace, EOLs and indent guides in Coder
* ADDED: auto-scaling of time axis in Routines panel
* IMPROVED: Splash screen comes up faster to show the app is loading
* FIXED: bug in RadialStim .set functions (default operation should be "" not None)
* FIXED: on mac trying to save an unchanged document no longer inserts an 's'
* FIXED: bug with SimpleImageStim not drawing to windows except #1
* FIXED: one bug preventing PsychoPy from running on vista/win7 (are there more?)
* :noncompat:`CHANGED: psychopy.filters.makeMask() now returns a mask with values -1:1, not 0:1 (as expected by stimulus masks)`
* RESTRUCTURED: the serial package is no longer a part of core psychopy and is no longer required (except when hardware is actually being connected). This should now be installed as a dependency by users, but is still included with the Standalone packages.
* RESTRUCTURED: preparing for further devices to be added, hardware is now a folder with files for each manufacturer. Now use e.g.::

    from psychopy.hardware.PR import PR650
    from psychopy.hardware.cedrus import RB730

PsychoPy 1.51.00
------------------------------
(Released: Nov 2009)

* :noncompat:`CHANGED: gamma handling to handle buggy graphics drivers on certain cards - see note below`
* :noncompat:`CHANGED: coord systems for mouse events - both winTypes now provide mouse coords in the same units as the Window`
* FIXED: mouse in pyglet window does now get hidden with Window allowGUI=False
* FIXED: (Builder) failed to open from Coder view menu (or cmd/ctrl L)
* FIXED: failure to load user prefs file
* ADDED: keybindings can be handled from prefs dialog (thanks to Jeremy Gray)
* ADDED: NxNx3 (ie RGB) numpy arrays can now be used as textures
* FIXED: MovieStim bug on win32 (was giving spurious avbin error if visual was imported before event)

NB. The changes to gamma handling should need no changes to your code, but could alter the gamma correction on
some machines. For setups/studies that require good gamma correction it is recommended that you recalibrate when
you install this version of PsychoPy.

PsychoPy 1.50
------------------------------

PsychoPy 1.50.04
~~~~~~~~~~~~~~~~~~~~~~
(Released: Sep 09)

* FIXED (Builder) bug with loading files (monitor fullScr incorrectly reloaded)
* FIXED (Coder) bug with Paste in coder
* FIXED (Builder) bug with drop-down boxes
* FIXED (Builder) bug with removed routines remaining in Flow and InsertRoutineDlg
* MOVED demos to demos/scripts and added demos/exps (for forthcoming Builder demos)
* :noncompat:`CHANGED (Builder) creating a new file in Builder (by any means) automatically adds a 'trial' Routine`
* FIXED (Builder) various bugs with the Patch component initialisation (params being ignored)
* FIXED (Builder) better default parameters for text component

PsychoPy 1.50.02
~~~~~~~~~~~~~~~~~~~~~~
(Released: Sep 09)

* FIXED bug loading .psydat (files component variables were being saved but not reloaded)
* removed debugging messages that were appearing in Coder output panel
* FIXED long-standing problem (OS X only) with "save unchanged" dialogs that won't go away
* FIXED bug with 'cancel' not always cancelling on "save unchanged" dialogs
* ADDED warning dialog if user adds component without having any routines
* ADDED builder now remembers its location, size and panel sizes (which can be moved around)

PsychoPy 1.50.01
~~~~~~~~~~~~~~~~~~~~~~
(Released: Sep 09)

* FIXED problem creating prefs file on first use
* FIXED problem with removing (identical) routines in Flow panel
* FIXED problem with avbin import (OS X standalone version)

PsychoPy 1.50.00
~~~~~~~~~~~~~~~~~~~~~~
(Released: Sep 09)

* ADDED A preview of the new application structure and GUI
* ADDED performance enhancements (OS X now blocks on vblank, all platforms rush() if user has permissions)
* ADDED config files. These are already used by the app, but not the library.
* ADDED data.getDateStr() for convenience
* FIXED bug on certain intel gfx cards (shaders now require float extension as well as opengl2.0)
* FIXED bug scaling pygame text (which caused pygame TextStims not to appear)
* BACKWARDS NONCOMPAT: monitors is moved to be a subpackage of psychopy
* BACKWARDS NONCOMPAT: added 'all_mean' (and similar) data types to TrialHandler.saveAsText and these are now default
* ADDED TrialType object to data (extends traditional dicts so that trial.SF can be used as well as trial['SF'])
* converted docs/website to sphinx rather than wiki (contained in svn)
* FIXED bug with MovieStim not displaying correctly after SimpleImageStim
* FIXED incorrect wx sizing of app(IDE) under OS X on opening
* :noncompat:`CHANGED license to GPL (more restrictive, preventing proprietary use)`
* :noncompat:`CHANGED gui dialogs are centered on screen rather than wx default position`
* new dependency on lxml (for saving/loading builder files)

PsychoPy 1.00
------------------------------

PsychoPy 1.00.04
~~~~~~~~~~~~~~~~~~~~~~
(Released: Jul 09)

* DotStim can have fieldShape of 'sqr', 'square' or 'circle' (the first two are equiv)
* :noncompat:`CHANGED interpreters in all .py scripts to be the same (#!/usr/bin/env python). Use PATH env variable to choose non-default python version for your Python scripts`
* :noncompat:`CHANGED pyglet textures to use numpy->ctypes rather than numpy->string`
* FIXED systemInfo assigned on Linux systems

PsychoPy 1.00.03
~~~~~~~~~~~~~~~~~~~~~~
(Released: Jul 09)

* FIXED initialisation bug with SimpleImageStimulus
* FIXED "useShaders" buglet for TextStim
* :noncompat:`CHANGED IDE on win32 to run scripts as processes rather than imports (gives better error messages)`
* ADDED mipmap support for textures (better antialiasing for down-scaling)
* :noncompat:`CHANGED win32 standalone to include the whole raw python rather than using py2exe`

PsychoPy 1.00.02
~~~~~~~~~~~~~~~~~~~~~~
(Released: Jun 09)

* ADDED SimpleImageStimulus for simple blitting of raw, unscaled images
* ADDED collection of anonymous usage stats (e.g.: OSX_10.5.6_i386 1.00.02 2009-04-27_17:26 )
* RENAMED DotStim.setDirection to setDir for consistency (the attribute is dir not direction)
* FIXED bug with DotStim updating for 'walk' and 'position' noise dots (thanks Alex Holcombe)
* FIXED bug with DotStim when fieldSize was initialised with a list rather than an array
* FIXED buglet using event.getKeys in pygame (nothing fetched if pyglet installed)
* :noncompat:`CHANGED image loading code to check whether the image is a file, rather than using try..except`
* FIXED buglet raising trivial error messages on closing final window in IDE
* FIXED problem pasting into find dlg in IDE

PsychoPy 1.00.01
~~~~~~~~~~~~~~~~~~~~~~
(Released: Feb 09)

* FIXED buglet in windows standalone installer

PsychoPy 1.00.00
~~~~~~~~~~~~~~~~~~~~~~
* ADDED ShapeStim, for drawing geometric stimuli (see demos/shapes.py and new clockface.py)
* ADDED support for the tristate ctrl bit on parallel ports (thanks Gary Strangman for the patch)
* ADDED standalone installer support for windows (XP, vista?)
* FIXED minor bug in Window.flip() with frame recording on (average -> numpy.average)
* FIXED minor bug in sound, now forcing pygame.mixer to use numpy (thanks Konstantin for the patch)
* FIXED visual stimulus positions forced to be floats on init (thanks C Luhmann)

~~~~~~~~~~~~~~~~~~~~~~

PsychoPy 0.97:
------------------------------

PsychoPy 0.97.01:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED bug with IDE not closing properly (when current file was not right-most)
* ADDED parallel.readPin(pinN) so that parallel port can be used for input as well as output
* FIXED bug in parallel.setPortAddress(addr)
* ADDED check for floats as arguments to ElementArrayStim set___ methods
* :noncompat:`CHANGED: frame time recording to be *off* by default (for plotting, for Window.fps() and for warnings). To turn it on use Window.setRecordFrameIntervals(True), preferably after first few frames have elapsed`
* IMPROVED detection of the (truly) dropped frames using log.console.setLevel(log.WARNING)
* FIXED bug that was preventing bits++ from detecting LUT on the Mac (ensure screen gamma is 1.0 first)
* FIXED buglet with .setRGB on stimuli - that method should require an operation argument (def=None)
* ADDED fieldDepth and depths (for elements, relative to fieldDepth) as separate arguments to the ElementArrayStim

PsychoP 0.97.00:
~~~~~~~~~~~~~~~~~~~~~~
* ADDED options to DotStim motions. Two args have been added:
  * signalDots can be 'different' from or 'same' as the noise dots (from frame to frame)
  * noiseDots determines the update rule for the distractor dots (random 'position', 'walk', 'direction')
  * dotLife now works (was previously just a placeholder). Default is -1 (so should be same as before)
  see Scase, Braddick & Raymond (1996) for further info on the importance of these
* ADDED options to event.getKeys
  * keyList to limit which keys are checked for (thanks Gary Strangman)
  * timeStamped=False/True/Clock (thanks Dave Britton)
* :noncompat:`CHANGED pyglet key checking now returns '1' as the key irrespective of numpad or otherwise (used to return '1' or 'NUM_1')`
* FIXED bug in event.py for machines where pyglet is failing to import
* REMOVED AlphaStim (after a long period of 'deprecated')

----------

PsychoPy 0.96:
------------------------------

PsychoPy 0.96.02:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED bug introduced with clipping of text in 0.96.01 using textstimuli with shaders  under pygame
* FIXED bug with rendering png alpha layer using pyglet shaders

PsychoPy 0.96.01:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED problem with write errors running demos from Mac IDE
* ADDED frameWidth to textStim for multiline
* ADDED setRecordFrameIntervals, saveFrameTimes() to Window and misc.plotFrameIntervals()
* FIXED had accidentally made pygame a full dependency in visual.py
* FIXED MovieStim was being affected by texture color of other stimuli
* FIXED window now explicitly checks for GL_ARB_texture_float before using shaders

PsychoPy 0.96.00:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED pygame back-end so that can be used as a valid alternative to pyglet (requires pygame1.8+ and PyOpenGL3.0+, both included in mac app)
* :noncompat:`CHANGED default sound handler to be pygame again. Although pyglet looked promising for this`
  it has turned out to be buggy. Timing of sounds can be very irregular and sometimes they don't even play
  Although pygame has longer overall latencies (20-30ms) it's behaviour is at least robust. This will be
  revisited one day when i have time to write driver-specific code for sounds
* FIXED image importing - scaling from square image wasn't working and CMYK images weren't imported
  properly. Both are now fine.

----------


PsychoPy 0.95:
------------------------------

PsychoPy 0.95.11:
~~~~~~~~~~~~~~~~~~~~~~
* ADDED sound.Sound.getDuration() method
* FIXED spurious (unimportant but ugly) error messages raised by certain threads on core.quit()

PsychoPy 0.95.9:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED further bug in sound.Sound on win32 (caused by thread being polled too frequently)
* FIXED new bug in notebook view (introduced in 0.95.8)

PsychoPy 0.95.8:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED bug in sound.Sound not repeating when play() is called repeatedly
* IDE uses improved notebook view for code pages
* IDE line number column is larger
* IDE SaveAs no longer raises (inconsequential) error
* IDE Cmd-S or Ctrl-S now clears autocomplete

PsychoPy 0.95.7:
~~~~~~~~~~~~~~~~~~~~~~
* ADDED misc.cart2pol()
* ADDED highly optimised ElementArrayStim, suitable for drawing large numbers of elements. Requires fast OpenGL 2.0 gfx card - at least an nVidia 8000 series or ATI HD 2600 are recommended.
* FIXED bug in calibTools with MonitorFolder (should have been monitorFolder)
* FIXED bug in Sound.stop() for pyglet contexts
* FIXED bug in running scripts with spaces in the filename/path (Mac OS X)

PsychoPy 0.95.6:
~~~~~~~~~~~~~~~~~~~~~~
* DISABLED the setting of gamma if this is [1,1,1] (allows the user to set it from a control panel and not have this adjusted)
* FIXED gamma setting on linux (thanks to Luca Citi for testing)
* FIXED bug in TextStim.setRGB (wasn't setting properly after text had been created)
* FIXED bug searching for shaders on ATI graphics cards
* FIXED - now no need to download avbin for the mac IDE installation

PsychoPy 0.95.5:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED bug in event.clearEvents() implementation in pyglet (wasn't clearing)
* FIXED - psychopy no longer disables ipython shortcut keys
* FIXED bug in sound.Sound initialisation without pygame installeds
* ADDED core.rush() for increasing thread priority on win32
* ADDED Window._haveShaders, XXXStim._useShaders and XXXStim.setUseShaders
* FIXED crashes on win32, running a pyglet context after a DlgFromDict
* ADDED gamma correction for pyglet contexts (not tested yet on linux)

PsychoPy 0.95.4:
~~~~~~~~~~~~~~~~~~~~~~
* :noncompat:`CHANGED PsychoPy options (IDE and monitors) now stored the following, rather than with the app. (monitor calib files will be moved here if possible)`
    * ~/.PsychoPy/IDE (OS X, linux)
    * <Docs and Settings>/<user>/Application Data/PsychoPy
* FIXED bug in text rendering (ATI/win32/pyglet combo only)
* FIXED minor bug in handling of images with alpha channel

PsychoPy 0.95.3:
~~~~~~~~~~~~~~~~~~~~~~
* ADDED a .clearTextures() method to PatchStim and RadialStim, which should be called before de-referencing a stimulus
* :noncompat:`CHANGED input range for numpy array textures to -1:1`
* ADDED sysInfo.py to demos

PsychoPy 0.95.2:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED quitting PsychoPyIDE now correctly cancels when saving files

PsychoPy 0.95.1:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED problem with saving files from the IDE on Mac
* FIXED Cmd-C now copies from the output window of IDE
* even nicer IDE icons (thanks to the Crystal project at everaldo.com)
* FIXED bug in the shaders code under pyglet (was working fine in pygame already)
* (refactored code to use a template visual stimulus)

PsychoPy 0.95.0:
~~~~~~~~~~~~~~~~~~~~~~
* FIXED linux bug preventing repeated dialogs (thanks Luca Citi)
* REWRITTEN stimuli to use _BaseClass, defining ._set() method
* MAJOR IMPROVEMENTS to IDE:
  * Intel mac version available as app bundle, including python
  * FIXED double help menu
  * cleaned code for fetching icons
  * fixed code for updating SourceAssistant (now runs from .OnIdle())

Older
----------------------

PsychoPy 0.94.0:
~~~~~~~~~~~~~~~~~~~~~~
* pyglet:
  * can use multiple windows and multiple screens (see screensAndWindows demo)
  * sounds are buffered faster and more precisely (16ms with <0.1ms variability on my system)
  * creating sounds in pyglet starts a separate thread. If you use sounds in your script you must call core.quit() when you're done to exit the system (or this background thread will continue).
  * pyglet window.setGamma and setGammaRamp working on win and mac (NOT LINUX)
  * pyglet event.Mouse complete (and supports wheel as well as buttons)
  * pyglet is now the default context. pygame will be used if explicitly called or if pyglet (v1.1+) isn't found
  * pyglet can now get/save movie frames (like pygame)
  * TextStims are much cleaner (and a bit bigger?) Can use multiple lines too. New method for specifying font
* added simpler parallel.py (wraps _parallel which will remain for now)
* removed the C code extensions in favour of ctypes (so compiler no longer necessary)
* converted "is" for "==" where appropriate (thanks Luca)
* Window.getMovieFrame now takes a buffer argument ('front' or 'back')
* monitor calibration files now stored in HOME/.psychopy/monitors rather than site-packages
* Window.flip() added and supports the option not to clear previous buffer (for incremental drawing). Window.update() is still available for now but can be replaced with flip() commands
* updated demos

PsychoPy 0.93.6:
~~~~~~~~~~~~~~~~~~~~~~
* bug fixes for OS X 10.5 and ctypes OpenGL
* new improved OS X installer for dependencies
* moved to egg for OS X distribution

PsychoPy 0.93.5:
~~~~~~~~~~~~~~~~~~~~~~

* added rich text ctrl to IDE output, including links to lines of errors
* IDE now only opens one copy of a given text file
* improved (chances of) sync-to-vertical blank on windows without adjusting driver settings (on windows it's still better to set driver to force sync to be safe!)
* added center and radius arguments to filters.makeMask and filters.makeRadialMatrix
* implemented pyglet backend for;
    * better screen handling (can specify which screen a window should appear in)
    * fewer dependencies (takes care of pygame and opengl)
    * faster sound production
    * TextStims can be multi-line
    * NO GAMMA-SETTING as yet. Don't use this backend if you need a gamma-corrected window and aren't using Bits++.
* changed the behaviour of Window winTypes
    If you leave winType as None PsychoPy tries to use Pygame, Pyglet, GLUT in that order
    (when Pyglet can handle gamma funcs it will become default). Can be overridden by specifying winType.
* turned off depth testing for drawing of text (will simply be overlaid in the order called)
* changes to TextStim: pyglet fonts are loaded by name only, not filename. PsychoPy TextStim now has an additional argument called 'fontFiles=[]' to allow the adding of custom ttf fonts, but the font name should be used as the font=" " argument.
* updated some of the Reference docs

PsychoPy 0.93.3:
~~~~~~~~~~~~~~~~~~~~~~
* fixed problem with 'dynamic loading of multitextureARB' (only found on certain graphics cards)

PsychoPy 0.93.2:
~~~~~~~~~~~~~~~~~~~~~~
* improved detection of non-OpenGL2.0 drivers

PsychoPy 0.93.1:
~~~~~~~~~~~~~~~~~~~~~~
* now automatically uses shaders only if available (older machines can use this version but will not benefit from the speed up)
* slight speed improvement for TextStim rendering (on all machines)

PsychoPy 0.93.0:
~~~~~~~~~~~~~~~~~~~~~~
* new requirement of PyOpenGL3.0+ (and a graphics card with OpenGL2.0 drivers?)
* much faster implementation of setRGB, setContrast and setOpacity (using fragment shaders)
* images (and other textures) need not be square. They will be automatically resampled if they arent. Square power-of-two image textures are still recommended
* Fixed problem in calibTools.DACrange caused by change in numpy rounding behaviour. (symptom was strange choice of lum values for calibrations)
* numpy arrays as textures currently need to be NxM intensity arrays
* multitexturing now handled by OpenGL2.0 rather than ARB
* added support for Cedrus response pad
* if any component of rgb*contrast>1 then the stimulus will be drawn as low contrast and b/y (rgb=[0.2,0.2,-0.2]) in an attempt to alert the user that this is out of range

PsychoPy 0.92.5:
~~~~~~~~~~~~~~~~~~~~~~
* Fixed issue with stairhandler (it was terminating based only on the nTrials). It does now terminate when both the nTrials and the nReversals [or length(stepSizes) if this is greater] are exceeded.
* Minor enhancements to IDE (added explicit handlers to menus for Ctrl-Z, Ctrl-Y, Ctrl-D)

PsychoPy 0.92.4:
~~~~~~~~~~~~~~~~~~~~~~
* fixed some source packaging problems for linux (removed trademark symbols from serialposix.py and fixed directory capitalisation of IDE/Resources in setup.py). Thanks to Jason Locklin and Samuele Carcagno for picking them up.
* numerous minor improvements to the IDE
* reduced the buffer size of sound stream to reduce latency of sound play
* fixed error installing start menu links (win32)

PsychoPy 0.92.3:
~~~~~~~~~~~~~~~~~~~~~~
* new source .zip package (switched away from the use of setuptools - it didn't include files properly in a source dist)
* Fixed problem on very fast computers that meant error messages weren't always displayed in the IDE

PsychoPy 0.92.2:
~~~~~~~~~~~~~~~~~~~~~~
* have been trying (and failing) to make scripts run faster from the IDE under Mac OS X. Have tried using threads and debug modules (which would mean you didn't need to import all the libs every time). All these work fine under win32 but not under OS X every time :-( If anyone has a new idea for how to run a pygame window in the same process as the IDE thread I'd love hear it
* removed the messages from the new TextStim stimuli
* fixed bug in IDE that caused it to crash before starting if pythonw.exe was run rather than python.exe on first run(!)
* improvements to the source assistant window (better help and now fetches function arguments)

Known Problems:
* The IDE isn't collecting all errors that are returned - a problem with the process redirection mechanism? FIXED in 0.92.3

PsychoPy 0.92.1
~~~~~~~~~~~~~~~~~~~~~~
* fixed minor bug in IDE - wouldn't open if it had been closed with no open docs.
* fixed problem with pushing/popping matrix that caused the stimuli to disappear (only if a TextStim was rendered repeatedly)

PsychoPy 0.92.0:
~~~~~~~~~~~~~~~~~~~~~~
* 'sequential' ordering now implemented for data.TrialHandler (thx Ben Webb)
* moved to pygame fonts (with unicode support and any TT font on the system). The switch will break any code that was using TextStim with lineWidth or letterWidth as args. Users wanting to continue using the previous TextStim can call textStimGLUT instead (although I think the new pygame fonts are superior in every way).
* improved IDE handling of previous size (to cope with being closed in the maximised or minimised state, which previously caused the window not to return)

PsychoPy 0.91.5:
~~~~~~~~~~~~~~~~~~~~~~
* fixed minor bug in using numpy.array as a mask (was only working if array was 128x128)
* faster startup for IDE (added threading class for importing modules)
* fixed very minor bug in IDE when searching for attributes that don't exist
* fixed minor bug where scripts with syntax errors didn't run but didn't complain either
* IDE FileOpen now tries the folder that the current file is in first
* IDE removed threading class for running scripts

PsychoPy 0.91.4
~~~~~~~~~~~~~~~~~~~~~~
* fixed the problem of stimulus order/depth. Now the default depth is set (more intuitively) by the order of drawing not creating.
* IDE added recent files to file menu
* IDE minor bug fixes
* IDE rewrite of code inspection using wx.py.instrospect

PsychoPy 0.91.3
~~~~~~~~~~~~~~~~~~~~~~
* added find dialog to IDE
* added ability of data.FunctionFromStaircase to create unique bins rather than averaging several x values. Give bins='unique' (rather than bins=someInteger). Also fixed very minor issue where this func would only take a list of lists, rather than a single list.

PsychoPy 0.91.2
~~~~~~~~~~~~~~~~~~~~~~
* fixed IDE problem running filenames containing spaces (only necessary on win32)

PsychoPy 0.91.1
~~~~~~~~~~~~~~~~~~~~~~
* added reasonable SourceAssistant to IDE
* added a stop button to abort scripts in IDE
* IDE scripts now run as sub process rather than within the main process: slower but safer
* added an autoflushing stdout to psychopy.__init__. Where lots of text is written to stdout this may be a problem, but turing it off means that stdout doesn't get properly picked up by the IDE :-(

PsychoPy 0.91.0
~~~~~~~~~~~~~~~~~~~~~~
* PsychoPy now has its own IDE!! With syntax-highlighting, code-folding and auto-complete!! :-)
* gui.py had to be refactored a little but (I think) should not be noticed by the end user (gui.Dlg is now a subclass of wx.Dialog rather than a modified instance)
* gui.Dlg and DlgFromDict now end up with an attribute .OK that is either True or False
* fixed bug in data.StairHandler that could result in too many trials being run (since v0.89)

PsychoPy 0.90.4
~~~~~~~~~~~~~~~~~~~~~~
* resolved deprecation warning with wxPython (now using "import wx")

PsychoPy 0.90.3
~~~~~~~~~~~~~~~~~~~~~~
* used the new numpy.mgrid commands throughout filters and visual modules
* sorted out the rounding probs on RadialStim
* fixed import bug in calibtools.py

PsychoPy 0.90.2
~~~~~~~~~~~~~~~~~~~~~~
* fixed new bug in the minVal/maxVal handling of StairHandler (where these have not been specified)
* changed the default console log level to be ERROR, due to too much log output!

PsychoPy 0.90.1
~~~~~~~~~~~~~~~~~~~~~~
* fixed new bug in Sound object
* changed the default log file to go to the script directory rather than site-packages/psychopy

PsychoPy 0.90
~~~~~~~~~~~~~~~~~~~~~~
* sounds now in stereo and a new function to allow you to choose the settings for the sound system.
* LMS colors (cone-isolating stimuli) are now tested and accurate (when calibrated)
* added logging module (erros, warnings, info). And removed other messages:
     * @Verbose@ flags have become log.info messages
     * @Warn@ commands have become log.warning messages
* added minVal and maxVal arguments to data.StairHandler so that range can be bounded
* @import psychopy@ no longer imports anything other than core

Psychopy 0.89.1
~~~~~~~~~~~~~~~~~~~~~~
* fixed bug in new numpy's handling of bits++ header

Psychopy 0.89
~~~~~~~~~~~~~~~~~~~~~~
* optimised DotStim to use vertex arrays (can now draw several thousand dots)
* optimised RadialStim to use vertex arrays (can increase radial resolution without much loss)

Psychopy 0.88
~~~~~~~~~~~~~~~~~~~~~~
* fixed problem with MonitorCenter on OSX (buttons not working on recent version of wxPython)

Psychopy 0.87
~~~~~~~~~~~~~~~~~~~~~~
* added sqrXsqr to RadialStim and made it default texture
* fixed a minor bug in RadialStim rendering (stimuli failed to appear under certain stimulus orderings)
* changed RadialStim size parameter to be diameter rather than radius (to be like AlphaStim)
* namechange: introduced PatchStim (currently identical to AlphaStim which may one day become deprecated)

Psychopy 0.86
~~~~~~~~~~~~~~~~~~~~~~
* distributed as an .egg

Psychopy 0.85
~~~~~~~~~~~~~~~~~~~~~~
* upgraded for numpy1.0b and scipy0.50. Hopefully those packages are now stable enough that they won't need further PsychoPy compatibility changes

Psychopy 0.84
~~~~~~~~~~~~~~~~~~~~~~
* NEW (alpha) support for radial patterns rather than linear ones
* changed Clock behaviour to use time.clock() on win32 rather than time.time()
* fixed a bug in the shuffle seeding behaviour
* added a noise pattern to bacground in monitor calibration

Psychopy 0.83
~~~~~~~~~~~~~~~~~~~~~~
* NEW post-install script for Win32 installs shortcuts to your >>Start>Programs menu
* NEW parallel port code (temporary form) using DLportIO.dll can be found under _parallel
* NEW hardware module with support for fORP response box (for MRI) using serial port
* added iterator functionality to data.TrialHandler and data.StairHandler you can now use ::
    for thisTrial in allTrials:

but a consequence was that .nextTrial() will be deprecated in favour of .next().
Also, when the end of the trials is reached a StopIteration is raised.
* added the ability to seed the shuffle mechanism (and trial handler) so you can repeat experiments with the same trial sequence

Psychopy 0.82
~~~~~~~~~~~~~~~~~~~~~~
* rewritten code for bits++ LUT drawing, raised by changes in pyOpenGL(2.0.1.09) call to drawpixels
* minor change to exit behaviour. pyGame.quit() is now called and then sys.exit(0) rather than sys.exit(1)
* bug fixes in type handling (from Numeric to numpy)

Psychopy 0.81
~~~~~~~~~~~~~~~~~~~~~~
* changes to gui caused by new threading behaviour of wxPython and PyGame (DlgFromDict must now be a class not a function).

Psychopy 0.80
~~~~~~~~~~~~~~~~~~~~~~
* switching numeric code to new python24 and new scipy/numpy. MUCH nicer
* new (reduced requirements):
  * numpy 0.9 or newer (the replacement for Numeric/numarray)
  * numpy 0.4.4 or newer
  * pyOpenGL
  * pygame
  * PIL
  * matplotlib (for data plotting)

PsychoPy 0.72
~~~~~~~~~~~~~~~~~~~~~~
* tested (and fixed) compatibility with wxPython 2.6. Will now be using this as my primary handler for GUIs
* ADDED ability to quit during run of getLumSeries

PsychoPy 0.71
~~~~~~~~~~~~~~~~~~~~~~
* FIXED filename bug in makeMovies.makeAnimatedGIF
* slight change to monitors that it uses testMonitor.calib as a default rather than default.calib (testMonitor.calib is packaged with the installation)

PsychoPy 0.70
~~~~~~~~~~~~~~~~~~~~~~
* FIXED bug in setSize. Wasn't updating correctly
* ADDED ability to append to a data file rather than create new
* bits.lib (from CRS) is now distributed directly with psychopy rather than needing separate install)
* ADDED db/log/linear step methods to StairHandler
* ADDED logistic equation to data.FitFunction

PsychoPy 0.69
~~~~~~~~~~~~~~~~~~~~~~
* ADDED a testMonitor to the monitors package so that demos can use it for pseudo*calibrated stimuli.
* REDUCED the attempt to use _bits.pyd. Was only necessary for machines that had bits++ monitor center
* ADDED basic staircase method
* :noncompat:`CHANGED dlgFromDict to return None on cancel rather than 0`
* :noncompat:`CHANGED the description of sin textures so that the centre of the patch had the color of dkl or rgb rather`
  than the edge. (Effectively all sin textures are now shifted in phase by pi radians).
  -Demos removed from the main package - now ONLY distributed as a separate library

PsychoPy 0.68
~~~~~~~~~~~~~~~~~~~~~~
* FIXED toFile and fromFile so they work!?
* Demos being distributed as a separate .zip file (may be removed from the main package someday)

PsychoPy 0.67
~~~~~~~~~~~~~~~~~~~~~~
* ADDED toFile, fromFile, pol2cart functions to psychopy.misc
* :noncompat:`CHANGED waitKeys to return a list of keys (usually of length one) so that it's compatible with getKeys`

PsychoPy 0.66
~~~~~~~~~~~~~~~~~~~~~~
* serial is now a subpackage of psychopy and so doesn't need additional installation
* REMOVED the code to try and query the graphics card about the scr dimensions. From now on, if yo uwish to use real world units, you MUST specify scrWidthPIX and scrWidthCM when you make your visual.Window
* ADDED flag to data output to output matrixOnly (useful for matlab imports)
* REVERTED the default numeric handler to be Numeric rather than numarray (because it looks like numarray hasn't taken off as much as thought)
* FIXED minor bug in text formatting for TrialHandler.saveAsText()
* :noncompat:`CHANGED visual.Window so that the monitor argument prefers to receive a Monitor object (rather than just a dictionary) or just the name of one. MonitorCenter makes it so easy to create these now that they should be the default.`
* :noncompat:`CHANGED Photometer initialisation behaviour - used to raise an error on a fail but now sets an internal attribute .OK to False rather than True`

PsychoPy 0.65
~~~~~~~~~~~~~~~~~~~~~~
* MonitorCenter now complete. Plots and checks gamma correction.
* can write movies out to animated gifs(any platform) or mpg/avi (both windows only)

PsychoPy 0.64
~~~~~~~~~~~~~~~~~~~~~~
* :noncompat:`CHANGED monitor key dkl_rgb_matrix to dkl_rgb (also for lms)`
* ADDED code for PR650 to get the monitor color calibration and calculate the color conversion matrices automatically. Will be implemented via the MonitorCenter application.
* ADDED pyserial2.0 as a subpackage of psychopy so that it needn't be separately installed
* Much improved MonitorCenter with DKL and LMS calibration buttons and matrix output
* Double-click installer for Mac now available

PsychoPy 0.63
~~~~~~~~~~~~~~~~~~~~~~
* ADDED ability to capture frames from the window as images (tif, jpg...) or as animated GIF files :) see demo
* ADDED ability for elements in DotStim to be any arbitrary stimulus with a methods for .setPos(), .draw()

PsychoPy 0.62
~~~~~~~~~~~~~~~~~~~~~~
* FIXED the circular mask for DotStim
* FIXED bug in the new text alignment method (was being aligned but not positioned?!)

PsychoPy 0.61
~~~~~~~~~~~~~~~~~~~~~~
* FIXED minor bug in MonitorCenter (OS X only)

PsychoPy 0.60
~~~~~~~~~~~~~~~~~~~~~~
* ADDED a GUI application for looking after monitors and calibrations. SEE MonitorCenter.py in the new package monitors
* MOVED "psychopy.calib" subpackage to a whole separate package "monitors". Calibration files will now be stored alongside the calibration code. This makes it easier to develop the new calibration GUI application that I'm working on. Also means that if you delete the psychopy folder for a new installation you won't lose your calibration files.
* ADDED optional maxWait argument to event.waitKeys()
* :noncompat:`CHANGED TextStim to take the font as a name rather than font number`
* ADDED alignment to text stimuli (alignVert, alignHoriz)
* :noncompat:`CHANGED waitKeys to implicitly clear keys from the event queue so that it only finds the first keypress after its called. As result it now returns a single character rather than list of them`
* :noncompat:`CHANGED visual.Window so that it no longer overrides monitor settings if arguments are specified. Easy now to create a monitor in the monitors GUI and use that instead`
* ADDED the circular mask for DotStimulus
