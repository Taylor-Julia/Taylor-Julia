.. _sonaIntegration:

Recruiting with Sona Systems
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sorry, the documentation for this hasn't yet been written, but Sona Systems have shared `a guide to get started <https://www.sona-systems.com/help/psychopy.aspx>`_.

The features are in place to do this, and the general description of how to make it work are on the page :ref:`recruitingOnline`.
