
.. _qualtricsIntegration:

Daisy-chaining with Qualtrics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sorry, the documentation for this hasn't yet been written.

The features are in place to do this, and the general description of how to make it work are on the page :ref:`recruitingOnline`.
